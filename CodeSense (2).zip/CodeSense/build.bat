@echo off
setlocal enabledelayedexpansion
echo ========================================================
echo Building CodeSense Analytical Utility (JDK 17 Target)
echo ========================================================

set JAVAC_CMD=javac
set JBR_PATH=C:\Program Files\JetBrains\IntelliJ IDEA 2026.2\jbr\bin\javac.exe

if exist "!JBR_PATH!" (
    set JAVAC_CMD="!JBR_PATH!"
    echo Using IntelliJ JBR javac: !JAVAC_CMD!
) else (
    echo IntelliJ JBR not found. Falling back to system PATH javac: !JAVAC_CMD!
)

if not exist bin mkdir bin

echo Compiling Java source files...
!JAVAC_CMD! --release 17 -d bin -cp "bin;lib/*" -sourcepath "src;test" src\com\codesense\Main.java src\com\codesense\VerifyCodeSense.java src\com\codesense\exporter\*.java src\com\codesense\ui\*.java src\com\codesense\analyzer\*.java src\com\codesense\ds\*.java src\com\codesense\features\*.java src\com\codesense\cli\*.java src\com\codesense\tools\*.java samples\*.java test\com\codesense\ds\*.java test\com\codesense\analyzer\*.java test\com\codesense\features\*.java test\com\codesense\cli\*.java

if %ERRORLEVEL% EQU 0 (
    echo.
    echo Compilation SUCCESSFUL! Binaries compiled into ./bin directory with --release 17 target.
) else (
    echo.
    echo Compilation FAILED! Please check error output above.
)
