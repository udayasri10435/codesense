@echo off
setlocal enabledelayedexpansion
echo ========================================================
echo Running CodeSense JUnit 5 Test Suite
echo ========================================================

set JAVA_CMD=java
set JBR_PATH=C:\Program Files\JetBrains\IntelliJ IDEA 2026.2\jbr\bin\java.exe

if exist "!JBR_PATH!" (
    set JAVA_CMD="!JBR_PATH!"
)

!JAVA_CMD! -jar lib/junit-platform-console-standalone-1.10.2.jar --class-path bin --scan-class-path
