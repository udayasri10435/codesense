@echo off
echo ========================================================
echo Packaging CodeSense Standalone Fat JAR (codesense.jar)
echo ========================================================

rem 1. Compile source files using build.bat
call build.bat

if %ERRORLEVEL% NEQ 0 (
    echo Compilation failed. Aborting JAR packaging.
    exit /b %ERRORLEVEL%
)

rem 2. Package into codesense.jar using pure Java JarPackager
set JAVA_EXE="C:\Program Files\JetBrains\IntelliJ IDEA 2026.2\jbr\bin\java.exe"
if exist %JAVA_EXE% (
    echo Packaging codesense.jar via Java JarPackager...
    %JAVA_EXE% -cp bin com.codesense.tools.JarPackager
) else (
    echo Packaging codesense.jar via PATH java JarPackager...
    java -cp bin com.codesense.tools.JarPackager
)

if %ERRORLEVEL% EQU 0 (
    echo ========================================================
    echo Packaging SUCCESSFUL! Created standalone codesense.jar
    echo Run GUI mode:  java -jar codesense.jar
    echo Run CLI mode:  java -jar codesense.jar --cli
    echo ========================================================
) else (
    echo JAR packaging failed.
)
