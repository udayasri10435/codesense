package com.codesense.tools;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;

/**
 * Pure Java Standalone JAR Packager.
 * Bundles compiled class files into a runnable fat JAR with custom manifest attributes,
 * eliminating external 'jar.exe' or build tool dependencies.
 */
public class JarPackager {

    public static void main(String[] args) {
        File binDir = new File("bin");
        File outputFile = new File("codesense.jar");

        if (!binDir.exists() || !binDir.isDirectory()) {
            System.err.println("Error: 'bin/' directory does not exist. Run build.bat first.");
            System.exit(1);
        }

        System.out.println("Packaging compiled classes from bin/ into " + outputFile.getName() + "...");

        Manifest manifest = new Manifest();
        Attributes mainAttrs = manifest.getMainAttributes();
        mainAttrs.put(Attributes.Name.MANIFEST_VERSION, "1.0");
        mainAttrs.put(Attributes.Name.MAIN_CLASS, "com.codesense.Main");
        mainAttrs.put(new Attributes.Name("Specification-Title"), "CodeSense");
        mainAttrs.put(new Attributes.Name("Specification-Version"), "1.0.0");
        mainAttrs.put(new Attributes.Name("Implementation-Title"), "com.codesense");
        mainAttrs.put(new Attributes.Name("Implementation-Version"), "1.0.0");

        try (JarOutputStream jos = new JarOutputStream(new FileOutputStream(outputFile), manifest)) {
            addDirectoryToJar(binDir, binDir, jos);
            System.out.println("SUCCESS: Standalone runnable JAR created -> " + outputFile.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Failed to create JAR: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }

    private static void addDirectoryToJar(File rootDir, File sourceDir, JarOutputStream jos) throws IOException {
        File[] files = sourceDir.listFiles();
        if (files == null) return;

        byte[] buffer = new byte[8192];
        for (File file : files) {
            if (file.isDirectory()) {
                addDirectoryToJar(rootDir, file, jos);
            } else {
                String relativePath = rootDir.toURI().relativize(file.toURI()).getPath().replace("\\", "/");
                JarEntry entry = new JarEntry(relativePath);
                entry.setTime(file.lastModified());
                jos.putNextEntry(entry);

                try (FileInputStream fis = new FileInputStream(file)) {
                    int bytesRead;
                    while ((bytesRead = fis.read(buffer)) != -1) {
                        jos.write(buffer, 0, bytesRead);
                    }
                }
                jos.closeEntry();
            }
        }
    }
}
