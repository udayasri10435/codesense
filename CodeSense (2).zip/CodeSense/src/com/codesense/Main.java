package com.codesense;

import com.codesense.cli.CodeSenseCLI;
import com.codesense.ui.CodeSenseDashboard;

import javax.swing.*;
import java.awt.*;

/**
 * Entry Point for CodeSense Analytical Utility.
 */
public class Main {
    public static void main(String[] args) {
        boolean forceCli = false;
        boolean runDemo = false;

        for (String arg : args) {
            if ("--cli".equalsIgnoreCase(arg)) {
                forceCli = true;
            } else if ("--demo".equalsIgnoreCase(arg) || "--benchmark".equalsIgnoreCase(arg)) {
                runDemo = true;
            }
        }

        if (runDemo) {
            System.out.println("Running CodeSense Automated Demonstration...");
            CodeSenseCLI cli = new CodeSenseCLI();
            cli.startInteractiveShell();
            return;
        }

        if (forceCli || GraphicsEnvironment.isHeadless()) {
            System.out.println("Starting CodeSense in CLI Mode...");
            CodeSenseCLI cli = new CodeSenseCLI();
            cli.startInteractiveShell();
        } else {
            SwingUtilities.invokeLater(() -> {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception ignored) {
                }
                CodeSenseDashboard dashboard = new CodeSenseDashboard();
                dashboard.setVisible(true);
            });
        }
    }
}
