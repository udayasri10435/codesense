# ⚡ CodeSense Architectural Complexity Report

**Generated:** 2026-08-13 22:46:17

## Executive Metrics Summary
- **Total Methods Indexed:** 18
- **Scanned Source Files:** 12
- **AVL Tree Height:** 5
- **AVL Rotations Triggered:** 11
- **Refactor Alerts:** 10

## 🚨 Refactor Alerts

### [CRITICAL] `DataPipeline.process_large_dataset()`
- **Issue:** Cyclomatic Complexity (36 >= 9) Max Nesting Depth (12 >= 3) Cognitive Overload (266) Low Maintainability Index (32.7/100)
- **Recommendation:** Replace Conditional Logic with Polymorphism or Command Pattern. Flatten nested branches using Early Return Guard Clauses. Extract helper routines to lower mental trace load. Decompose monolithic routine into cohesive domain services.

### [CRITICAL] `ComplexGodClass.processEverything()`
- **Issue:** Cyclomatic Complexity (22 >= 9) Max Nesting Depth (7 >= 3) Cognitive Overload (110) Low Maintainability Index (39.6/100)
- **Recommendation:** Replace Conditional Logic with Polymorphism or Command Pattern. Flatten nested branches using Early Return Guard Clauses. Extract helper routines to lower mental trace load. Decompose monolithic routine into cohesive domain services.

### [CRITICAL] `SpaghettiController.handleUserRegistration()`
- **Issue:** Cyclomatic Complexity (12 >= 9) Max Nesting Depth (16 >= 3) Cognitive Overload (83) Low Maintainability Index (42.2/100)
- **Recommendation:** Replace Conditional Logic with Polymorphism or Command Pattern. Flatten nested branches using Early Return Guard Clauses. Extract helper routines to lower mental trace load. Decompose monolithic routine into cohesive domain services.

### [CRITICAL] `ComplexGodClass.parseComplexConfiguration()`
- **Issue:** Cyclomatic Complexity (17 >= 9) Max Nesting Depth (8 >= 3) Cognitive Overload (83) Low Maintainability Index (44.9/100)
- **Recommendation:** Replace Conditional Logic with Polymorphism or Command Pattern. Flatten nested branches using Early Return Guard Clauses. Extract helper routines to lower mental trace load. Decompose monolithic routine into cohesive domain services.

### [CRITICAL] `ComplexOrderProcessor.processComplexOrder()`
- **Issue:** Cyclomatic Complexity (21 >= 9) Max Nesting Depth (5 >= 3) Cognitive Overload (63) Low Maintainability Index (42.3/100)
- **Recommendation:** Replace Conditional Logic with Polymorphism or Command Pattern. Flatten nested branches using Early Return Guard Clauses. Extract helper routines to lower mental trace load. Decompose monolithic routine into cohesive domain services.

### [CRITICAL] `algorithm.analyze_data_matrix()`
- **Issue:** Cyclomatic Complexity (9 >= 9) Max Nesting Depth (6 >= 3) Cognitive Overload (31)
- **Recommendation:** Replace Conditional Logic with Polymorphism or Command Pattern. Flatten nested branches using Early Return Guard Clauses. Extract helper routines to lower mental trace load.

### [CRITICAL] `ComplexGodClass.calculateTax()`
- **Issue:** Cyclomatic Complexity (14 >= 9) Max Nesting Depth (3 >= 3) Cognitive Overload (28) Low Maintainability Index (45.0/100)
- **Recommendation:** Replace Conditional Logic with Polymorphism or Command Pattern. Flatten nested branches using Early Return Guard Clauses. Extract helper routines to lower mental trace load. Decompose monolithic routine into cohesive domain services.

### [CRITICAL] `script.processUserData()`
- **Issue:** Cyclomatic Complexity (9 >= 9) Max Nesting Depth (5 >= 3) Cognitive Overload (15)
- **Recommendation:** Replace Conditional Logic with Polymorphism or Command Pattern. Flatten nested branches using Early Return Guard Clauses. Extract helper routines to lower mental trace load.

### [HIGH] `TrickyPythonSample.outer_routine()`
- **Issue:** Max Nesting Depth (4 >= 3)
- **Recommendation:** Flatten nested branches using Early Return Guard Clauses.

### [HIGH] `SampleService.calculateDiscount()`
- **Issue:** Composite Complexity Score (22.5 >= 15.0)
- **Recommendation:** Refactor routine into smaller sub-methods to reduce combined complexity score.

## 📋 Method Complexity Roadmap (AVL In-Order Sweep)

| Method Name | Class | LOC | CC | Cog | Nesting | MI | Score | Risk Level |
|---|---|---|---|---|---|---|---|---|
| `simpleGetter()` | SampleService | 3 | 1 | 1 | 1 | 80.9 | **4.18** | Low Complexity |
| `innerMethod()` | TrickyJavaSample | 3 | 1 | 1 | 1 | 80.9 | **4.98** | Low Complexity |
| `cleanAuditLogs()` | ComplexOrderProcessor | 5 | 2 | 1 | 1 | 74.4 | **6.20** | Low Complexity |
| `calculateOrderTotal()` | script | 10 | 2 | 1 | 1 | 65.7 | **7.30** | Low Complexity |
| `processUser()` | TrickyJSSample | 6 | 3 | 1 | 1 | 72.0 | **7.36** | Low Complexity |
| `calculateTotal()` | TrickyJSSample | 9 | 2 | 2 | 2 | 67.0 | **9.34** | Moderate Risk |
| `processDataWithLambdas()` | TrickyJavaSample | 8 | 4 | 2 | 2 | 68.3 | **11.48** | Moderate Risk |
| `validateUser()` | SampleService | 8 | 5 | 3 | 2 | 68.1 | **14.68** | Moderate Risk |
| `calculateDiscount()` | SampleService | 17 | 5 | 8 | 2 | 58.7 | **22.52** | High Complexity |
| `outer_routine()` | TrickyPythonSample | 13 | 4 | 9 | 4 | 62.2 | **24.08** | High Complexity |
| `processUserData()` | script | 16 | 9 | 15 | 5 | 58.9 | **39.96** | Critical Refactor Target |
| `calculateTax()` | ComplexGodClass | 46 | 14 | 28 | 3 | 45.0 | **62.56** | Critical Refactor Target |
| `analyze_data_matrix()` | algorithm | 18 | 9 | 31 | 6 | 57.4 | **63.28** | Critical Refactor Target |
| `processComplexOrder()` | ComplexOrderProcessor | 53 | 21 | 63 | 5 | 42.3 | **120.98** | Critical Refactor Target |
| `parseComplexConfiguration()` | ComplexGodClass | 45 | 17 | 83 | 8 | 44.9 | **142.90** | Critical Refactor Target |
| `handleUserRegistration()` | SpaghettiController | 59 | 12 | 83 | 16 | 42.2 | **151.84** | Critical Refactor Target |
| `processEverything()` | ComplexGodClass | 65 | 22 | 110 | 7 | 39.6 | **184.70** | Critical Refactor Target |
| `process_large_dataset()` | DataPipeline | 97 | 36 | 266 | 12 | 32.7 | **413.62** | Critical Refactor Target |
