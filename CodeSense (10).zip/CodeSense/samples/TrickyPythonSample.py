# Tricky Python Sample file testing edge cases for CodeParser
# Includes multiline docstrings containing def keywords and nested lambda expressions

def outer_routine(data_list):
    """
    Docstring example mentioning def fake_func(): inside text
    """
    filtered = filter(lambda x: x > 0, data_list)
    if filtered:
        for val in filtered:
            if val > 100:
                print("Large positive:", val)
    return True

def simple_helper(x, y):
    return x + y
