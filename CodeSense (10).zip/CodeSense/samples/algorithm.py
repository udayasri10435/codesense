def analyze_data_matrix(matrix, threshold, mode):
    result = []
    if matrix:
        for row in matrix:
            row_sum = 0
            for val in row:
                if val > threshold:
                    if mode == "strict" and val > threshold * 2:
                        row_sum += val * 2
                    elif mode == "lenient":
                        row_sum += val
                elif val < 0:
                    row_sum -= 1
            result.append(row_sum)
    return result

def simple_logger(msg):
    print(f"LOG: {msg}")
