package samples;

public class SampleService {

    public void simpleGetter() {
        System.out.println("Simple routine");
    }

    public boolean validateUser(String username, String password) {
        if (username != null && !username.isEmpty()) {
            if (password != null && password.length() >= 8) {
                return true;
            }
        }
        return false;
    }

    public double calculateDiscount(double price, int customerType, boolean isFirstOrder) {
        double discount = 0.0;
        if (price > 100.0) {
            if (customerType == 1) {
                discount += price * 0.10;
            } else if (customerType == 2) {
                discount += price * 0.15;
            } else {
                discount += price * 0.05;
            }

            if (isFirstOrder) {
                discount += 5.0;
            }
        }
        return discount;
    }
}
