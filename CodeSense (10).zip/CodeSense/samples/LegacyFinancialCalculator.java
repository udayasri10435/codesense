package samples;

public class LegacyFinancialCalculator {

    public double calculateComplexTaxAndInterest(double principal, double rate, int years, int accountType,
                                                boolean isTaxExempt, String jurisdiction, boolean hasPenalties,
                                                int transactionCount, double bonusMultiplier) {
        double result = principal;

        if (principal > 0) {
            if (rate > 0) {
                if (accountType == 1) {
                    for (int y = 0; y < years; y++) {
                        if (y % 2 == 0) {
                            if (jurisdiction.equals("US_CA")) {
                                result += result * (rate * 1.05);
                            } else if (jurisdiction.equals("US_NY")) {
                                result += result * (rate * 1.08);
                            } else {
                                result += result * rate;
                            }
                        } else {
                            if (hasPenalties) {
                                result -= 50.0;
                            }
                            result += result * (rate * 0.95);
                        }

                        for (int t = 0; t < transactionCount; t++) {
                            if (t % 5 == 0) {
                                result += 2.5 * bonusMultiplier;
                            } else if (t % 10 == 0) {
                                result -= 1.0;
                            }
                        }
                    }
                } else if (accountType == 2) {
                    int step = 0;
                    while (step < years) {
                        switch (jurisdiction) {
                            case "EU_DE":
                                result *= 1.03;
                                break;
                            case "EU_FR":
                                result *= 1.025;
                                break;
                            case "EU_UK":
                                result *= 1.04;
                                break;
                            default:
                                result *= 1.01;
                                break;
                        }
                        step++;
                    }
                }
            } else {
                throw new IllegalArgumentException("Negative rate");
            }

            if (!isTaxExempt) {
                if (result > 50000) {
                    result -= result * 0.25;
                } else if (result > 20000) {
                    result -= result * 0.15;
                } else {
                    result -= result * 0.05;
                }
            }
        } else {
            return 0.0;
        }

        return result;
    }
}
