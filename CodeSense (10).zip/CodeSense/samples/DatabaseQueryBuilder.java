package samples;

import java.util.List;
import java.util.Map;

public class DatabaseQueryBuilder {

    public String buildDynamicSelectQuery(String tableName, List<String> fields, Map<String, Object> filters,
                                           List<String> groupBy, String orderBy, boolean isAscending,
                                           int limit, int offset) {
        StringBuilder sb = new StringBuilder("SELECT ");

        if (fields != null && !fields.isEmpty()) {
            for (int i = 0; i < fields.size(); i++) {
                sb.append(fields.get(i));
                if (i < fields.size() - 1) {
                    sb.append(", ");
                }
            }
        } else {
            sb.append("*");
        }

        sb.append(" FROM ").append(tableName);

        if (filters != null && !filters.isEmpty()) {
            sb.append(" WHERE ");
            int idx = 0;
            for (Map.Entry<String, Object> entry : filters.entrySet()) {
                if (idx > 0) {
                    sb.append(" AND ");
                }
                if (entry.getValue() instanceof String) {
                    sb.append(entry.getKey()).append(" = '").append(entry.getValue()).append("'");
                } else if (entry.getValue() instanceof List) {
                    sb.append(entry.getKey()).append(" IN (");
                    List<?> list = (List<?>) entry.getValue();
                    for (int j = 0; j < list.size(); j++) {
                        sb.append(list.get(j));
                        if (j < list.size() - 1) sb.append(",");
                    }
                    sb.append(")");
                } else {
                    sb.append(entry.getKey()).append(" = ").append(entry.getValue());
                }
                idx++;
            }
        }

        if (orderBy != null && !orderBy.isEmpty()) {
            sb.append(" ORDER BY ").append(orderBy).append(isAscending ? " ASC" : " DESC");
        }

        if (limit > 0) {
            sb.append(" LIMIT ").append(limit);
            if (offset > 0) {
                sb.append(" OFFSET ").append(offset);
            }
        }

        return sb.toString();
    }
}
