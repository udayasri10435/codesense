function processUserData(users, filters) {
    let result = [];
    if (users && users.length > 0) {
        for (let i = 0; i < users.length; i++) {
            let u = users[i];
            if (u.isActive) {
                if (filters.minAge && u.age >= filters.minAge) {
                    if (filters.role && u.role === filters.role) {
                        result.push(u);
                    }
                }
            }
        }
    }
    return result;
}

function calculateOrderTotal(items, discountCode) {
    let total = 0;
    items.forEach(item => {
        total += item.price * item.quantity;
    });
    if (discountCode === "SAVE10") {
        total *= 0.9;
    }
    return total;
}
