package samples;

public class ComplexOrderProcessor {

    public double processComplexOrder(int orderType, double amount, int userTier, boolean expressShipping, String region, int itemsCount) {
        double finalPrice = amount;

        if (amount > 0) {
            if (userTier == 1) {
                if (orderType == 100) {
                    for (int i = 0; i < itemsCount; i++) {
                        if (i % 2 == 0 && expressShipping) {
                            finalPrice -= 2.0;
                        } else if (i % 3 == 0 || region.equals("US")) {
                            finalPrice -= 1.5;
                        } else {
                            finalPrice -= 0.5;
                        }
                    }
                } else if (orderType == 200) {
                    while (itemsCount > 0) {
                        if (region.equals("EU") && userTier > 0) {
                            finalPrice += 10.0;
                        } else {
                            finalPrice += 5.0;
                        }
                        itemsCount--;
                    }
                }
            } else if (userTier == 2) {
                switch (region) {
                    case "US":
                        finalPrice *= 0.9;
                        break;
                    case "EU":
                        finalPrice *= 0.85;
                        break;
                    case "ASIA":
                        finalPrice *= 0.95;
                        break;
                    default:
                        finalPrice *= 0.98;
                        break;
                }
            } else {
                if (expressShipping && amount > 500) {
                    finalPrice += 50.0;
                } else if (!expressShipping || amount < 100) {
                    finalPrice += 10.0;
                }
            }
        } else {
            throw new IllegalArgumentException("Invalid order amount");
        }

        return finalPrice;
    }

    public void cleanAuditLogs(String logPath) {
        if (logPath != null) {
            System.out.println("Cleaning log path: " + logPath);
        }
    }
}
