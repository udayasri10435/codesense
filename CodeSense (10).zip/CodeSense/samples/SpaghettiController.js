/**
 * A highly nested JavaScript file with callback hell and messy async logic.
 * Designed to test the analyzer's ability to detect high nesting levels.
 */
function handleUserRegistration(req, res) {
    if (req.body) {
        if (req.body.username && req.body.password) {
            database.connect(function(err, db) {
                if (err) {
                    return res.status(500).send("DB connection failed");
                } else {
                    db.collection('users').findOne({ username: req.body.username }, function(err, user) {
                        if (err) {
                            return res.status(500).send("Query failed");
                        } else {
                            if (user) {
                                return res.status(400).send("User already exists");
                            } else {
                                crypto.hash(req.body.password, function(err, hash) {
                                    if (err) {
                                        return res.status(500).send("Hashing failed");
                                    } else {
                                        const newUser = { username: req.body.username, password: hash };
                                        db.collection('users').insertOne(newUser, function(err, result) {
                                            if (err) {
                                                return res.status(500).send("Insert failed");
                                            } else {
                                                emailService.sendWelcomeEmail(req.body.email, function(err) {
                                                    if (err) {
                                                        console.error("Failed to send welcome email");
                                                        // Fallback logic
                                                        if (req.body.phone) {
                                                            smsService.sendWelcomeSMS(req.body.phone, function(err) {
                                                                if (err) {
                                                                    console.error("SMS also failed");
                                                                    return res.status(201).send("Created, but no notifications sent");
                                                                } else {
                                                                    return res.status(201).send("Created and SMS sent");
                                                                }
                                                            });
                                                        } else {
                                                            return res.status(201).send("Created, but no email sent");
                                                        }
                                                    } else {
                                                        return res.status(201).send("User created successfully");
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        }
                    });
                }
            });
        } else {
            return res.status(400).send("Missing credentials");
        }
    } else {
        return res.status(400).send("Empty body");
    }
}
