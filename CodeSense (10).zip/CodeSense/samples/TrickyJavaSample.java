package samples;

import java.util.List;

/**
 * Tricky Java Sample file designed to test edge cases of the lightweight CodeParser.
 * Stresses lambda expressions, string literals with braces, multi-line formatting, and inner classes.
 */
public class TrickyJavaSample {

    public void processDataWithLambdas(List<String> items) {
        String msg = "Testing { braces in string } and // fake comments";
        items.forEach(item -> {
            if (item != null && !item.isEmpty()) {
                System.out.println("Processing: " + item);
            }
        });
    }

    public static class InnerHelper {
        public boolean innerMethod(int val) {
            return val > 10;
        }
    }
}
