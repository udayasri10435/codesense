package com.codesense.samples;

import java.util.*;
import java.io.*;

/**
 * A massive, complex "God Class" simulating a legacy monolithic service.
 * This class is designed to trigger high Cyclomatic Complexity, deep nesting,
 * and poor Maintainability Index scores in CodeSense.
 */
public class ComplexGodClass {

    private Map<String, List<Object>> legacyDataStore = new HashMap<>();
    private boolean isInitialized = false;

    public void processEverything(String input, int flags, boolean override) throws Exception {
        if (input != null && !input.isEmpty()) {
            if (flags > 0) {
                if (override) {
                    for (int i = 0; i < flags; i++) {
                        if (i % 2 == 0) {
                            try {
                                if (input.length() > i) {
                                    System.out.println("Processing: " + input.charAt(i));
                                } else {
                                    System.out.println("Padding...");
                                }
                            } catch (Exception e) {
                                if (e instanceof NullPointerException) {
                                    System.err.println("NPE!");
                                } else if (e instanceof IndexOutOfBoundsException) {
                                    System.err.println("OOB!");
                                } else {
                                    throw new RuntimeException("Unknown error", e);
                                }
                            }
                        } else {
                            switch(i) {
                                case 1:
                                    System.out.println("One");
                                    break;
                                case 3:
                                    if (flags > 5) {
                                        System.out.println("Three and big");
                                    } else {
                                        System.out.println("Three and small");
                                    }
                                    break;
                                case 5:
                                case 7:
                                case 9:
                                    System.out.println("Odd primes");
                                    break;
                                default:
                                    System.out.println("Other odd");
                            }
                        }
                    }
                } else {
                    System.out.println("No override, standard processing...");
                    while (flags > 0) {
                        flags--;
                        if (flags == 42) {
                            continue;
                        }
                        if (flags == 0) {
                            break;
                        }
                    }
                }
            } else if (flags < 0) {
                System.out.println("Negative flags are not supported unless...");
                if (input.equals("ADMIN")) {
                    System.out.println("Admin override for negative flags.");
                } else {
                    throw new IllegalArgumentException("Invalid flags");
                }
            }
        }
    }

    public int calculateTax(int income, String userType, int dependents, boolean hasMortgage) {
        int tax = 0;
        if (income < 0) {
            return -1; // Invalid
        }
        if (userType.equals("REGULAR")) {
            if (income < 30000) {
                tax = (int)(income * 0.10);
            } else if (income < 80000) {
                tax = (int)(income * 0.20);
            } else {
                tax = (int)(income * 0.30);
            }
            if (dependents > 0) {
                if (dependents == 1) {
                    tax -= 1000;
                } else if (dependents == 2) {
                    tax -= 2000;
                } else {
                    tax -= 3500;
                }
            }
            if (hasMortgage) {
                tax -= 500;
            }
        } else if (userType.equals("CONTRACTOR")) {
            if (income < 50000) {
                tax = (int)(income * 0.15);
            } else {
                tax = (int)(income * 0.25);
            }
            if (dependents > 2) {
                tax -= 1000;
            }
        } else if (userType.equals("EXEMPT")) {
            tax = 0;
        } else {
            // Unknown user type
            if (income > 100000) {
                tax = (int)(income * 0.35);
            } else {
                tax = (int)(income * 0.22);
            }
        }
        return Math.max(tax, 0);
    }
    
    public void parseComplexConfiguration(String configData) {
        String[] lines = configData.split("\n");
        for (String line : lines) {
            line = line.trim();
            if (!line.startsWith("#")) {
                if (line.contains("=")) {
                    String[] parts = line.split("=");
                    if (parts.length == 2) {
                        String key = parts[0].trim();
                        String value = parts[1].trim();
                        if (key.startsWith("db.")) {
                            if (key.equals("db.url")) {
                                System.out.println("Connecting to " + value);
                            } else if (key.equals("db.user")) {
                                System.out.println("User: " + value);
                            } else if (key.equals("db.password")) {
                                System.out.println("Secret!");
                            } else {
                                System.out.println("Unknown DB config: " + key);
                            }
                        } else if (key.startsWith("api.")) {
                            if (key.endsWith(".endpoint")) {
                                System.out.println("Endpoint: " + value);
                            } else if (key.endsWith(".timeout")) {
                                try {
                                    int timeout = Integer.parseInt(value);
                                    if (timeout < 0) {
                                        System.out.println("Invalid timeout");
                                    } else if (timeout > 10000) {
                                        System.out.println("Warning: high timeout");
                                    }
                                } catch (NumberFormatException e) {
                                    System.out.println("Timeout must be a number");
                                }
                            }
                        } else {
                            System.out.println("Global config: " + key);
                        }
                    }
                } else if (line.startsWith("[") && line.endsWith("]")) {
                    System.out.println("Section: " + line.substring(1, line.length() - 1));
                }
            }
        }
    }
}
