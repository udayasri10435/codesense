import json
import csv
import logging

def process_large_dataset(filepath, output_path, strict_mode=False, max_errors=100):
    """
    Simulates a messy data pipeline script with deep nesting,
    try-except blocks, and complex logic that increases cyclomatic complexity.
    """
    error_count = 0
    processed_data = []
    
    try:
        with open(filepath, 'r') as f:
            if filepath.endswith('.json'):
                data = json.load(f)
                for item in data:
                    if 'id' in item and 'value' in item:
                        if item['value'] is not None:
                            try:
                                val = float(item['value'])
                                if val > 1000:
                                    item['category'] = 'HIGH'
                                elif val > 500:
                                    item['category'] = 'MEDIUM'
                                elif val > 0:
                                    item['category'] = 'LOW'
                                else:
                                    item['category'] = 'INVALID'
                                    
                                if 'metadata' in item:
                                    if 'source' in item['metadata']:
                                        if item['metadata']['source'] == 'trusted':
                                            item['verified'] = True
                                        elif item['metadata']['source'] == 'untrusted':
                                            item['verified'] = False
                                        else:
                                            if strict_mode:
                                                raise ValueError("Unknown source")
                                            else:
                                                item['verified'] = None
                                                
                                processed_data.append(item)
                            except ValueError as e:
                                error_count += 1
                                if error_count > max_errors:
                                    logging.error("Too many errors, aborting.")
                                    break
                                continue
                        else:
                            if strict_mode:
                                logging.warning(f"Null value for ID {item['id']}")
                    else:
                        error_count += 1
            elif filepath.endswith('.csv'):
                reader = csv.DictReader(f)
                for row in reader:
                    if row.get('status') == 'ACTIVE':
                        if row.get('amount'):
                            try:
                                amt = float(row['amount'])
                                if amt < 0:
                                    if row.get('allow_negative') == 'true':
                                        processed_data.append(row)
                                    else:
                                        error_count += 1
                                else:
                                    processed_data.append(row)
                            except ValueError:
                                error_count += 1
                                if strict_mode:
                                    logging.error(f"Failed to parse amount in row: {row}")
                                    if error_count >= max_errors:
                                        break
                    elif row.get('status') == 'PENDING':
                        if row.get('priority') == 'HIGH':
                            processed_data.append(row)
                        else:
                            logging.info("Skipping low priority pending row")
                    else:
                        logging.debug("Ignoring row")
            else:
                logging.error("Unsupported file type")
                return False
                
        with open(output_path, 'w') as out_f:
            if output_path.endswith('.json'):
                json.dump(processed_data, out_f, indent=4)
            elif output_path.endswith('.csv'):
                if len(processed_data) > 0:
                    writer = csv.DictWriter(out_f, fieldnames=processed_data[0].keys())
                    writer.writeheader()
                    writer.writerows(processed_data)
                    
        return True
    except FileNotFoundError:
        logging.error(f"File not found: {filepath}")
        return False
    except Exception as e:
        logging.critical(f"Unhandled exception: {e}")
        return False
