// Tricky JS Sample file testing edge cases for CodeParser
// Stresses arrow functions, object methods, and template literals containing braces

const processUser = (user) => {
    const template = `User ID: ${user.id} {status: active}`;
    if (user && user.isActive) {
        console.log("Active user", template);
    }
};

function calculateTotal(items) {
    let total = 0;
    items.forEach(item => {
        if (item.price > 0) {
            total += item.price;
        }
    });
    return total;
}
