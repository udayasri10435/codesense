# 🎓 CodeSense Viva Defense Cheat Sheet (Exam Prep Guide)

> **Direct, plain-English answers for viva oral examination questioning.**  
> Memorize or review these key technical answers prior to project defense.

---

## Q1: How does `insert()` decide which rotation case applies (LL vs LR vs RR vs RL)?

**Answer to recite**:
In `AVLTree.java`, after standard BST insertion, height is updated bottom-up and the **Balance Factor (BF)** is calculated as:
$$\text{Balance Factor} = \text{Height}(\text{Left Subtree}) - \text{Height}(\text{Right Subtree})$$

An imbalance occurs when $|\text{BF}| > 1$. The 4 cases are selected as follows:

1. **Left-Left Case (LL) $\implies$ Single Right Rotation (`rotateRight`)**:
   * **Condition**: $\text{BF} > 1$ (left-heavy) AND `key < node.left.key` (new key inserted in left child's left subtree).
   * **Action**: Rotate current node right. The left child becomes the new root of the subtree.

2. **Right-Right Case (RR) $\implies$ Single Left Rotation (`rotateLeft`)**:
   * **Condition**: $\text{BF} < -1$ (right-heavy) AND `key > node.right.key` (new key inserted in right child's right subtree).
   * **Action**: Rotate current node left. The right child becomes the new root of the subtree.

3. **Left-Right Case (LR) $\implies$ Double Rotation (Left on left child, then Right on node)**:
   * **Condition**: $\text{BF} > 1$ (left-heavy) AND `key > node.left.key` (new key inserted in left child's right subtree).
   * **Action**: First rotate left child to the left, reducing it to an LL case, then rotate current node to the right.

4. **Right-Left Case (RL) $\implies$ Double Rotation (Right on right child, then Left on node)**:
   * **Condition**: $\text{BF} < -1$ (right-heavy) AND `key < node.right.key` (new key inserted in right child's left subtree).
   * **Action**: First rotate right child to the right, reducing it to an RR case, then rotate current node to the left.

---

## Q2: Why is `rangeSearch()` $O(\log N + K)$ rather than $O(N)$?

**Answer to recite**:
Because `rangeSearchRecursive()` uses logarithmic sub-tree pruning conditions to skip entire branches that cannot possibly contain keys in the target range $[minKey, maxKey]$:

```java
// 1. Only explore left subtree if current key is strictly greater than minKey
if (node.getKey() > minKey) {
    rangeSearchRecursive(node.getLeft(), minKey, maxKey, result);
}

// 2. Include payload if current key falls inside [minKey, maxKey]
if (node.getKey() >= minKey && node.getKey() <= maxKey) {
    result.addAll(node.getDataList());
}

// 3. Only explore right subtree if current key is strictly less than maxKey
if (node.getKey() < maxKey) {
    rangeSearchRecursive(node.getRight(), minKey, maxKey, result);
}
```

* **Traversing to range**: Takes $O(\log N)$ steps to navigate down the balanced AVL tree to the smallest key $\ge minKey$.
* **Collecting $K$ in-range items**: Takes $O(K)$ steps to visit only the $K$ nodes in the range.
* **Pruning**: Subtrees where all keys are $< minKey$ or $> maxKey$ are never visited, avoiding an $O(N)$ full table scan.

---

## Q3: What can the regex parser NOT handle, and why is that an acceptable tradeoff?

**Answer to recite**:
`CodeParser` is a lightweight lexical/structural analyzer, not a full compiler AST front-end. It does NOT handle:
1. Multi-line method parameter declarations split across lines before the opening `{`.
2. Complex nested lambdas or anonymous inner classes whose braces may shift method boundary counts.
3. Raw string literals or block comments containing `{` or `}` characters across line breaks.
4. Python code with non-standard mixed tab/space indentations.

**Why it's acceptable for this project's scope**:
Building a full multi-language compiler front-end (Java, Python, JS, C++) requires thousands of grammar rules (like ANTLR/Roslyn). For a code metrics analyzer targeting routine-level complexity, lightweight regex lexing extracts 95%+ of method signatures accurately, degrades gracefully without crashing, and allows zero-dependency execution.

---

## Q4: What are the actual empirical benchmark numbers?

**Answer to recite**:
When inserting $N = 10,000$ pre-sorted items (Ascending / Descending order):
* **Unbalanced BST**: Degenerates into a single linked list of **Height = 10,000** ($H = N$). Search time degrades to **1,476 - 2,638 nanoseconds** per lookup ($O(N)$ linear scan).
* **CodeSense AVL Tree**: Rotations keep the tree strictly balanced at **Height = 14** ($H \le 1.44 \log_2 N$). Search time stays bounded at **75 - 78 nanoseconds** per lookup ($O(\log N)$).

| N | Insertion Order | AVL Height | BST Height | AVL Search Latency | BST Search Latency |
|---|---|---|---|---|---|
| **10,000** | Ascending (Sorted) | **14** | **10,000** | **78.70 ns** | **1476.20 ns** |
| **10,000** | Descending | **14** | **10,000** | **75.20 ns** | **2638.70 ns** |
| **10,000** | Random | **16** | 30 | **82.00 ns** | **59.40 ns** |

*Conclusion*: Sorted code input causes an unbalanced BST to degrade to linear $O(N)$ search latency, whereas AVL balance factor rotations guarantee $O(\log N)$ latency under all input orderings.
