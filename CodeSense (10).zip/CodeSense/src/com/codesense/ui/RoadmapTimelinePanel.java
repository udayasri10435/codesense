package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.features.TechnicalDebtEstimator;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Interactive Refactoring Roadmap Timeline Panel.
 * Generates sprint-by-sprint refactoring plans and projected codebase health milestones.
 */
public class RoadmapTimelinePanel extends JPanel {

    private List<MethodMetrics> methods;

    public RoadmapTimelinePanel() {
        this.methods = new ArrayList<>();
        setBackground(BG_OBSIDIAN);
    }

    public void setMethods(List<MethodMetrics> methods) {
        this.methods = methods != null ? methods : new ArrayList<>();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        if (methods == null || methods.isEmpty()) {
            g2d.setColor(TEXT_MUTED);
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 15));
            String msg = "No routines loaded. Run a Workspace Scan to generate Refactoring Roadmap Timeline.";
            FontMetrics fm = g2d.getFontMetrics();
            g2d.drawString(msg, (width - fm.stringWidth(msg)) / 2, height / 2);
            return;
        }

        // Header Title
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 13));
        g2d.setColor(ACCENT_CYAN);
        g2d.drawString("📅 Refactoring Roadmap & Sprint Remediation Timeline", 20, 30);

        List<MethodMetrics> highRisk = new ArrayList<>();
        for (MethodMetrics m : methods) {
            if (m.getRiskLevel() == MethodMetrics.RiskLevel.CRITICAL || m.getRiskLevel() == MethodMetrics.RiskLevel.HIGH) {
                highRisk.add(m);
            }
        }

        int startX = 40;
        int startY = 70;
        int cardWidth = width - 80;

        // Sprint 1: Critical Targets (Weeks 1-2)
        drawSprintCard(g2d, startX, startY, cardWidth, 110, "SPRINT 1 (Weeks 1-2): Emergency Critical Refactoring",
                highRisk, ACCENT_RED, "Remediate Cyclomatic Overload & Nested Branching");

        // Sprint 2: High Risk Targets (Weeks 3-4)
        drawSprintCard(g2d, startX, startY + 130, cardWidth, 110, "SPRINT 2 (Weeks 3-4): Maintainability & Guard Clauses",
                methods, ACCENT_AMBER, "Inject Early Return Guard Clauses & Decompose Medium Routines");

        // Sprint 3: Fine-Tuning & Test Suite Generation (Weeks 5-6)
        drawSprintCard(g2d, startX, startY + 260, cardWidth, 110, "SPRINT 3 (Weeks 5-6): JUnit 5 Test Harness & CI/CD Gates",
                methods, ACCENT_EMERALD, "Generate Automated Regression Unit Tests & Enforce Quality Gates");
    }

    private void drawSprintCard(Graphics2D g2d, int x, int y, int w, int h, String title, List<MethodMetrics> list, Color accent, String goal) {
        g2d.setColor(PANEL_SLATE);
        g2d.fillRoundRect(x, y, w, h, 10, 10);
        g2d.setColor(BORDER_DARK);
        g2d.drawRoundRect(x, y, w, h, 10, 10);

        g2d.setColor(accent);
        g2d.fillRect(x, y, 6, h);

        g2d.setFont(new Font("Segoe UI", Font.BOLD, 13));
        g2d.setColor(TEXT_BRIGHT);
        g2d.drawString(title, x + 20, y + 26);

        g2d.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        g2d.setColor(TEXT_MUTED);
        g2d.drawString("🎯 Goal: " + goal, x + 20, y + 48);

        double estHours = Math.max(4.0, list.size() * 2.5);
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 12));
        g2d.setColor(ACCENT_CYAN);
        g2d.drawString(String.format("Estimated Effort: %.1f person-hours | Target Routines: %d methods", estHours, list.size()), x + 20, y + 78);
    }
}
