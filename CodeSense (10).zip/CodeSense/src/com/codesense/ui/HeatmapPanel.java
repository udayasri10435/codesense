package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Structural Complexity Treemap Heatmap Visualizer.
 * Renders method tiles sized by Lines of Code and color-coded by Risk Tier.
 */
public class HeatmapPanel extends JPanel {

    private List<MethodMetrics> methods;
    private MethodMetrics hoveredMethod = null;

    public HeatmapPanel() {
        this.methods = new ArrayList<>();
        setBackground(BG_OBSIDIAN);
        setToolTipText("Hover over tiles to inspect metrics");

        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                MethodMetrics m = findTileAt(e.getX(), e.getY());
                if (m != hoveredMethod) {
                    hoveredMethod = m;
                    repaint();
                }
            }
        });
    }

    public void setMethods(List<MethodMetrics> methods) {
        this.methods = methods != null ? methods : new ArrayList<>();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        if (methods == null || methods.isEmpty()) {
            g2d.setColor(TEXT_MUTED);
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 15));
            String msg = "No routines loaded. Run a Workspace Scan to render Complexity Treemap Heatmap.";
            FontMetrics fm = g2d.getFontMetrics();
            g2d.drawString(msg, (width - fm.stringWidth(msg)) / 2, height / 2);
            return;
        }

        // Header Title
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 13));
        g2d.setColor(ACCENT_CYAN);
        g2d.drawString("🗺️ Codebase Structural Complexity Heatmap (Tile Size = LOC, Tile Color = Risk Level)", 20, 30);

        // Render Heatmap Matrix Tiles
        int startX = 20;
        int startY = 55;
        int maxW = width - 40;

        int currX = startX;
        int currY = startY;
        int rowMaxH = 0;

        for (MethodMetrics m : methods) {
            int tileW = Math.max(140, Math.min(260, (m.getLinesOfCode() * 4) + 60));
            int tileH = 75;

            if (currX + tileW > maxW) {
                currX = startX;
                currY += rowMaxH + 12;
                rowMaxH = 0;
            }

            if (tileH > rowMaxH) rowMaxH = tileH;

            // Draw Tile
            Color tileColor = getRiskTileColor(m.getRiskLevel());

            if (hoveredMethod == m) {
                g2d.setColor(tileColor.brighter());
                g2d.fillRoundRect(currX, currY, tileW, tileH, 10, 10);
                g2d.setColor(Color.WHITE);
                g2d.setStroke(new BasicStroke(2.5f));
                g2d.drawRoundRect(currX, currY, tileW, tileH, 10, 10);
            } else {
                g2d.setColor(tileColor);
                g2d.fillRoundRect(currX, currY, tileW, tileH, 10, 10);
                g2d.setColor(BORDER_DARK);
                g2d.setStroke(new BasicStroke(1.2f));
                g2d.drawRoundRect(currX, currY, tileW, tileH, 10, 10);
            }

            // Tile Text
            g2d.setColor(Color.WHITE);
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 12));
            g2d.drawString(m.getMethodName() + "()", currX + 10, currY + 22);

            g2d.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            g2d.setColor(new Color(241, 245, 249));
            g2d.drawString(m.getClassName() + " | LOC: " + m.getLinesOfCode(), currX + 10, currY + 40);
            g2d.drawString(String.format("Score: %.2f | CC: %d", m.getComplexityScore(), m.getCyclomaticComplexity()), currX + 10, currY + 58);

            currX += tileW + 12;
        }
    }

    private MethodMetrics findTileAt(int mouseX, int mouseY) {
        if (methods == null || methods.isEmpty()) return null;

        int startX = 20;
        int startY = 55;
        int maxW = getWidth() - 40;

        int currX = startX;
        int currY = startY;
        int rowMaxH = 0;

        for (MethodMetrics m : methods) {
            int tileW = Math.max(140, Math.min(260, (m.getLinesOfCode() * 4) + 60));
            int tileH = 75;

            if (currX + tileW > maxW) {
                currX = startX;
                currY += rowMaxH + 12;
                rowMaxH = 0;
            }

            if (tileH > rowMaxH) rowMaxH = tileH;

            if (mouseX >= currX && mouseX <= currX + tileW && mouseY >= currY && mouseY <= currY + tileH) {
                return m;
            }

            currX += tileW + 12;
        }
        return null;
    }

    private Color getRiskTileColor(MethodMetrics.RiskLevel risk) {
        switch (risk) {
            case CRITICAL: return new Color(147, 51, 234); // Purple
            case HIGH:     return new Color(220, 38, 38);  // Red
            case MEDIUM:   return new Color(217, 119, 6);  // Amber
            case LOW:
            default:       return new Color(5, 150, 105);  // Emerald
        }
    }
}
