package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.*;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Class & Routine Code Quality Leaderboard Panel.
 * Ranks codebase components by architectural health score.
 */
public class LeaderboardPanel extends JPanel {

    private final JTable leaderboardTable;
    private final DefaultTableModel leaderboardTableModel;

    public LeaderboardPanel() {
        setLayout(new BorderLayout());
        setBackground(PANEL_SLATE);

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(CARD_NAVY);
        header.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));

        JLabel title = new JLabel("🏅 Class Architectural Quality & Hygiene Leaderboard");
        title.setFont(new Font("Segoe UI", Font.BOLD, 13));
        title.setForeground(ACCENT_CYAN);
        header.add(title, BorderLayout.WEST);

        add(header, BorderLayout.NORTH);

        // Table
        String[] cols = {"Rank", "Class Name", "Routines Count", "Total LOC", "Avg Complexity", "Avg MI (100)", "Hygiene Grade", "Status Category"};
        leaderboardTableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        leaderboardTable = new JTable(leaderboardTableModel);
        applyDarkTableStyle(leaderboardTable);

        JScrollPane sp = new JScrollPane(leaderboardTable);
        sp.getViewport().setBackground(PANEL_SLATE);
        sp.setBorder(BorderFactory.createEmptyBorder());

        add(sp, BorderLayout.CENTER);
    }

    public void updateLeaderboard(List<MethodMetrics> methods) {
        leaderboardTableModel.setRowCount(0);
        if (methods == null || methods.isEmpty()) return;

        Map<String, List<MethodMetrics>> classMap = new HashMap<>();
        for (MethodMetrics m : methods) {
            classMap.computeIfAbsent(m.getClassName(), k -> new ArrayList<>()).add(m);
        }

        List<ClassStats> statsList = new ArrayList<>();
        for (Map.Entry<String, List<MethodMetrics>> entry : classMap.entrySet()) {
            String className = entry.getKey();
            List<MethodMetrics> list = entry.getValue();

            int loc = 0;
            double sumScore = 0;
            double sumMi = 0;

            for (MethodMetrics m : list) {
                loc += m.getLinesOfCode();
                sumScore += m.getComplexityScore();
                sumMi += m.getMaintainabilityIndex();
            }

            double avgScore = sumScore / list.size();
            double avgMi = sumMi / list.size();

            statsList.add(new ClassStats(className, list.size(), loc, avgScore, avgMi));
        }

        statsList.sort((a, b) -> Double.compare(a.avgScore, b.avgScore)); // Lower complexity = better rank

        int rank = 1;
        for (ClassStats cs : statsList) {
            String grade = "A+";
            String cat = "Pristine Architecture";
            if (cs.avgScore > 40) { grade = "F"; cat = "Critical Structural Risk"; }
            else if (cs.avgScore > 25) { grade = "D"; cat = "Refactoring Required"; }
            else if (cs.avgScore > 15) { grade = "C"; cat = "Moderate Complexity"; }
            else if (cs.avgScore > 8) { grade = "B"; cat = "Good Clean Code"; }

            leaderboardTableModel.addRow(new Object[]{
                    "#" + rank++,
                    cs.className,
                    cs.methodCount,
                    cs.totalLoc,
                    String.format("%.2f", cs.avgScore),
                    String.format("%.1f", cs.avgMi),
                    grade,
                    cat
            });
        }
    }

    private static class ClassStats {
        String className;
        int methodCount;
        int totalLoc;
        double avgScore;
        double avgMi;

        ClassStats(String className, int methodCount, int totalLoc, double avgScore, double avgMi) {
            this.className = className;
            this.methodCount = methodCount;
            this.totalLoc = totalLoc;
            this.avgScore = avgScore;
            this.avgMi = avgMi;
        }
    }
}
