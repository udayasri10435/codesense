package com.codesense.ui;

import com.codesense.platform.license.LicenseManager;
import com.codesense.platform.license.LicensePayload;

import javax.swing.*;
import java.awt.*;
import java.net.URI;

import static com.codesense.ui.DarkThemeUtils.*;

public class LicenseActivationDialog extends JDialog {

    private static final String CODESENSE_STORE_URL = "https://codesence.netlify.app/";
    private final LicenseManager licenseManager;
    private final Runnable onLicenseChanged;

    public LicenseActivationDialog(JFrame parent, LicenseManager licenseManager, Runnable onLicenseChanged) {
        super(parent, "License & Subscription", true);
        this.licenseManager = licenseManager;
        this.onLicenseChanged = onLicenseChanged;

        setSize(450, 350);
        setLocationRelativeTo(parent);
        
        initUI();
    }

    private void initUI() {
        getContentPane().removeAll();
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BG_OBSIDIAN);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        // Info Panel
        JPanel infoPanel = new JPanel(new GridLayout(6, 1, 4, 4));
        infoPanel.setOpaque(false);
        
        LicensePayload license = licenseManager.getActiveLicense();
        String planText = licenseManager.getCurrentPlan().name();
        String statusText = (license != null && System.currentTimeMillis() < license.getExpiryDate()) ? "ACTIVE" : "FREE";
        
        JLabel title = new JLabel("CodeSense License");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(ACCENT_CYAN);
        
        JLabel planLbl = new JLabel("Plan: " + planText);
        planLbl.setForeground(TEXT_BRIGHT);
        
        JLabel statusLbl = new JLabel("Status: " + statusText);
        statusLbl.setForeground(TEXT_BRIGHT);

        infoPanel.add(title);
        infoPanel.add(planLbl);
        infoPanel.add(statusLbl);

        if (license != null) {
            JLabel idLbl = new JLabel("License ID: " + license.getSerialCode().substring(0, 15) + "...");
            idLbl.setForeground(TEXT_MUTED);
            infoPanel.add(idLbl);
        }
        
        panel.add(infoPanel, BorderLayout.NORTH);

        // Input Panel
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));
        inputPanel.setOpaque(false);
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        
        JLabel lbl = new JLabel("Enter your purchased serial code:");
        lbl.setForeground(TEXT_BRIGHT);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JTextField serialField = new JTextField();
        serialField.setBackground(INPUT_DARK);
        serialField.setForeground(TEXT_BRIGHT);
        serialField.setCaretColor(Color.WHITE);
        serialField.setPreferredSize(new Dimension(400, 32));
        serialField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        serialField.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        inputPanel.add(lbl);
        inputPanel.add(Box.createVerticalStrut(8));
        inputPanel.add(serialField);
        
        panel.add(inputPanel, BorderLayout.CENTER);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.setOpaque(false);
        
        CustomDarkButton buyBtn = new CustomDarkButton("Buy a License", ACCENT_AMBER, Color.WHITE);
        buyBtn.addActionListener(e -> {
            try {
                Desktop.getDesktop().browse(new URI(CODESENSE_STORE_URL));
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        CustomDarkButton deactivateBtn = new CustomDarkButton("Deactivate", BORDER_DARK, TEXT_BRIGHT);
        deactivateBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Deactivate CodeSense on this device?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                licenseManager.deactivate();
                onLicenseChanged.run();
                initUI();
            }
        });
        
        CustomDarkButton activateBtn = new CustomDarkButton("Activate", ACCENT_BLUE, Color.WHITE);
        activateBtn.addActionListener(e -> {
            String code = serialField.getText().trim();
            if (licenseManager.activate(code)) {
                JOptionPane.showMessageDialog(this, "License Activated Successfully!\nPlan: " + licenseManager.getCurrentPlan());
                onLicenseChanged.run();
                initUI();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid CodeSense serial code.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnPanel.add(buyBtn);
        if (license != null) {
            btnPanel.add(deactivateBtn);
        }
        btnPanel.add(activateBtn);
        
        panel.add(btnPanel, BorderLayout.SOUTH);

        add(panel);
        revalidate();
        repaint();
    }
}
