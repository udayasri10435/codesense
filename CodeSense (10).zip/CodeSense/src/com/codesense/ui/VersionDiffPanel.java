package com.codesense.ui;

import com.codesense.features.CodebaseDiffEngine;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Version Diffing UI Panel for comparing two codebase revisions side-by-side.
 */
public class VersionDiffPanel extends JPanel {

    private final JTextField basePathField;
    private final JTextField targetPathField;
    private final JLabel addedLabel;
    private final JLabel removedLabel;
    private final JLabel modifiedLabel;
    private final JLabel netDeltaLabel;

    private final JTable diffTable;
    private final DefaultTableModel diffTableModel;

    public VersionDiffPanel() {
        setLayout(new BorderLayout());
        setBackground(PANEL_SLATE);

        // Control Header
        JPanel controlBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 10));
        controlBar.setBackground(CARD_NAVY);
        controlBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));

        JLabel baseLbl = new JLabel("Base Path (V1):");
        baseLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        baseLbl.setForeground(TEXT_BRIGHT);

        basePathField = new JTextField(22);
        basePathField.setFont(new Font("Consolas", Font.PLAIN, 12));
        basePathField.setText(new File("samples").getAbsolutePath());
        basePathField.setBackground(INPUT_DARK);
        basePathField.setForeground(ACCENT_CYAN);
        basePathField.setCaretColor(TEXT_BRIGHT);
        basePathField.setBorder(BorderFactory.createLineBorder(BORDER_DARK, 1));

        JLabel targetLbl = new JLabel("Target Path (V2):");
        targetLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        targetLbl.setForeground(TEXT_BRIGHT);

        targetPathField = new JTextField(22);
        targetPathField.setFont(new Font("Consolas", Font.PLAIN, 12));
        targetPathField.setText(new File("samples").getAbsolutePath());
        targetPathField.setBackground(INPUT_DARK);
        targetPathField.setForeground(ACCENT_CYAN);
        targetPathField.setCaretColor(TEXT_BRIGHT);
        targetPathField.setBorder(BorderFactory.createLineBorder(BORDER_DARK, 1));

        CustomDarkButton runDiffBtn = new CustomDarkButton("⚡ Run Version Diff", ACCENT_BLUE, Color.WHITE);
        runDiffBtn.addActionListener(e -> executeDiff());

        controlBar.add(baseLbl);
        controlBar.add(basePathField);
        controlBar.add(targetLbl);
        controlBar.add(targetPathField);
        controlBar.add(runDiffBtn);

        // Summary Bar
        JPanel summaryBar = new JPanel(new GridLayout(1, 4, 12, 0));
        summaryBar.setOpaque(false);
        summaryBar.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        addedLabel = createCard(summaryBar, "Added Routines", "0", ACCENT_EMERALD);
        removedLabel = createCard(summaryBar, "Removed Routines", "0", ACCENT_RED);
        modifiedLabel = createCard(summaryBar, "Modified Routines", "0", ACCENT_AMBER);
        netDeltaLabel = createCard(summaryBar, "Net Avg Δ Complexity", "+0.00", ACCENT_CYAN);

        JPanel topContainer = new JPanel(new BorderLayout());
        topContainer.setOpaque(false);
        topContainer.add(controlBar, BorderLayout.NORTH);
        topContainer.add(summaryBar, BorderLayout.SOUTH);

        add(topContainer, BorderLayout.NORTH);

        // Diff Table
        String[] cols = {"Status", "Routine Target", "Base Score (V1)", "Target Score (V2)", "Score Delta (ΔS)", "CC Delta (ΔCC)", "MI Delta (ΔMI)"};
        diffTableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        diffTable = new JTable(diffTableModel);
        applyDarkTableStyle(diffTable);

        JScrollPane sp = new JScrollPane(diffTable);
        sp.getViewport().setBackground(PANEL_SLATE);
        sp.setBorder(BorderFactory.createEmptyBorder());

        add(sp, BorderLayout.CENTER);
    }

    private JLabel createCard(JPanel container, String title, String initVal, Color color) {
        JPanel card = new JPanel(new BorderLayout(4, 4));
        card.setBackground(CARD_NAVY);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(3, 0, 0, 0, color),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_DARK, 1),
                        BorderFactory.createEmptyBorder(8, 10, 8, 10)
                )
        ));

        JLabel tLbl = new JLabel(title);
        tLbl.setFont(new Font("Segoe UI", Font.BOLD, 10));
        tLbl.setForeground(TEXT_MUTED);

        JLabel vLbl = new JLabel(initVal);
        vLbl.setFont(new Font("Segoe UI", Font.BOLD, 16));
        vLbl.setForeground(color);

        card.add(tLbl, BorderLayout.NORTH);
        card.add(vLbl, BorderLayout.CENTER);
        container.add(card);
        return vLbl;
    }

    private void executeDiff() {
        File base = new File(basePathField.getText().trim());
        File target = new File(targetPathField.getText().trim());

        if (!base.exists() || !target.exists()) {
            JOptionPane.showMessageDialog(this, "Base or Target path does not exist.", "Diff Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        CodebaseDiffEngine.DiffResult res = CodebaseDiffEngine.compareWorkspaces(base, target);

        addedLabel.setText(String.valueOf(res.getAddedCount()));
        removedLabel.setText(String.valueOf(res.getRemovedCount()));
        modifiedLabel.setText(String.valueOf(res.getModifiedCount()));
        netDeltaLabel.setText(String.format("%+.2f", res.getNetAvgScoreDelta()));

        diffTableModel.setRowCount(0);
        for (CodebaseDiffEngine.MethodDiff d : res.getDiffList()) {
            String baseScore = d.getBaseMetrics() != null ? String.format("%.2f", d.getBaseMetrics().getComplexityScore()) : "N/A";
            String targetScore = d.getTargetMetrics() != null ? String.format("%.2f", d.getTargetMetrics().getComplexityScore()) : "N/A";

            diffTableModel.addRow(new Object[]{
                    d.getStatus(),
                    d.getRoutineKey() + "()",
                    baseScore,
                    targetScore,
                    String.format("%+.2f", d.getScoreDelta()),
                    String.format("%+d", d.getCcDelta()),
                    String.format("%+.1f", d.getMiDelta())
            });
        }
    }
}
