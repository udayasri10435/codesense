package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.ds.AVLTree;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Interactive AVL Tree Data Structure Simulator & Algorithm Playground.
 * Allows users to insert custom keys, watch self-balancing rotations live,
 * and test logarithmic search boundaries interactively.
 */
public class AVLPlaygroundPanel extends JPanel {

    private final AVLTree<MethodMetrics> simTree;
    private final AVLTreeCanvas simCanvas;
    private final JSpinner keySpinner;
    private final JTextArea simLogArea;
    private final Random random;

    public AVLPlaygroundPanel() {
        setLayout(new BorderLayout());
        setBackground(PANEL_SLATE);
        this.simTree = new AVLTree<>();
        this.random = new Random();

        // Header Control Bar
        JPanel controlBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 10));
        controlBar.setBackground(CARD_NAVY);
        controlBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));

        JLabel keyLbl = new JLabel("Key Value:");
        keyLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        keyLbl.setForeground(TEXT_BRIGHT);

        keySpinner = new JSpinner(new SpinnerNumberModel(15.0, 1.0, 1000.0, 1.0));
        applyDarkSpinnerStyle(keySpinner);

        CustomDarkButton insertBtn = new CustomDarkButton("➕ Insert Key", ACCENT_BLUE, Color.WHITE);
        insertBtn.addActionListener(e -> insertCustomKey());

        CustomDarkButton randomStreamBtn = new CustomDarkButton("🎲 Insert 5 Random Keys", ACCENT_PURPLE, Color.WHITE);
        randomStreamBtn.addActionListener(e -> insertRandomKeys(5));

        CustomDarkButton clearBtn = new CustomDarkButton("🗑️ Clear Tree", ACCENT_RED, Color.WHITE);
        clearBtn.addActionListener(e -> clearSimTree());

        controlBar.add(keyLbl);
        controlBar.add(keySpinner);
        controlBar.add(insertBtn);
        controlBar.add(randomStreamBtn);
        controlBar.add(clearBtn);

        add(controlBar, BorderLayout.NORTH);

        // Center View (Left: Canvas | Right: Live Rotation Log)
        JPanel mainContent = new JPanel(new BorderLayout());
        mainContent.setOpaque(false);

        simCanvas = new AVLTreeCanvas();
        simCanvas.setTree(simTree);

        // Rotation Log
        JPanel logContainer = new JPanel(new BorderLayout());
        logContainer.setPreferredSize(new Dimension(320, 0));
        logContainer.setBackground(CARD_NAVY);
        logContainer.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, BORDER_DARK));

        JLabel logTitle = new JLabel(" 🔄 Live Rotation Event Log:");
        logTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        logTitle.setForeground(ACCENT_EMERALD);
        logTitle.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        simLogArea = new JTextArea();
        simLogArea.setEditable(false);
        simLogArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        simLogArea.setBackground(BG_OBSIDIAN);
        simLogArea.setForeground(ACCENT_EMERALD);
        simLogArea.setMargin(new Insets(8, 8, 8, 8));

        logContainer.add(logTitle, BorderLayout.NORTH);
        logContainer.add(new JScrollPane(simLogArea), BorderLayout.CENTER);

        mainContent.add(simCanvas, BorderLayout.CENTER);
        mainContent.add(logContainer, BorderLayout.EAST);

        add(mainContent, BorderLayout.CENTER);

        // Seed initial sample nodes into simulator
        insertRandomKeys(4);
    }

    private void insertCustomKey() {
        double key = ((Number) keySpinner.getValue()).doubleValue();
        MethodMetrics dummy = new MethodMetrics("node_" + (simTree.getSize() + 1), "SimClass", "sim.java", 1, 10, 1, 1, 1, 10, 0);
        simTree.insert(key, dummy);
        updateSimView();
    }

    private void insertRandomKeys(int count) {
        for (int i = 0; i < count; i++) {
            double key = Math.round((1.0 + random.nextDouble() * 99.0) * 10.0) / 10.0;
            MethodMetrics dummy = new MethodMetrics("routine_" + (simTree.getSize() + 1), "SimClass", "sim.java", 1, 10, 1, 1, 1, 10, 0);
            simTree.insert(key, dummy);
        }
        updateSimView();
    }

    private void clearSimTree() {
        simTree.clear();
        updateSimView();
    }

    private void updateSimView() {
        simCanvas.setTree(simTree);
        StringBuilder logs = new StringBuilder();
        logs.append("Tree Size: ").append(simTree.getSize()).append(" nodes\n");
        logs.append("Tree Height: ").append(simTree.getHeight()).append("\n");
        logs.append("Total Rotations: ").append(simTree.getTotalRotations()).append("\n\n");

        for (String log : simTree.getRotationLogs()) {
            logs.append("▸ ").append(log).append("\n");
        }
        if (simTree.getRotationLogs().isEmpty()) {
            logs.append("No rotations performed yet.\n");
        }
        simLogArea.setText(logs.toString());
    }
}
