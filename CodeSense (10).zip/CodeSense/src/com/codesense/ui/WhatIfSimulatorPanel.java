package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.analyzer.WorkspaceScanner;

import javax.swing.*;
import java.awt.*;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Interactive What-If Refactoring Impact Simulator.
 * Simulates real-time codebase health score and technical debt reduction when refactoring methods.
 */
public class WhatIfSimulatorPanel extends JPanel {

    private final JSlider ccReductionSlider;
    private final JSlider nestingReductionSlider;
    private final JSlider methodSplitSlider;

    private final JLabel currentHealthLabel;
    private final JLabel predictedHealthLabel;
    private final JLabel currentDebtLabel;
    private final JLabel predictedDebtLabel;

    private WorkspaceScanner.ScanResult currentScan;

    public WhatIfSimulatorPanel() {
        setLayout(new BorderLayout());
        setBackground(PANEL_SLATE);

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(CARD_NAVY);
        header.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));

        JLabel title = new JLabel("🔮 What-If Refactoring Impact Simulator");
        title.setFont(new Font("Segoe UI", Font.BOLD, 13));
        title.setForeground(ACCENT_CYAN);
        header.add(title, BorderLayout.WEST);

        add(header, BorderLayout.NORTH);

        // Main Content
        JPanel content = new JPanel(new GridLayout(1, 2, 16, 0));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        // Left Controls Panel
        JPanel controlsCard = new JPanel(new GridLayout(6, 1, 0, 12));
        controlsCard.setBackground(CARD_NAVY);
        controlsCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_DARK, 1),
                BorderFactory.createEmptyBorder(16, 16, 16, 16)
        ));

        JLabel cTitle = new JLabel("⚙️ Adjust Refactoring Target Sliders:");
        cTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        cTitle.setForeground(ACCENT_CYAN);
        controlsCard.add(cTitle);

        ccReductionSlider = createSlider("Target Cyclomatic Complexity Reduction (%)", 0, 80, 25);
        nestingReductionSlider = createSlider("Max Nesting Depth Reduction (Levels)", 0, 4, 2);
        methodSplitSlider = createSlider("Monolithic Routine Decompositions (Methods Split)", 0, 10, 3);

        controlsCard.add(ccReductionSlider.getParent());
        controlsCard.add(nestingReductionSlider.getParent());
        controlsCard.add(methodSplitSlider.getParent());

        // Right Results Panel
        JPanel resultsCard = new JPanel(new GridLayout(2, 2, 12, 12));
        resultsCard.setOpaque(false);

        currentHealthLabel = createStatBox(resultsCard, "CURRENT HEALTH SCORE", "100%", ACCENT_AMBER);
        predictedHealthLabel = createStatBox(resultsCard, "PREDICTED HEALTH SCORE", "100%", ACCENT_EMERALD);
        currentDebtLabel = createStatBox(resultsCard, "CURRENT TECH DEBT", "0.0h", ACCENT_RED);
        predictedDebtLabel = createStatBox(resultsCard, "PREDICTED TECH DEBT", "0.0h", ACCENT_CYAN);

        content.add(controlsCard);
        content.add(resultsCard);

        add(content, BorderLayout.CENTER);
    }

    private JSlider createSlider(String labelText, int min, int max, int val) {
        JPanel box = new JPanel(new BorderLayout(0, 4));
        box.setOpaque(false);

        JLabel lbl = new JLabel(labelText);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lbl.setForeground(TEXT_BRIGHT);

        JSlider slider = new JSlider(min, max, val);
        slider.setBackground(CARD_NAVY);
        slider.setForeground(ACCENT_CYAN);
        slider.setMajorTickSpacing((max - min) / 2);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);

        slider.addChangeListener(e -> recalculateSimulation());

        box.add(lbl, BorderLayout.NORTH);
        box.add(slider, BorderLayout.CENTER);
        return slider;
    }

    private JLabel createStatBox(JPanel container, String title, String val, Color color) {
        JPanel card = new JPanel(new BorderLayout(6, 6));
        card.setBackground(CARD_NAVY);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(3, 0, 0, 0, color),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_DARK, 1),
                        BorderFactory.createEmptyBorder(16, 16, 16, 16)
                )
        ));

        JLabel tLbl = new JLabel(title);
        tLbl.setFont(new Font("Segoe UI", Font.BOLD, 10));
        tLbl.setForeground(TEXT_MUTED);

        JLabel vLbl = new JLabel(val);
        vLbl.setFont(new Font("Segoe UI", Font.BOLD, 22));
        vLbl.setForeground(color);

        card.add(tLbl, BorderLayout.NORTH);
        card.add(vLbl, BorderLayout.CENTER);
        container.add(card);
        return vLbl;
    }

    public void updateData(WorkspaceScanner.ScanResult scan) {
        this.currentScan = scan;
        recalculateSimulation();
    }

    private void recalculateSimulation() {
        if (currentScan == null || currentScan.getAllMethods().isEmpty()) return;

        double ccPct = ccReductionSlider.getValue() / 100.0;
        int nestingDec = nestingReductionSlider.getValue();
        int splits = methodSplitSlider.getValue();

        List<MethodMetrics> methods = currentScan.getAllMethods();
        double currentSumScore = 0;
        double predictedSumScore = 0;

        for (MethodMetrics m : methods) {
            double origScore = m.getComplexityScore();
            currentSumScore += origScore;

            double newCc = Math.max(1, m.getCyclomaticComplexity() * (1.0 - ccPct));
            double newCog = Math.max(1, m.getCognitiveComplexity() * (1.0 - ccPct * 1.2));
            double newMnd = Math.max(1, m.getMaxNestingDepth() - nestingDec);

            double newScore = (newCc * 1.8) + (newCog * 1.2) + (newMnd * 2.5);
            predictedSumScore += newScore;
        }

        double origAvg = currentSumScore / methods.size();
        double predAvg = predictedSumScore / methods.size();

        double origHealth = Math.max(10.0, 100.0 - (origAvg * 1.8));
        double predHealth = Math.min(100.0, Math.max(10.0, 100.0 - (predAvg * 1.8) + (splits * 1.5)));

        double origDebt = Math.max(0, (origAvg - 8.0) * methods.size() * 0.45);
        double predDebt = Math.max(0, (predAvg - 8.0) * methods.size() * 0.45);

        currentHealthLabel.setText(String.format("%.0f%%", origHealth));
        predictedHealthLabel.setText(String.format("%.0f%% (+%.0f%%)", predHealth, Math.max(0, predHealth - origHealth)));
        currentDebtLabel.setText(String.format("%.1fh", origDebt));
        predictedDebtLabel.setText(String.format("%.1fh (-%.1fh)", predDebt, Math.max(0, origDebt - predDebt)));
    }
}
