package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.features.RefactoringAssistant;

import javax.swing.*;
import java.awt.*;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Side-by-Side Code Refactoring Diff Viewer.
 * Renders original method source vs refactored clean routine template.
 */
public class CodeDiffViewerPanel extends JPanel {

    private final JLabel headerTitle;
    private final JTextArea originalCodeArea;
    private final JTextArea refactoredCodeArea;

    public CodeDiffViewerPanel() {
        setLayout(new BorderLayout());
        setBackground(PANEL_SLATE);

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(CARD_NAVY);
        header.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));

        headerTitle = new JLabel("🔍 Side-by-Side Refactoring Diff (Select a routine from the Index to compare)");
        headerTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        headerTitle.setForeground(ACCENT_CYAN);
        header.add(headerTitle, BorderLayout.WEST);

        add(header, BorderLayout.NORTH);

        // Split View
        JPanel splitContainer = new JPanel(new GridLayout(1, 2, 12, 0));
        splitContainer.setOpaque(false);
        splitContainer.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        // Original Code Pane
        JPanel leftPane = new JPanel(new BorderLayout());
        leftPane.setBackground(CARD_NAVY);
        leftPane.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_DARK, 1),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));

        JLabel leftLbl = new JLabel("❌ Original High-Complexity Implementation:");
        leftLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        leftLbl.setForeground(ACCENT_RED);

        originalCodeArea = new JTextArea();
        originalCodeArea.setEditable(false);
        originalCodeArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        originalCodeArea.setBackground(BG_OBSIDIAN);
        originalCodeArea.setForeground(ACCENT_RED);
        originalCodeArea.setMargin(new Insets(8, 8, 8, 8));

        leftPane.add(leftLbl, BorderLayout.NORTH);
        leftPane.add(new JScrollPane(originalCodeArea), BorderLayout.CENTER);

        // Refactored Code Pane
        JPanel rightPane = new JPanel(new BorderLayout());
        rightPane.setBackground(CARD_NAVY);
        rightPane.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_DARK, 1),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));

        JLabel rightLbl = new JLabel("✨ Clean Refactored Design (Guard Clauses & Flattened Nesting):");
        rightLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        rightLbl.setForeground(ACCENT_EMERALD);

        refactoredCodeArea = new JTextArea();
        refactoredCodeArea.setEditable(false);
        refactoredCodeArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        refactoredCodeArea.setBackground(BG_OBSIDIAN);
        refactoredCodeArea.setForeground(ACCENT_EMERALD);
        refactoredCodeArea.setMargin(new Insets(8, 8, 8, 8));

        rightPane.add(rightLbl, BorderLayout.NORTH);
        rightPane.add(new JScrollPane(refactoredCodeArea), BorderLayout.CENTER);

        splitContainer.add(leftPane);
        splitContainer.add(rightPane);

        add(splitContainer, BorderLayout.CENTER);
    }

    public void loadDiff(MethodMetrics m) {
        if (m == null) return;
        headerTitle.setText("🔍 Side-by-Side Refactoring Diff: " + m.getClassName() + "." + m.getMethodName() + "() [Original Score: " + String.format("%.2f", m.getComplexityScore()) + "]");

        originalCodeArea.setText("// Original Routine (CC=" + m.getCyclomaticComplexity() + ", Nesting=" + m.getMaxNestingDepth() + ")\n" +
                "// Class: " + m.getClassName() + "\n\n" +
                "public void " + m.getMethodName() + "() {\n" +
                "    // Monolithic implementation with nested loops/conditionals...\n" +
                "}");

        RefactoringAssistant.RefactoringRecipe recipe = RefactoringAssistant.generateRecipe(m);
        refactoredCodeArea.setText(recipe.getRefactoredCodeTemplate());
    }
}
