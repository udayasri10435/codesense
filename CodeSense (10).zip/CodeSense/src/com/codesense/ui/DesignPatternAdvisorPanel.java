package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Design Pattern Advisor Panel.
 * Recommends Gang of Four (GoF) design patterns to remediate complex code structures.
 */
public class DesignPatternAdvisorPanel extends JPanel {

    private List<MethodMetrics> methods;

    public DesignPatternAdvisorPanel() {
        this.methods = new ArrayList<>();
        setBackground(BG_OBSIDIAN);
    }

    public void setMethods(List<MethodMetrics> methods) {
        this.methods = methods != null ? methods : new ArrayList<>();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        if (methods == null || methods.isEmpty()) {
            g2d.setColor(TEXT_MUTED);
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 15));
            String msg = "No routines loaded. Run a Workspace Scan to view Design Pattern Recommendations.";
            FontMetrics fm = g2d.getFontMetrics();
            g2d.drawString(msg, (width - fm.stringWidth(msg)) / 2, height / 2);
            return;
        }

        // Header Title
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 13));
        g2d.setColor(ACCENT_CYAN);
        g2d.drawString("💡 Architectural Design Pattern Remediation Advisor", 20, 30);

        int startX = 40;
        int startY = 70;
        int cardWidth = width - 80;

        // Card 1: Strategy / Command Pattern
        drawPatternCard(g2d, startX, startY, cardWidth, 100, "1. Strategy / Command Pattern",
                "Replaces long switch statements and deeply nested if-else conditionals with polymorphic execution objects.", ACCENT_BLUE);

        // Card 2: State Pattern
        drawPatternCard(g2d, startX, startY + 120, cardWidth, 100, "2. State Pattern",
                "Encapsulates state-dependent behavior into separate state classes, eliminating nested state checks.", ACCENT_EMERALD);

        // Card 3: Extract Method / Compose Method
        drawPatternCard(g2d, startX, startY + 240, cardWidth, 100, "3. Extract Method & Early Return Guard Clauses",
                "Flattens deep indentation by returning early on invalid preconditions and delegating sub-tasks to helper methods.", ACCENT_PURPLE);
    }

    private void drawPatternCard(Graphics2D g2d, int x, int y, int w, int h, String title, String desc, Color accent) {
        g2d.setColor(PANEL_SLATE);
        g2d.fillRoundRect(x, y, w, h, 10, 10);
        g2d.setColor(BORDER_DARK);
        g2d.drawRoundRect(x, y, w, h, 10, 10);

        g2d.setColor(accent);
        g2d.fillRect(x, y, 6, h);

        g2d.setFont(new Font("Segoe UI", Font.BOLD, 13));
        g2d.setColor(TEXT_BRIGHT);
        g2d.drawString(title, x + 20, y + 26);

        g2d.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        g2d.setColor(TEXT_MUTED);
        g2d.drawString(desc, x + 20, y + 55);
    }
}
