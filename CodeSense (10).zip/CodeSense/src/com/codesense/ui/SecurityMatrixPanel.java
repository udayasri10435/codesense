package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Architectural Security Exposure & Attack Surface Matrix Panel.
 * Maps high-complexity routines to potential security vulnerability exposures.
 */
public class SecurityMatrixPanel extends JPanel {

    private List<MethodMetrics> methods;

    public SecurityMatrixPanel() {
        this.methods = new ArrayList<>();
        setBackground(BG_OBSIDIAN);
    }

    public void setMethods(List<MethodMetrics> methods) {
        this.methods = methods != null ? methods : new ArrayList<>();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        if (methods == null || methods.isEmpty()) {
            g2d.setColor(TEXT_MUTED);
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 15));
            String msg = "No routines loaded. Run a Workspace Scan to analyze Architectural Security Exposure.";
            FontMetrics fm = g2d.getFontMetrics();
            g2d.drawString(msg, (width - fm.stringWidth(msg)) / 2, height / 2);
            return;
        }

        // Header Title
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 13));
        g2d.setColor(ACCENT_CYAN);
        g2d.drawString("🛡️ Architectural Security & Vulnerability Exposure Matrix", 20, 30);

        int startX = 40;
        int startY = 70;
        int cardWidth = width - 80;

        List<MethodMetrics> secTargets = new ArrayList<>();
        for (MethodMetrics m : methods) {
            if (m.getCyclomaticComplexity() >= 5 || m.getParameterCount() >= 3) {
                secTargets.add(m);
            }
        }

        // Card 1: Parameter Exposure / Unsanitized Input Risk
        drawSecurityCard(g2d, startX, startY, cardWidth, 100, "1. Excessive Parameter Exposure & Input Surface",
                "Routines with 3+ parameters increase attack surface exposure. Ensure validation guard clauses.", ACCENT_RED);

        // Card 2: Nested Control Flow / Timing Side-Channel Risk
        drawSecurityCard(g2d, startX, startY + 120, cardWidth, 100, "2. Deeply Nested Loops & Timing Side-Channel Exposure",
                "Routines with 3+ nesting levels may create variable-time execution branches vulnerable to side-channel timing analysis.", ACCENT_AMBER);

        // Card 3: Maintainability Decay & Technical Debt Vulnerability
        drawSecurityCard(g2d, startX, startY + 240, cardWidth, 100, "3. Cognitive Overload & Security Audit Difficulty",
                "Monolithic methods with low Maintainability Index (< 50) impede security code audits and obscure flaw detection.", ACCENT_PURPLE);
    }

    private void drawSecurityCard(Graphics2D g2d, int x, int y, int w, int h, String title, String desc, Color accent) {
        g2d.setColor(PANEL_SLATE);
        g2d.fillRoundRect(x, y, w, h, 10, 10);
        g2d.setColor(BORDER_DARK);
        g2d.drawRoundRect(x, y, w, h, 10, 10);

        g2d.setColor(accent);
        g2d.fillRect(x, y, 6, h);

        g2d.setFont(new Font("Segoe UI", Font.BOLD, 13));
        g2d.setColor(TEXT_BRIGHT);
        g2d.drawString(title, x + 20, y + 26);

        g2d.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        g2d.setColor(TEXT_MUTED);
        g2d.drawString(desc, x + 20, y + 55);
    }
}
