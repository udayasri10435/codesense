package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Structural Architecture Radar / Spider Chart Visualizer.
 * Maps multi-dimensional software metrics on a polygonal radar axis.
 */
public class RadarChartPanel extends JPanel {

    private List<MethodMetrics> methods;

    public RadarChartPanel() {
        this.methods = new ArrayList<>();
        setBackground(BG_OBSIDIAN);
    }

    public void setMethods(List<MethodMetrics> methods) {
        this.methods = methods != null ? methods : new ArrayList<>();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        if (methods == null || methods.isEmpty()) {
            g2d.setColor(TEXT_MUTED);
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 15));
            String msg = "No routines loaded. Run a Workspace Scan to render Radar Architecture Chart.";
            FontMetrics fm = g2d.getFontMetrics();
            g2d.drawString(msg, (width - fm.stringWidth(msg)) / 2, height / 2);
            return;
        }

        // Header Title
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 13));
        g2d.setColor(ACCENT_CYAN);
        g2d.drawString("🕸️ Multi-Axis Architectural Complexity Radar Footprint", 20, 30);

        // Compute Metric Averages
        double avgCc = 0, avgCog = 0, avgMnd = 0, avgMi = 0, avgLoc = 0, avgParams = 0;
        for (MethodMetrics m : methods) {
            avgCc += m.getCyclomaticComplexity();
            avgCog += m.getCognitiveComplexity();
            avgMnd += m.getMaxNestingDepth();
            avgMi += m.getMaintainabilityIndex();
            avgLoc += m.getLinesOfCode();
            avgParams += m.getParameterCount();
        }
        int n = methods.size();
        avgCc /= n; avgCog /= n; avgMnd /= n; avgMi /= n; avgLoc /= n; avgParams /= n;

        // 6 Radar Axes: CC, Cognitive, Nesting, MI, LOC, Params
        String[] axisLabels = {
                "Cyclomatic CC (" + String.format("%.1f", avgCc) + ")",
                "Cognitive (" + String.format("%.1f", avgCog) + ")",
                "Max Nesting (" + String.format("%.1f", avgMnd) + ")",
                "Maintainability (" + String.format("%.1f", avgMi) + ")",
                "Routine LOC (" + String.format("%.1f", avgLoc) + ")",
                "Params (" + String.format("%.1f", avgParams) + ")"
        };

        // Scale factors (0.0 to 1.0)
        double[] currentValues = {
                Math.min(1.0, avgCc / 15.0),
                Math.min(1.0, avgCog / 25.0),
                Math.min(1.0, avgMnd / 5.0),
                Math.min(1.0, avgMi / 100.0),
                Math.min(1.0, avgLoc / 50.0),
                Math.min(1.0, avgParams / 5.0)
        };

        double[] idealValues = { 0.25, 0.20, 0.30, 0.85, 0.30, 0.30 }; // Ideal Baseline

        int centerX = width / 2;
        int centerY = height / 2 + 10;
        int radius = Math.min(width, height) / 3;

        int numAxes = axisLabels.length;

        // Draw Radar Concentric Web
        g2d.setStroke(new BasicStroke(1.2f));
        int steps = 4;
        for (int step = 1; step <= steps; step++) {
            int r = (radius * step) / steps;
            Polygon p = new Polygon();
            for (int i = 0; i < numAxes; i++) {
                double angle = (2 * Math.PI * i) / numAxes - Math.PI / 2;
                p.addPoint(centerX + (int) (r * Math.cos(angle)), centerY + (int) (r * Math.sin(angle)));
            }
            g2d.setColor(new Color(51, 65, 85, 120));
            g2d.drawPolygon(p);
        }

        // Draw Axes Lines & Labels
        Polygon currentPoly = new Polygon();
        Polygon idealPoly = new Polygon();

        for (int i = 0; i < numAxes; i++) {
            double angle = (2 * Math.PI * i) / numAxes - Math.PI / 2;
            int xEnd = centerX + (int) (radius * Math.cos(angle));
            int yEnd = centerY + (int) (radius * Math.sin(angle));

            g2d.setColor(new Color(71, 85, 105));
            g2d.drawLine(centerX, centerY, xEnd, yEnd);

            // Add Polygon points
            int cx = centerX + (int) (radius * currentValues[i] * Math.cos(angle));
            int cy = centerY + (int) (radius * currentValues[i] * Math.sin(angle));
            currentPoly.addPoint(cx, cy);

            int ix = centerX + (int) (radius * idealValues[i] * Math.cos(angle));
            int iy = centerY + (int) (radius * idealValues[i] * Math.sin(angle));
            idealPoly.addPoint(ix, iy);

            // Label text
            g2d.setColor(TEXT_BRIGHT);
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 11));
            FontMetrics fm = g2d.getFontMetrics();
            int lx = centerX + (int) ((radius + 30) * Math.cos(angle)) - (fm.stringWidth(axisLabels[i]) / 2);
            int ly = centerY + (int) ((radius + 30) * Math.sin(angle)) + 4;
            g2d.drawString(axisLabels[i], lx, ly);
        }

        // Draw Ideal Baseline Polygon (Green dashed outline)
        g2d.setColor(new Color(52, 211, 153, 50));
        g2d.fillPolygon(idealPoly);
        g2d.setColor(ACCENT_EMERALD);
        g2d.setStroke(new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 0, new float[]{6}, 0));
        g2d.drawPolygon(idealPoly);

        // Draw Current Codebase Polygon (Cyan filled)
        g2d.setColor(new Color(56, 189, 248, 80));
        g2d.fillPolygon(currentPoly);
        g2d.setColor(ACCENT_CYAN);
        g2d.setStroke(new BasicStroke(2.5f));
        g2d.drawPolygon(currentPoly);

        // Legend
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 12));
        g2d.setColor(ACCENT_CYAN);
        g2d.drawString("● Current Codebase Footprint", width - 260, height - 35);
        g2d.setColor(ACCENT_EMERALD);
        g2d.drawString("-- Ideal Design Baseline", width - 260, height - 15);
    }
}
