package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.features.RefactoringAssistant;
import com.codesense.features.UnitTestGenerator;

import javax.swing.*;
import java.awt.*;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Automated Refactoring Assistant Panel displaying refactoring recipes,
 * code pattern transformations, predicted metrics gains, and automated JUnit 5 test generation.
 */
public class RefactorAssistantPanel extends JPanel {

    private final JLabel routineTitleLabel;
    private final JLabel origCcLabel;
    private final JLabel origCogLabel;
    private final JLabel origMndLabel;
    private final JLabel origMiLabel;
    private final JLabel origScoreLabel;

    private final JLabel predCcLabel;
    private final JLabel predCogLabel;
    private final JLabel predMndLabel;
    private final JLabel predMiLabel;
    private final JLabel predScoreLabel;

    private final JTextArea guideArea;
    private final JTextArea codeTemplateArea;
    private final CustomDarkButton genTestBtn;

    private MethodMetrics currentMethod;

    public RefactorAssistantPanel() {
        setLayout(new BorderLayout());
        setBackground(PANEL_SLATE);

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(CARD_NAVY);
        header.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));

        routineTitleLabel = new JLabel("🛠️ Automated Refactoring Assistant (Select a routine from the Index to generate recipe)");
        routineTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        routineTitleLabel.setForeground(ACCENT_CYAN);

        genTestBtn = new CustomDarkButton("🧪 Generate Refactoring Test Suite", ACCENT_PURPLE, Color.WHITE);
        genTestBtn.addActionListener(e -> generateTestSuite());

        header.add(routineTitleLabel, BorderLayout.WEST);
        header.add(genTestBtn, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);

        // Main Split Content
        JPanel mainContent = new JPanel(new GridLayout(1, 2, 12, 0));
        mainContent.setOpaque(false);
        mainContent.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        // Left Side: Metrics Impact Comparison & Steps
        JPanel leftPanel = new JPanel(new BorderLayout(0, 10));
        leftPanel.setOpaque(false);

        JPanel metricsComparisonGrid = new JPanel(new GridLayout(2, 5, 8, 8));
        metricsComparisonGrid.setBackground(CARD_NAVY);
        metricsComparisonGrid.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_DARK, 1),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));

        origCcLabel = createMetricCell(metricsComparisonGrid, "Original CC", "0", ACCENT_RED);
        origCogLabel = createMetricCell(metricsComparisonGrid, "Original Cog", "0", ACCENT_RED);
        origMndLabel = createMetricCell(metricsComparisonGrid, "Original MND", "0", ACCENT_RED);
        origMiLabel = createMetricCell(metricsComparisonGrid, "Original MI", "0", ACCENT_RED);
        origScoreLabel = createMetricCell(metricsComparisonGrid, "Original Score", "0.0", ACCENT_RED);

        predCcLabel = createMetricCell(metricsComparisonGrid, "Predicted CC", "0", ACCENT_EMERALD);
        predCogLabel = createMetricCell(metricsComparisonGrid, "Predicted Cog", "0", ACCENT_EMERALD);
        predMndLabel = createMetricCell(metricsComparisonGrid, "Predicted MND", "0", ACCENT_EMERALD);
        predMiLabel = createMetricCell(metricsComparisonGrid, "Predicted MI", "0", ACCENT_EMERALD);
        predScoreLabel = createMetricCell(metricsComparisonGrid, "Predicted Score", "0.0", ACCENT_EMERALD);

        leftPanel.add(metricsComparisonGrid, BorderLayout.NORTH);

        // Guide Area
        JPanel guideContainer = new JPanel(new BorderLayout());
        guideContainer.setBackground(CARD_NAVY);
        guideContainer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_DARK, 1),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));

        JLabel guideTitle = new JLabel("📌 Step-by-Step Refactoring Blueprint:");
        guideTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        guideTitle.setForeground(ACCENT_CYAN);

        guideArea = new JTextArea();
        guideArea.setEditable(false);
        guideArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        guideArea.setBackground(BG_OBSIDIAN);
        guideArea.setForeground(TEXT_BRIGHT);
        guideArea.setMargin(new Insets(8, 8, 8, 8));

        guideContainer.add(guideTitle, BorderLayout.NORTH);
        guideContainer.add(new JScrollPane(guideArea), BorderLayout.CENTER);

        leftPanel.add(guideContainer, BorderLayout.CENTER);

        // Right Side: Code Transformation Template View
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBackground(CARD_NAVY);
        rightPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_DARK, 1),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));

        JLabel codeTitle = new JLabel("✨ Refactored Architectural Code Pattern Template:");
        codeTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        codeTitle.setForeground(ACCENT_EMERALD);

        codeTemplateArea = new JTextArea();
        codeTemplateArea.setEditable(false);
        codeTemplateArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        codeTemplateArea.setBackground(BG_OBSIDIAN);
        codeTemplateArea.setForeground(ACCENT_CYAN);
        codeTemplateArea.setMargin(new Insets(10, 10, 10, 10));

        rightPanel.add(codeTitle, BorderLayout.NORTH);
        rightPanel.add(new JScrollPane(codeTemplateArea), BorderLayout.CENTER);

        mainContent.add(leftPanel);
        mainContent.add(rightPanel);

        add(mainContent, BorderLayout.CENTER);
    }

    private JLabel createMetricCell(JPanel grid, String title, String initVal, Color color) {
        JPanel p = new JPanel(new GridLayout(2, 1));
        p.setOpaque(false);

        JLabel tLbl = new JLabel(title);
        tLbl.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        tLbl.setForeground(TEXT_MUTED);

        JLabel vLbl = new JLabel(initVal);
        vLbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        vLbl.setForeground(color);

        p.add(tLbl);
        p.add(vLbl);
        grid.add(p);
        return vLbl;
    }

    public void loadRecipe(MethodMetrics m) {
        if (m == null) return;
        this.currentMethod = m;
        RefactoringAssistant.RefactoringRecipe recipe = RefactoringAssistant.generateRecipe(m);

        routineTitleLabel.setText("🛠️ Refactoring Recipe: " + m.getClassName() + "." + m.getMethodName() + "() | Pattern: " + recipe.getPrimaryPattern());

        origCcLabel.setText(String.valueOf(m.getCyclomaticComplexity()));
        origCogLabel.setText(String.valueOf(m.getCognitiveComplexity()));
        origMndLabel.setText(String.valueOf(m.getMaxNestingDepth()));
        origMiLabel.setText(String.format("%.1f", m.getMaintainabilityIndex()));
        origScoreLabel.setText(String.format("%.2f", m.getComplexityScore()));

        predCcLabel.setText(String.valueOf(recipe.getPredictedCc()));
        predCogLabel.setText(String.valueOf(recipe.getPredictedCognitive()));
        predMndLabel.setText(String.valueOf(recipe.getPredictedMaxNesting()));
        predMiLabel.setText(String.format("%.1f", recipe.getPredictedMaintainabilityIndex()));
        predScoreLabel.setText(String.format("%.2f", recipe.getPredictedScore()));

        guideArea.setText(recipe.getStepByStepGuide());
        codeTemplateArea.setText(recipe.getRefactoredCodeTemplate());
    }

    private void generateTestSuite() {
        if (currentMethod == null) return;
        String testCode = UnitTestGenerator.generateJUnit5TestSuite(currentMethod);

        JTextArea area = new JTextArea(testCode);
        area.setFont(new Font("Consolas", Font.PLAIN, 12));
        area.setBackground(BG_OBSIDIAN);
        area.setForeground(ACCENT_CYAN);

        JScrollPane sp = new JScrollPane(area);
        sp.setPreferredSize(new Dimension(650, 450));

        JOptionPane.showMessageDialog(this, sp, "Generated JUnit 5 Test Suite for " + currentMethod.getMethodName() + "()", JOptionPane.INFORMATION_MESSAGE);
    }
}
