package com.codesense.ui;

import com.codesense.features.SnapshotManager;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * Custom Swing Component for rendering Trend Trajectory Graphs
 * across sequential codebase scan revisions.
 */
public class TrendChartCanvas extends JPanel {

    private List<SnapshotManager.TreeSnapshot> history;

    public TrendChartCanvas() {
        this.history = null;
        setBackground(new Color(11, 15, 25)); // Deep Obsidian Dark
    }

    public void setHistory(List<SnapshotManager.TreeSnapshot> history) {
        this.history = history;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        if (history == null || history.size() < 2) {
            g2d.setColor(new Color(148, 163, 184));
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 15));
            String msg = "Capture at least 2 Scan Snapshots to render Structural Trajectory Graphs.";
            FontMetrics fm = g2d.getFontMetrics();
            int x = (width - fm.stringWidth(msg)) / 2;
            int y = height / 2;
            g2d.drawString(msg, x, y);
            return;
        }

        int padding = 65;
        int chartW = width - (padding * 2);
        int chartH = height - (padding * 2);

        // Draw Axes
        g2d.setColor(new Color(51, 65, 85));
        g2d.setStroke(new BasicStroke(1.5f));
        g2d.drawLine(padding, height - padding, padding + chartW, height - padding);
        g2d.drawLine(padding, padding, padding, height - padding);

        double maxVal = 10.0;
        for (SnapshotManager.TreeSnapshot s : history) {
            if (s.getMaxComplexity() > maxVal) maxVal = s.getMaxComplexity();
        }
        maxVal = Math.ceil(maxVal + 2.0);

        // Grid lines
        int gridSteps = 5;
        for (int i = 0; i <= gridSteps; i++) {
            int yPos = (height - padding) - (int) ((i * chartH) / (double) gridSteps);
            g2d.setColor(new Color(30, 41, 59));
            g2d.drawLine(padding, yPos, padding + chartW, yPos);

            double val = (i * maxVal) / gridSteps;
            g2d.setColor(new Color(148, 163, 184));
            g2d.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            g2d.drawString(String.format("%.1f", val), 20, yPos + 4);
        }

        int n = history.size();
        int stepX = chartW / Math.max(1, n - 1);

        int[] xPoints = new int[n];
        int[] yAvgPoints = new int[n];
        int[] yMaxPoints = new int[n];

        for (int i = 0; i < n; i++) {
            SnapshotManager.TreeSnapshot s = history.get(i);
            xPoints[i] = padding + (i * stepX);
            yAvgPoints[i] = (height - padding) - (int) ((s.getAvgComplexity() * chartH) / maxVal);
            yMaxPoints[i] = (height - padding) - (int) ((s.getMaxComplexity() * chartH) / maxVal);

            g2d.setColor(new Color(226, 232, 240));
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 10));
            g2d.drawString(s.getSnapshotId(), xPoints[i] - 15, height - padding + 20);
            g2d.setFont(new Font("Segoe UI", Font.PLAIN, 9));
            g2d.drawString(s.getLabel(), xPoints[i] - 20, height - padding + 35);
        }

        // Draw Max Complexity Line (Purple Neon)
        g2d.setColor(new Color(168, 85, 247));
        g2d.setStroke(new BasicStroke(2.5f));
        for (int i = 0; i < n - 1; i++) {
            g2d.drawLine(xPoints[i], yMaxPoints[i], xPoints[i + 1], yMaxPoints[i + 1]);
        }

        // Draw Average Complexity Line (Emerald Neon)
        g2d.setColor(new Color(16, 185, 129));
        g2d.setStroke(new BasicStroke(2.5f));
        for (int i = 0; i < n - 1; i++) {
            g2d.drawLine(xPoints[i], yAvgPoints[i], xPoints[i + 1], yAvgPoints[i + 1]);
        }

        // Data points
        for (int i = 0; i < n; i++) {
            g2d.setColor(new Color(16, 185, 129));
            g2d.fillOval(xPoints[i] - 5, yAvgPoints[i] - 5, 10, 10);
            g2d.setColor(Color.WHITE);
            g2d.drawOval(xPoints[i] - 5, yAvgPoints[i] - 5, 10, 10);

            g2d.setColor(new Color(168, 85, 247));
            g2d.fillOval(xPoints[i] - 5, yMaxPoints[i] - 5, 10, 10);
            g2d.setColor(Color.WHITE);
            g2d.drawOval(xPoints[i] - 5, yMaxPoints[i] - 5, 10, 10);
        }

        // Chart Legend
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 12));
        g2d.setColor(new Color(16, 185, 129));
        g2d.drawString("● Avg Complexity Trajectory", padding + 20, 30);
        g2d.setColor(new Color(168, 85, 247));
        g2d.drawString("● Max Complexity Peak", padding + 220, 30);
    }
}
