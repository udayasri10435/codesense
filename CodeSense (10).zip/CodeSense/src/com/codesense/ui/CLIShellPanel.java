package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.analyzer.WorkspaceScanner;
import com.codesense.ds.AVLTree;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Embedded Developer CLI Terminal Shell Panel.
 * Allows executing interactive commands directly inside the GUI dashboard.
 */
public class CLIShellPanel extends JPanel {

    private final JTextArea terminalOutputArea;
    private final JTextField commandInputField;

    private WorkspaceScanner.ScanResult currentScan;

    public CLIShellPanel() {
        setLayout(new BorderLayout());
        setBackground(BG_OBSIDIAN);

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(CARD_NAVY);
        header.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));

        JLabel title = new JLabel("💻 CodeSense Interactive Developer CLI Terminal Shell");
        title.setFont(new Font("Segoe UI", Font.BOLD, 13));
        title.setForeground(ACCENT_CYAN);
        header.add(title, BorderLayout.WEST);

        add(header, BorderLayout.NORTH);

        // Terminal Log View
        terminalOutputArea = new JTextArea();
        terminalOutputArea.setEditable(false);
        terminalOutputArea.setFont(new Font("Consolas", Font.PLAIN, 13));
        terminalOutputArea.setBackground(BG_OBSIDIAN);
        terminalOutputArea.setForeground(ACCENT_CYAN);
        terminalOutputArea.setMargin(new Insets(12, 12, 12, 12));

        printWelcomeMessage();

        JScrollPane sp = new JScrollPane(terminalOutputArea);
        sp.getViewport().setBackground(BG_OBSIDIAN);
        sp.setBorder(BorderFactory.createEmptyBorder());

        add(sp, BorderLayout.CENTER);

        // Command Prompt Input Bar
        JPanel inputBar = new JPanel(new BorderLayout(8, 0));
        inputBar.setBackground(PANEL_SLATE);
        inputBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_DARK),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));

        JLabel promptLbl = new JLabel("codesense> ");
        promptLbl.setFont(new Font("Consolas", Font.BOLD, 13));
        promptLbl.setForeground(ACCENT_EMERALD);

        commandInputField = new JTextField();
        commandInputField.setFont(new Font("Consolas", Font.PLAIN, 13));
        commandInputField.setBackground(INPUT_DARK);
        commandInputField.setForeground(TEXT_BRIGHT);
        commandInputField.setCaretColor(TEXT_BRIGHT);
        commandInputField.setBorder(BorderFactory.createEmptyBorder(4, 6, 4, 6));

        commandInputField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    processCommand(commandInputField.getText().trim());
                    commandInputField.setText("");
                }
            }
        });

        inputBar.add(promptLbl, BorderLayout.WEST);
        inputBar.add(commandInputField, BorderLayout.CENTER);

        add(inputBar, BorderLayout.SOUTH);
    }

    private void printWelcomeMessage() {
        terminalOutputArea.append("=======================================================================\n");
        terminalOutputArea.append("  CODESENSE DEVELOPER CLI TERMINAL SHELL v2.5                          \n");
        terminalOutputArea.append("  Type 'help' to see list of available commands.                       \n");
        terminalOutputArea.append("=======================================================================\n\n");
    }

    public void updateData(WorkspaceScanner.ScanResult scan) {
        this.currentScan = scan;
    }

    private void processCommand(String cmd) {
        if (cmd.isEmpty()) return;

        terminalOutputArea.append("codesense> " + cmd + "\n");

        String[] parts = cmd.split("\\s+");
        String action = parts[0].toLowerCase();

        switch (action) {
            case "help":
                terminalOutputArea.append("  Available Commands:\n");
                terminalOutputArea.append("   - scan <path>       : Scan target directory for complexity metrics\n");
                terminalOutputArea.append("   - list              : List all indexed method routines sorted by AVL tree\n");
                terminalOutputArea.append("   - range <min> <max> : Execute logarithmic AVL sub-tree range query\n");
                terminalOutputArea.append("   - height            : Show current native AVL tree height and optimal bound\n");
                terminalOutputArea.append("   - clear             : Clear terminal screen\n\n");
                break;

            case "list":
                if (currentScan == null) {
                    terminalOutputArea.append("  [!] No active scan data. Run a scan first.\n\n");
                } else {
                    List<MethodMetrics> methods = currentScan.getAvlTree().inOrderTraversal();
                    terminalOutputArea.append("  Indexed Routines (" + methods.size() + " total):\n");
                    for (MethodMetrics m : methods) {
                        terminalOutputArea.append(String.format("   ▸ %-32s | Score: %-6.2f | CC: %-2d | Risk: %s\n",
                                m.getClassName() + "." + m.getMethodName() + "()",
                                m.getComplexityScore(), m.getCyclomaticComplexity(), m.getRiskLevel().name()));
                    }
                    terminalOutputArea.append("\n");
                }
                break;

            case "height":
                if (currentScan == null) {
                    terminalOutputArea.append("  [!] No active scan data.\n\n");
                } else {
                    AVLTree<?> tree = currentScan.getAvlTree();
                    terminalOutputArea.append("  AVL Tree Height: " + tree.getHeight() + " (Rotations: " + tree.getTotalRotations() + ")\n\n");
                }
                break;

            case "range":
                if (currentScan == null) {
                    terminalOutputArea.append("  [!] No active scan data.\n\n");
                } else if (parts.length < 3) {
                    terminalOutputArea.append("  Usage: range <minScore> <maxScore>\n\n");
                } else {
                    try {
                        double min = Double.parseDouble(parts[1]);
                        double max = Double.parseDouble(parts[2]);
                        List<MethodMetrics> range = currentScan.getAvlTree().rangeSearch(min, max);
                        terminalOutputArea.append("  Range Query [" + min + " <= Score <= " + max + "] found " + range.size() + " matches:\n");
                        for (MethodMetrics m : range) {
                            terminalOutputArea.append(String.format("   ▸ %s (Score: %.2f)\n", m.getMethodName(), m.getComplexityScore()));
                        }
                        terminalOutputArea.append("\n");
                    } catch (NumberFormatException e) {
                        terminalOutputArea.append("  [!] Invalid min/max numeric values.\n\n");
                    }
                }
                break;

            case "clear":
                terminalOutputArea.setText("");
                printWelcomeMessage();
                break;

            default:
                terminalOutputArea.append("  [!] Unknown command: '" + cmd + "'. Type 'help' for usage.\n\n");
                break;
        }

        terminalOutputArea.setCaretPosition(terminalOutputArea.getDocument().getLength());
    }
}
