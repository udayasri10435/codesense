package com.codesense.ui;

import com.codesense.analyzer.WorkspaceScanner;
import com.codesense.features.AlertManager;
import com.codesense.features.QualityGateEngine;

import javax.swing.*;
import java.awt.*;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * CI/CD Quality Gate Configuration & Compliance Inspector UI.
 */
public class QualityGatePanel extends JPanel {

    private final JSpinner maxCcSpinner;
    private final JSpinner minMiSpinner;
    private final JSpinner maxCriticalSpinner;
    private final JSpinner maxAvgScoreSpinner;

    private final JLabel statusBadgeLabel;
    private final JLabel complianceScoreLabel;
    private final JTextArea violationsArea;

    private WorkspaceScanner.ScanResult currentScan;
    private List<AlertManager.RefactorAlert> currentAlerts;

    public QualityGatePanel() {
        setLayout(new BorderLayout());
        setBackground(PANEL_SLATE);

        // Header & Threshold Config Bar
        JPanel configBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 10));
        configBar.setBackground(CARD_NAVY);
        configBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));

        JLabel maxCcLbl = new JLabel("Max Allowed CC:");
        maxCcLbl.setFont(new Font("Segoe UI", Font.BOLD, 11));
        maxCcLbl.setForeground(TEXT_BRIGHT);
        maxCcSpinner = new JSpinner(new SpinnerNumberModel(15, 1, 100, 1));
        applyDarkSpinnerStyle(maxCcSpinner);

        JLabel minMiLbl = new JLabel("Min Allowed MI:");
        minMiLbl.setFont(new Font("Segoe UI", Font.BOLD, 11));
        minMiLbl.setForeground(TEXT_BRIGHT);
        minMiSpinner = new JSpinner(new SpinnerNumberModel(50.0, 0.0, 100.0, 5.0));
        applyDarkSpinnerStyle(minMiSpinner);

        JLabel maxCritLbl = new JLabel("Max Critical Alerts:");
        maxCritLbl.setFont(new Font("Segoe UI", Font.BOLD, 11));
        maxCritLbl.setForeground(TEXT_BRIGHT);
        maxCriticalSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 20, 1));
        applyDarkSpinnerStyle(maxCriticalSpinner);

        JLabel maxAvgLbl = new JLabel("Max Avg Score:");
        maxAvgLbl.setFont(new Font("Segoe UI", Font.BOLD, 11));
        maxAvgLbl.setForeground(TEXT_BRIGHT);
        maxAvgScoreSpinner = new JSpinner(new SpinnerNumberModel(20.0, 1.0, 100.0, 1.0));
        applyDarkSpinnerStyle(maxAvgScoreSpinner);

        CustomDarkButton evalBtn = new CustomDarkButton("🛡️ Evaluate Quality Gate", ACCENT_BLUE, Color.WHITE);
        evalBtn.addActionListener(e -> runEvaluation());

        configBar.add(maxCcLbl);
        configBar.add(maxCcSpinner);
        configBar.add(minMiLbl);
        configBar.add(minMiSpinner);
        configBar.add(maxCritLbl);
        configBar.add(maxCriticalSpinner);
        configBar.add(maxAvgLbl);
        configBar.add(maxAvgScoreSpinner);
        configBar.add(evalBtn);

        add(configBar, BorderLayout.NORTH);

        // Status Result Banner & Violations List
        JPanel mainContent = new JPanel(new BorderLayout(0, 12));
        mainContent.setOpaque(false);
        mainContent.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JPanel statusBanner = new JPanel(new GridLayout(1, 2, 12, 0));
        statusBanner.setOpaque(false);

        statusBadgeLabel = createStatusCard(statusBanner, "QUALITY GATE STATUS", "PASSED", ACCENT_EMERALD);
        complianceScoreLabel = createStatusCard(statusBanner, "COMPLIANCE RATING", "100%", ACCENT_CYAN);

        mainContent.add(statusBanner, BorderLayout.NORTH);

        // Violations List Area
        JPanel violationsContainer = new JPanel(new BorderLayout());
        violationsContainer.setBackground(CARD_NAVY);
        violationsContainer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_DARK, 1),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));

        JLabel vTitle = new JLabel("⚠️ Gate Violations & Compliance Failures:");
        vTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        vTitle.setForeground(ACCENT_RED);

        violationsArea = new JTextArea();
        violationsArea.setEditable(false);
        violationsArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        violationsArea.setBackground(BG_OBSIDIAN);
        violationsArea.setForeground(ACCENT_RED);
        violationsArea.setMargin(new Insets(10, 10, 10, 10));

        violationsContainer.add(vTitle, BorderLayout.NORTH);
        violationsContainer.add(new JScrollPane(violationsArea), BorderLayout.CENTER);

        mainContent.add(violationsContainer, BorderLayout.CENTER);

        add(mainContent, BorderLayout.CENTER);
    }

    private JLabel createStatusCard(JPanel container, String title, String initVal, Color color) {
        JPanel card = new JPanel(new BorderLayout(4, 4));
        card.setBackground(CARD_NAVY);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(3, 0, 0, 0, color),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_DARK, 1),
                        BorderFactory.createEmptyBorder(12, 14, 12, 14)
                )
        ));

        JLabel tLbl = new JLabel(title);
        tLbl.setFont(new Font("Segoe UI", Font.BOLD, 11));
        tLbl.setForeground(TEXT_MUTED);

        JLabel vLbl = new JLabel(initVal);
        vLbl.setFont(new Font("Segoe UI", Font.BOLD, 22));
        vLbl.setForeground(color);

        card.add(tLbl, BorderLayout.NORTH);
        card.add(vLbl, BorderLayout.CENTER);
        container.add(card);
        return vLbl;
    }

    public void updateData(WorkspaceScanner.ScanResult scan, List<AlertManager.RefactorAlert> alerts) {
        this.currentScan = scan;
        this.currentAlerts = alerts;
        runEvaluation();
    }

    private void runEvaluation() {
        if (currentScan == null) return;

        QualityGateEngine.QualityGateConfig config = new QualityGateEngine.QualityGateConfig();
        config.maxAllowedCc = ((Number) maxCcSpinner.getValue()).intValue();
        config.minAllowedMaintainabilityIndex = ((Number) minMiSpinner.getValue()).doubleValue();
        config.maxAllowedCriticalAlerts = ((Number) maxCriticalSpinner.getValue()).intValue();
        config.maxAllowedAvgScore = ((Number) maxAvgScoreSpinner.getValue()).doubleValue();

        QualityGateEngine.QualityGateResult res = QualityGateEngine.evaluateQualityGate(currentScan, config, currentAlerts != null ? currentAlerts : java.util.Collections.emptyList());

        if (res.isPassed()) {
            statusBadgeLabel.setText("PASSED (All Rules Compliant)");
            statusBadgeLabel.setForeground(ACCENT_EMERALD);
            complianceScoreLabel.setText("100%");
            complianceScoreLabel.setForeground(ACCENT_EMERALD);
            violationsArea.setForeground(ACCENT_EMERALD);
            violationsArea.setText("All quality gate rules satisfied cleanly! No architectural violations found.\nCodebase is certified for deployment.");
        } else {
            statusBadgeLabel.setText("FAILED (Violations Found)");
            statusBadgeLabel.setForeground(ACCENT_RED);
            complianceScoreLabel.setText(res.getComplianceScore() + "%");
            complianceScoreLabel.setForeground(ACCENT_RED);
            violationsArea.setForeground(ACCENT_RED);

            StringBuilder sb = new StringBuilder();
            sb.append("QUALITY GATE EVALUATION FAILED WITH ").append(res.getViolations().size()).append(" VIOLATIONS:\n\n");
            for (String v : res.getViolations()) {
                sb.append(" ❌ ").append(v).append("\n");
            }
            violationsArea.setText(sb.toString());
        }
    }
}
