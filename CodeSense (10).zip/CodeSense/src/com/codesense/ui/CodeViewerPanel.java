package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Source Code Preview Panel with line numbers and routine highlight bounds.
 */
public class CodeViewerPanel extends JPanel {

    private final JTextPane codeArea;
    private final JTextArea lineNumbersArea;
    private final JLabel fileTitleLabel;

    public CodeViewerPanel() {
        setLayout(new BorderLayout());
        setBackground(PANEL_SLATE);

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(CARD_NAVY);
        header.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));

        fileTitleLabel = new JLabel("📄 Source Code Viewer (Select a routine from the Index to inspect source)");
        fileTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        fileTitleLabel.setForeground(ACCENT_CYAN);
        header.add(fileTitleLabel, BorderLayout.WEST);

        add(header, BorderLayout.NORTH);

        // Code Area
        codeArea = new JTextPane();
        codeArea.setEditable(false);
        codeArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        codeArea.setBackground(BG_OBSIDIAN);
        codeArea.setForeground(TEXT_BRIGHT);
        codeArea.setMargin(new Insets(10, 10, 10, 10));

        // Line Numbers Area
        lineNumbersArea = new JTextArea();
        lineNumbersArea.setEditable(false);
        lineNumbersArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        lineNumbersArea.setBackground(PANEL_SLATE);
        lineNumbersArea.setForeground(TEXT_MUTED);
        lineNumbersArea.setMargin(new Insets(10, 8, 10, 8));
        lineNumbersArea.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, BORDER_DARK));

        JScrollPane scrollPane = new JScrollPane(codeArea);
        scrollPane.setRowHeaderView(lineNumbersArea);
        scrollPane.getViewport().setBackground(BG_OBSIDIAN);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        add(scrollPane, BorderLayout.CENTER);
    }

    public void loadAndHighlightMethod(MethodMetrics method) {
        if (method == null || method.getFilePath() == null) return;

        File file = new File(method.getFilePath());
        if (!file.exists()) {
            fileTitleLabel.setText("File not found: " + method.getFilePath());
            return;
        }

        fileTitleLabel.setText(String.format("📄 File: %s | Target Routine: %s.%s() (Lines %d-%d)",
                file.getName(), method.getClassName(), method.getMethodName(), method.getStartLine(), method.getEndLine()));

        StringBuilder codeText = new StringBuilder();
        StringBuilder lineNums = new StringBuilder();

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int lineNo = 1;
            while ((line = reader.readLine()) != null) {
                lineNums.append(String.format("%3d\n", lineNo));
                codeText.append(line).append("\n");
                lineNo++;
            }
        } catch (IOException e) {
            codeArea.setText("Error reading file: " + e.getMessage());
            return;
        }

        lineNumbersArea.setText(lineNums.toString());
        codeArea.setText(codeText.toString());

        // Highlight routine line range
        try {
            Highlighter highlighter = codeArea.getHighlighter();
            highlighter.removeAllHighlights();

            String fullText = codeArea.getText();
            String[] lines = fullText.split("\n");

            int startPos = 0;
            int endPos = 0;
            int currentLine = 1;

            for (int i = 0; i < lines.length; i++) {
                if (currentLine == method.getStartLine()) {
                    startPos = codeArea.getDocument().getDefaultRootElement().getElement(i).getStartOffset();
                }
                if (currentLine == method.getEndLine()) {
                    endPos = codeArea.getDocument().getDefaultRootElement().getElement(i).getEndOffset();
                    break;
                }
                currentLine++;
            }

            if (startPos < endPos && endPos <= fullText.length()) {
                DefaultHighlighter.DefaultHighlightPainter painter =
                        new DefaultHighlighter.DefaultHighlightPainter(new Color(37, 99, 235, 90)); // Soft Blue Highlight
                highlighter.addHighlight(startPos, endPos, painter);
                codeArea.setCaretPosition(startPos);
            }
        } catch (Exception ignored) {
        }
    }
}
