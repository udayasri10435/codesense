package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.analyzer.WorkspaceScanner;
import com.codesense.features.AlertManager;

import javax.swing.*;
import java.awt.*;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Executive Summary C-Suite Compliance & Overview Dashboard Panel.
 */
public class ExecutiveSummaryPanel extends JPanel {

    private final JLabel healthGradeBadge;
    private final JLabel certificationLabel;
    private final JTextArea topRiskArea;
    private final JTextArea executiveNotesArea;

    public ExecutiveSummaryPanel() {
        setLayout(new BorderLayout());
        setBackground(PANEL_SLATE);

        // Top Banner
        JPanel banner = new JPanel(new BorderLayout());
        banner.setBackground(CARD_NAVY);
        banner.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK),
                BorderFactory.createEmptyBorder(12, 16, 12, 16)
        ));

        JLabel title = new JLabel("👔 Executive Complexity Summary & C-Suite Compliance Audit");
        title.setFont(new Font("Segoe UI", Font.BOLD, 14));
        title.setForeground(ACCENT_CYAN);

        banner.add(title, BorderLayout.WEST);
        add(banner, BorderLayout.NORTH);

        // Content
        JPanel content = new JPanel(new GridLayout(1, 2, 14, 0));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));

        // Left Card: Certification & Health Grade
        JPanel leftCard = new JPanel(new BorderLayout(0, 10));
        leftCard.setBackground(CARD_NAVY);
        leftCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_DARK, 1),
                BorderFactory.createEmptyBorder(16, 16, 16, 16)
        ));

        JLabel gradeTitle = new JLabel("CODEBASE HEALTH RATING");
        gradeTitle.setFont(new Font("Segoe UI", Font.BOLD, 11));
        gradeTitle.setForeground(TEXT_MUTED);

        healthGradeBadge = new JLabel("100% (A+)");
        healthGradeBadge.setFont(new Font("Segoe UI", Font.BOLD, 36));
        healthGradeBadge.setForeground(ACCENT_EMERALD);

        certificationLabel = new JLabel("STATUS: SYSTEM CERTIFIED FOR PRODUCTION");
        certificationLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        certificationLabel.setForeground(ACCENT_EMERALD);

        executiveNotesArea = new JTextArea();
        executiveNotesArea.setEditable(false);
        executiveNotesArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        executiveNotesArea.setBackground(BG_OBSIDIAN);
        executiveNotesArea.setForeground(TEXT_BRIGHT);
        executiveNotesArea.setMargin(new Insets(10, 10, 10, 10));

        JPanel gradeHeaderBox = new JPanel(new GridLayout(3, 1, 0, 4));
        gradeHeaderBox.setOpaque(false);
        gradeHeaderBox.add(gradeTitle);
        gradeHeaderBox.add(healthGradeBadge);
        gradeHeaderBox.add(certificationLabel);

        leftCard.add(gradeHeaderBox, BorderLayout.NORTH);
        leftCard.add(new JScrollPane(executiveNotesArea), BorderLayout.CENTER);

        // Right Card: Top Risk Routines
        JPanel rightCard = new JPanel(new BorderLayout(0, 10));
        rightCard.setBackground(CARD_NAVY);
        rightCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_DARK, 1),
                BorderFactory.createEmptyBorder(16, 16, 16, 16)
        ));

        JLabel riskTitle = new JLabel("🚨 TOP 3 HIGH-RISK ROUTINES NEEDING REMEDIATION:");
        riskTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        riskTitle.setForeground(ACCENT_RED);

        topRiskArea = new JTextArea();
        topRiskArea.setEditable(false);
        topRiskArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        topRiskArea.setBackground(BG_OBSIDIAN);
        topRiskArea.setForeground(ACCENT_RED);
        topRiskArea.setMargin(new Insets(10, 10, 10, 10));

        rightCard.add(riskTitle, BorderLayout.NORTH);
        rightCard.add(new JScrollPane(topRiskArea), BorderLayout.CENTER);

        content.add(leftCard);
        content.add(rightCard);

        add(content, BorderLayout.CENTER);
    }

    public void updateSummary(WorkspaceScanner.ScanResult scan, List<AlertManager.RefactorAlert> alerts) {
        if (scan == null || scan.getAllMethods().isEmpty()) return;

        List<MethodMetrics> methods = scan.getAllMethods();
        int total = methods.size();
        int criticalCount = 0;
        for (AlertManager.RefactorAlert a : alerts) {
            if (a.getSeverity() == MethodMetrics.RiskLevel.CRITICAL) criticalCount++;
        }

        double sum = 0;
        for (MethodMetrics m : methods) sum += m.getComplexityScore();
        double avg = sum / total;

        double health = Math.max(10.0, 100.0 - (criticalCount * 22.0) - (alerts.size() * 6.0) - (avg * 1.2));
        String grade = "A+";
        if (health < 50) grade = "F";
        else if (health < 65) grade = "D";
        else if (health < 75) grade = "C";
        else if (health < 88) grade = "B";
        else if (health < 95) grade = "A";

        healthGradeBadge.setText(String.format("%.0f%% (%s)", health, grade));

        if (health >= 80) {
            healthGradeBadge.setForeground(ACCENT_EMERALD);
            certificationLabel.setText("STATUS: CERTIFIED FOR ENTERPRISE DEPLOYMENT ✅");
            certificationLabel.setForeground(ACCENT_EMERALD);
        } else {
            healthGradeBadge.setForeground(ACCENT_RED);
            certificationLabel.setText("STATUS: REFACTORING REQUIRED BEFORE PRODUCTION RELEASE ⚠️");
            certificationLabel.setForeground(ACCENT_RED);
        }

        executiveNotesArea.setText("EXECUTIVE ARCHITECTURAL SUMMARY:\n\n" +
                "• Analyzed Routines: " + total + " methods across " + scan.getScannedFilesCount() + " source files.\n" +
                "• System Scan Velocity: Completed in " + scan.getElapsedTimeMs() + "ms.\n" +
                "• Native AVL Tree Height: " + scan.getAvlTree().getHeight() + " (Strict Logarithmic Height Guarantee).\n" +
                "• Total Refactor Alerts: " + alerts.size() + " (" + criticalCount + " Critical Targets).\n" +
                "• System Stability: " + (criticalCount == 0 ? "EXCELLENT - Zero blocking architectural risks." : "ACTION REQUIRED - Critical complexity overload detected."));

        StringBuilder rb = new StringBuilder();
        methods.sort((a, b) -> Double.compare(b.getComplexityScore(), a.getComplexityScore()));

        rb.append("Highest Complexity Routines Ranked:\n\n");
        for (int i = 0; i < Math.min(3, methods.size()); i++) {
            MethodMetrics m = methods.get(i);
            rb.append(" #").append(i + 1).append(" ").append(m.getClassName()).append(".").append(m.getMethodName()).append("()\n");
            rb.append("    Score: ").append(String.format("%.2f", m.getComplexityScore()))
              .append(" | CC: ").append(m.getCyclomaticComplexity())
              .append(" | Cog: ").append(m.getCognitiveComplexity())
              .append(" | Nesting: ").append(m.getMaxNestingDepth()).append("\n\n");
        }
        topRiskArea.setText(rb.toString());
    }
}
