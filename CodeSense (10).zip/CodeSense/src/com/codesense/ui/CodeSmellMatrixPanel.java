package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.features.AlertManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Code Smell Remediation Matrix Panel.
 * Categorizes architectural code smells across the codebase with remediation priority ranks.
 */
public class CodeSmellMatrixPanel extends JPanel {

    private final JTable smellTable;
    private final DefaultTableModel smellTableModel;
    private final JLabel longMethodLabel;
    private final JLabel highCcLabel;
    private final JLabel cognitiveOverloadLabel;
    private final JLabel deepNestingLabel;

    public CodeSmellMatrixPanel() {
        setLayout(new BorderLayout());
        setBackground(PANEL_SLATE);

        // Header Summary Bar
        JPanel summaryBar = new JPanel(new GridLayout(1, 4, 12, 0));
        summaryBar.setOpaque(false);
        summaryBar.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        longMethodLabel = createCard(summaryBar, "Long Methods (>40 LOC)", "0", ACCENT_AMBER);
        highCcLabel = createCard(summaryBar, "High CC (>10)", "0", ACCENT_RED);
        cognitiveOverloadLabel = createCard(summaryBar, "Cognitive Overload (>12)", "0", ACCENT_PURPLE);
        deepNestingLabel = createCard(summaryBar, "Deep Nesting (>3)", "0", ACCENT_CYAN);

        add(summaryBar, BorderLayout.NORTH);

        // Table
        String[] cols = {"Code Smell Type", "Target Routine", "Severity Level", "Affected Line Bounds", "Actionable Remediation Strategy"};
        smellTableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        smellTable = new JTable(smellTableModel);
        applyDarkTableStyle(smellTable);

        JScrollPane sp = new JScrollPane(smellTable);
        sp.getViewport().setBackground(PANEL_SLATE);
        sp.setBorder(BorderFactory.createEmptyBorder());

        add(sp, BorderLayout.CENTER);
    }

    private JLabel createCard(JPanel container, String title, String initVal, Color color) {
        JPanel card = new JPanel(new BorderLayout(4, 4));
        card.setBackground(CARD_NAVY);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(3, 0, 0, 0, color),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_DARK, 1),
                        BorderFactory.createEmptyBorder(8, 10, 8, 10)
                )
        ));

        JLabel tLbl = new JLabel(title);
        tLbl.setFont(new Font("Segoe UI", Font.BOLD, 10));
        tLbl.setForeground(TEXT_MUTED);

        JLabel vLbl = new JLabel(initVal);
        vLbl.setFont(new Font("Segoe UI", Font.BOLD, 16));
        vLbl.setForeground(color);

        card.add(tLbl, BorderLayout.NORTH);
        card.add(vLbl, BorderLayout.CENTER);
        container.add(card);
        return vLbl;
    }

    public void updateSmells(List<MethodMetrics> methods) {
        smellTableModel.setRowCount(0);
        if (methods == null) return;

        int longMethods = 0, highCc = 0, cognitiveOverload = 0, deepNesting = 0;

        for (MethodMetrics m : methods) {
            for (String smell : m.getCodeSmells()) {
                if (smell.startsWith("Clean")) continue;

                if (smell.contains("Long Method")) longMethods++;
                if (smell.contains("High Cyclomatic")) highCc++;
                if (smell.contains("Cognitive Overload")) cognitiveOverload++;
                if (smell.contains("Deep Arrow")) deepNesting++;

                String rec = "Refactor method into smaller cohesive functions.";
                if (smell.contains("Long Method")) rec = "Apply Extract Method pattern to split large routine.";
                else if (smell.contains("High Cyclomatic")) rec = "Replace decision branches with Strategy/Command Pattern.";
                else if (smell.contains("Cognitive Overload")) rec = "Extract helper sub-routines to lower mental trace load.";
                else if (smell.contains("Deep Arrow")) rec = "Invert conditionals into Guard Clauses (Early Return).";

                smellTableModel.addRow(new Object[]{
                        smell,
                        m.getClassName() + "." + m.getMethodName() + "()",
                        m.getRiskLevel().getLabel(),
                        "Lines " + m.getStartLine() + "-" + m.getEndLine() + " (" + m.getLinesOfCode() + " LOC)",
                        rec
                });
            }
        }

        longMethodLabel.setText(String.valueOf(longMethods));
        highCcLabel.setText(String.valueOf(highCc));
        cognitiveOverloadLabel.setText(String.valueOf(cognitiveOverload));
        deepNestingLabel.setText(String.valueOf(deepNesting));
    }
}
