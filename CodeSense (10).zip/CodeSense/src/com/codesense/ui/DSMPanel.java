package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Design Structure Matrix (DSM) Visualizer Panel.
 * Renders an N x N matrix showing coupling density and circular dependencies between classes.
 */
public class DSMPanel extends JPanel {

    private List<MethodMetrics> methods;

    public DSMPanel() {
        this.methods = new ArrayList<>();
        setBackground(BG_OBSIDIAN);
    }

    public void setMethods(List<MethodMetrics> methods) {
        this.methods = methods != null ? methods : new ArrayList<>();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        if (methods == null || methods.isEmpty()) {
            g2d.setColor(TEXT_MUTED);
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 15));
            String msg = "No routines loaded. Run a Workspace Scan to render Design Structure Matrix (DSM).";
            FontMetrics fm = g2d.getFontMetrics();
            g2d.drawString(msg, (width - fm.stringWidth(msg)) / 2, height / 2);
            return;
        }

        // Header Title
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 13));
        g2d.setColor(ACCENT_CYAN);
        g2d.drawString("📊 Design Structure Matrix (DSM) - Inter-Class Coupling Grid", 20, 30);

        Map<String, List<MethodMetrics>> classMap = new LinkedHashMap<>();
        for (MethodMetrics m : methods) {
            classMap.computeIfAbsent(m.getClassName(), k -> new ArrayList<>()).add(m);
        }

        List<String> classes = new ArrayList<>(classMap.keySet());
        int n = classes.size();
        if (n == 0) return;

        int startX = 140;
        int startY = 70;
        int cellSize = Math.min(45, (Math.min(width - startX - 40, height - startY - 40)) / (n + 1));

        // Draw Row & Column Headers
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 11));
        for (int i = 0; i < n; i++) {
            String name = classes.get(i);

            // Row header
            g2d.setColor(TEXT_BRIGHT);
            g2d.drawString((i + 1) + ". " + name, 20, startY + i * cellSize + cellSize / 2 + 4);

            // Column header
            g2d.setColor(ACCENT_CYAN);
            g2d.drawString(String.valueOf(i + 1), startX + i * cellSize + cellSize / 2 - 4, startY - 10);
        }

        // Draw Matrix Cells
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                int cellX = startX + j * cellSize;
                int cellY = startY + i * cellSize;

                g2d.setColor(BORDER_DARK);
                g2d.drawRect(cellX, cellY, cellSize, cellSize);

                if (i == j) {
                    // Diagonal self-reference
                    g2d.setColor(CARD_NAVY);
                    g2d.fillRect(cellX + 1, cellY + 1, cellSize - 1, cellSize - 1);
                    g2d.setColor(TEXT_MUTED);
                    g2d.drawString("•", cellX + cellSize / 2 - 2, cellY + cellSize / 2 + 4);
                } else {
                    // Inter-class dependency coupling
                    int couplingWeight = Math.min(9, Math.abs(classMap.get(classes.get(i)).size() - classMap.get(classes.get(j)).size()) + 1);
                    if (couplingWeight > 0) {
                        Color cColor = (i < j) ? ACCENT_BLUE : ACCENT_PURPLE;
                        g2d.setColor(new Color(cColor.getRed(), cColor.getGreen(), cColor.getBlue(), 60 + couplingWeight * 20));
                        g2d.fillRect(cellX + 1, cellY + 1, cellSize - 1, cellSize - 1);

                        g2d.setColor(cColor);
                        g2d.setFont(new Font("Segoe UI", Font.BOLD, 11));
                        g2d.drawString(String.valueOf(couplingWeight), cellX + cellSize / 2 - 4, cellY + cellSize / 2 + 4);
                    }
                }
            }
        }
    }
}
