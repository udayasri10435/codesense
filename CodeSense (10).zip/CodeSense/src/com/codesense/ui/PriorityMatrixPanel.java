package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * 4-Quadrant Technical Debt & Refactoring Priority Matrix Panel.
 * Maps routine complexity against maintainability index to prioritize engineering effort.
 */
public class PriorityMatrixPanel extends JPanel {

    private List<MethodMetrics> methods;

    public PriorityMatrixPanel() {
        this.methods = new ArrayList<>();
        setBackground(BG_OBSIDIAN);
    }

    public void setMethods(List<MethodMetrics> methods) {
        this.methods = methods != null ? methods : new ArrayList<>();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        if (methods == null || methods.isEmpty()) {
            g2d.setColor(TEXT_MUTED);
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 15));
            String msg = "No routines loaded. Run a Workspace Scan to render Refactoring Priority Matrix.";
            FontMetrics fm = g2d.getFontMetrics();
            g2d.drawString(msg, (width - fm.stringWidth(msg)) / 2, height / 2);
            return;
        }

        // Header Title
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 13));
        g2d.setColor(ACCENT_CYAN);
        g2d.drawString("🎯 Technical Debt Refactoring Priority Matrix (Impact vs Complexity)", 20, 30);

        int startX = 60;
        int startY = 60;
        int gridWidth = width - 100;
        int gridHeight = height - 100;

        int midX = startX + gridWidth / 2;
        int midY = startY + gridHeight / 2;

        // Quadrant Background Fills
        // Top-Left: Quick Wins (High MI, Low CC) - Emerald
        g2d.setColor(new Color(6, 78, 59, 70));
        g2d.fillRect(startX, startY, gridWidth / 2, gridHeight / 2);

        // Top-Right: High ROI Major Projects (Low MI, High CC) - Red
        g2d.setColor(new Color(127, 29, 29, 80));
        g2d.fillRect(midX, startY, gridWidth / 2, gridHeight / 2);

        // Bottom-Left: Low Priority Fill-Ins (High MI, High CC) - Amber
        g2d.setColor(new Color(120, 53, 15, 60));
        g2d.fillRect(startX, midY, gridWidth / 2, gridHeight / 2);

        // Bottom-Right: Low ROI / Defer (Low MI, Low CC) - Purple
        g2d.setColor(new Color(88, 28, 135, 60));
        g2d.fillRect(midX, midY, gridWidth / 2, gridHeight / 2);

        // Quadrant Borders & Axis Lines
        g2d.setColor(BORDER_DARK);
        g2d.setStroke(new BasicStroke(2.0f));
        g2d.drawRect(startX, startY, gridWidth, gridHeight);
        g2d.drawLine(midX, startY, midX, startY + gridHeight);
        g2d.drawLine(startX, midY, startX + gridWidth, midY);

        // Quadrant Titles
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 14));

        g2d.setColor(ACCENT_EMERALD);
        g2d.drawString("🚀 QUICK WINS (Low Complexity, High Maintainability)", startX + 15, startY + 25);

        g2d.setColor(ACCENT_RED);
        g2d.drawString("🚨 CRITICAL REFACTOR TARGETS (High Complexity)", midX + 15, startY + 25);

        g2d.setColor(ACCENT_AMBER);
        g2d.drawString("🧹 LOW PRIORITY (Moderate Complexity)", startX + 15, midY + 25);

        g2d.setColor(ACCENT_PURPLE);
        g2d.drawString("⚠️ DEFER / MONOLITH DECOMPOSITION", midX + 15, midY + 25);

        // Plot Routine Nodes on Matrix
        for (MethodMetrics m : methods) {
            double ccNorm = Math.min(1.0, m.getCyclomaticComplexity() / 25.0);
            double miNorm = Math.min(1.0, m.getMaintainabilityIndex() / 100.0);

            int px = startX + (int) (ccNorm * gridWidth);
            int py = startY + (int) ((1.0 - miNorm) * gridHeight);

            Color dotColor = ACCENT_EMERALD;
            if (m.getRiskLevel() == MethodMetrics.RiskLevel.CRITICAL) dotColor = ACCENT_PURPLE;
            else if (m.getRiskLevel() == MethodMetrics.RiskLevel.HIGH) dotColor = ACCENT_RED;
            else if (m.getRiskLevel() == MethodMetrics.RiskLevel.MEDIUM) dotColor = ACCENT_AMBER;

            g2d.setColor(dotColor);
            g2d.fillOval(px - 6, py - 6, 12, 12);
            g2d.setColor(Color.WHITE);
            g2d.drawOval(px - 6, py - 6, 12, 12);

            g2d.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            g2d.drawString(m.getMethodName() + "()", px + 8, py + 4);
        }
    }
}
