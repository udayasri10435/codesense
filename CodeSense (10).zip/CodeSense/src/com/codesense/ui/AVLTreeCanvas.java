package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.ds.AVLNode;
import com.codesense.ds.AVLTree;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Enhanced AVL Tree Visualizer with Zooming, Node Selection, and Detail Inspector.
 */
public class AVLTreeCanvas extends JPanel {

    private AVLTree<MethodMetrics> tree;
    private double zoomScale = 1.0;
    private AVLNode<MethodMetrics> selectedNode = null;
    private final int NODE_RADIUS = 26;

    public AVLTreeCanvas() {
        this.tree = null;
        setBackground(new Color(10, 14, 23));

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (tree == null || tree.getRoot() == null) return;
                int clickX = (int) (e.getX() / zoomScale);
                int clickY = (int) (e.getY() / zoomScale);
                AVLNode<MethodMetrics> clicked = findClickedNode(tree.getRoot(), clickX, clickY, getWidth() / 2, 85, getWidth() / 4, 65);
                if (clicked != null) {
                    selectedNode = clicked;
                    repaint();
                    showNodeDetailDialog(clicked);
                }
            }
        });
    }

    public void setTree(AVLTree<MethodMetrics> tree) {
        this.tree = tree;
        this.selectedNode = null;
        repaint();
    }

    public void zoomIn() {
        zoomScale = Math.min(2.5, zoomScale + 0.15);
        repaint();
    }

    public void zoomOut() {
        zoomScale = Math.max(0.4, zoomScale - 0.15);
        repaint();
    }

    public void resetZoom() {
        zoomScale = 1.0;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        g2d.scale(zoomScale, zoomScale);

        int width = (int) (getWidth() / zoomScale);
        int height = (int) (getHeight() / zoomScale);

        if (tree == null || tree.getRoot() == null) {
            g2d.setColor(new Color(148, 163, 184));
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 16));
            String msg = "No AVL Tree Loaded. Perform a Workspace Scan to visualize the self-balancing tree.";
            FontMetrics fm = g2d.getFontMetrics();
            int x = (width - fm.stringWidth(msg)) / 2;
            int y = height / 2;
            g2d.drawString(msg, x, y);
            return;
        }

        // Draw Tree Header & Zoom Info
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 13));
        g2d.setColor(new Color(56, 189, 248));
        g2d.drawString(String.format("AVL Tree Canvas: Root Key=%.2f | Tree Height=%d | Indexed Nodes=%d | Scale=%.0f%% (Click any node to inspect)",
                tree.getRoot().getKey(), tree.getHeight(), tree.getSize(), zoomScale * 100), 20, 30);

        // Draw Legend
        drawLegend(g2d, width - 380, 15);

        // Draw Tree
        drawTreeRecursive(g2d, tree.getRoot(), width / 2, 85, width / 4, 65);
    }

    private void drawLegend(Graphics2D g2d, int x, int y) {
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 11));
        g2d.setColor(new Color(52, 211, 153)); g2d.drawString("● Low", x, y + 15);
        g2d.setColor(new Color(245, 158, 11)); g2d.drawString("● Medium", x + 65, y + 15);
        g2d.setColor(new Color(239, 68, 68));  g2d.drawString("● High", x + 145, y + 15);
        g2d.setColor(new Color(168, 85, 247)); g2d.drawString("● Critical Target", x + 215, y + 15);
    }

    private void drawTreeRecursive(Graphics2D g2d, AVLNode<MethodMetrics> node, int x, int y, int xOffset, int yOffset) {
        if (node == null) return;

        if (node.getLeft() != null) {
            int childX = x - xOffset;
            int childY = y + yOffset;
            g2d.setColor(new Color(51, 65, 85));
            g2d.setStroke(new BasicStroke(2.2f));
            g2d.drawLine(x, y, childX, childY);
            drawTreeRecursive(g2d, node.getLeft(), childX, childY, Math.max(xOffset / 2, 32), yOffset);
        }

        if (node.getRight() != null) {
            int childX = x + xOffset;
            int childY = y + yOffset;
            g2d.setColor(new Color(51, 65, 85));
            g2d.setStroke(new BasicStroke(2.2f));
            g2d.drawLine(x, y, childX, childY);
            drawTreeRecursive(g2d, node.getRight(), childX, childY, Math.max(xOffset / 2, 32), yOffset);
        }

        Color nodeColor = getNodeColor(node);

        g2d.setColor(new Color(nodeColor.getRed(), nodeColor.getGreen(), nodeColor.getBlue(), 60));
        g2d.fillOval(x - NODE_RADIUS - 5, y - NODE_RADIUS - 5, (NODE_RADIUS + 5) * 2, (NODE_RADIUS + 5) * 2);

        g2d.setColor(nodeColor);
        g2d.fillOval(x - NODE_RADIUS, y - NODE_RADIUS, NODE_RADIUS * 2, NODE_RADIUS * 2);

        // Highlight selected node
        if (selectedNode == node) {
            g2d.setColor(new Color(253, 224, 71)); // Yellow Selection Ring
            g2d.setStroke(new BasicStroke(3.5f));
            g2d.drawOval(x - NODE_RADIUS - 3, y - NODE_RADIUS - 3, (NODE_RADIUS + 3) * 2, (NODE_RADIUS + 3) * 2);
        }

        g2d.setColor(new Color(15, 23, 42));
        g2d.setStroke(new BasicStroke(2.0f));
        g2d.drawOval(x - NODE_RADIUS, y - NODE_RADIUS, NODE_RADIUS * 2, NODE_RADIUS * 2);

        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 11));
        String text = String.format("%.1f", node.getKey());
        FontMetrics fm = g2d.getFontMetrics();
        int textX = x - (fm.stringWidth(text) / 2);
        int textY = y + (fm.getAscent() / 2) - 2;
        g2d.drawString(text, textX, textY);

        g2d.setColor(new Color(226, 232, 240));
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 10));
        String labelStr = String.format("h=%d", node.getHeight());
        if (!node.getDataList().isEmpty()) {
            labelStr = node.getDataList().get(0).getMethodName() + " (" + labelStr + ")";
        }
        fm = g2d.getFontMetrics();
        g2d.drawString(labelStr, x - (fm.stringWidth(labelStr) / 2), y + NODE_RADIUS + 15);
    }

    private AVLNode<MethodMetrics> findClickedNode(AVLNode<MethodMetrics> node, int clickX, int clickY, int x, int y, int xOffset, int yOffset) {
        if (node == null) return null;

        double dist = Math.hypot(clickX - x, clickY - y);
        if (dist <= NODE_RADIUS) return node;

        AVLNode<MethodMetrics> leftMatch = findClickedNode(node.getLeft(), clickX, clickY, x - xOffset, y + yOffset, Math.max(xOffset / 2, 32), yOffset);
        if (leftMatch != null) return leftMatch;

        return findClickedNode(node.getRight(), clickX, clickY, x + xOffset, y + yOffset, Math.max(xOffset / 2, 32), yOffset);
    }

    private Color getNodeColor(AVLNode<MethodMetrics> node) {
        if (node.getDataList().isEmpty()) return new Color(52, 211, 153);

        MethodMetrics.RiskLevel highest = MethodMetrics.RiskLevel.LOW;
        for (MethodMetrics m : node.getDataList()) {
            if (m.getRiskLevel().ordinal() > highest.ordinal()) {
                highest = m.getRiskLevel();
            }
        }

        switch (highest) {
            case CRITICAL: return new Color(168, 85, 247);
            case HIGH:     return new Color(239, 68, 68);
            case MEDIUM:   return new Color(245, 158, 11);
            case LOW:
            default:       return new Color(52, 211, 153);
        }
    }

    private void showNodeDetailDialog(AVLNode<MethodMetrics> node) {
        if (node.getDataList().isEmpty()) return;
        MethodMetrics m = node.getDataList().get(0);

        StringBuilder sb = new StringBuilder();
        sb.append("AVL Node Metric Key: ").append(String.format("%.2f", node.getKey())).append("\n");
        sb.append("Node Subtree Height: ").append(node.getHeight()).append("\n");
        sb.append("Target Routine: ").append(m.getClassName()).append(".").append(m.getMethodName()).append("()\n");
        sb.append("File Path: ").append(m.getFilePath()).append("\n\n");
        sb.append("Architectural Metrics:\n");
        sb.append(" - Cyclomatic Complexity (CC): ").append(m.getCyclomaticComplexity()).append("\n");
        sb.append(" - Cognitive Complexity (Cog): ").append(m.getCognitiveComplexity()).append("\n");
        sb.append(" - Max Nesting Depth (MND):   ").append(m.getMaxNestingDepth()).append("\n");
        sb.append(" - Maintainability Index:      ").append(m.getMaintainabilityIndex()).append(" / 100\n");
        sb.append(" - Lines of Code (LOC):        ").append(m.getLinesOfCode()).append(" (Lines ").append(m.getStartLine()).append("-").append(m.getEndLine()).append(")\n");
        sb.append(" - Code Smells Detected:       ").append(m.getCodeSmellsFormatted()).append("\n");

        JOptionPane.showMessageDialog(this, sb.toString(), "AVL Node Inspector: " + m.getMethodName() + "()", JOptionPane.INFORMATION_MESSAGE);
    }
}
