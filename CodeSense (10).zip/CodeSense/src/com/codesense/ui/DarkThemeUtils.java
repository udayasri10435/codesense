package com.codesense.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Custom Dark Theme Component Factory for Swing.
 * Ensures 100% elimination of all white backgrounds, native OS white button overlays,
 * and light tab artifacts.
 */
public class DarkThemeUtils {

    public static final Color BG_OBSIDIAN = new Color(10, 14, 23);     // #0a0e17
    public static final Color PANEL_SLATE = new Color(15, 23, 42);     // #0f172a
    public static final Color CARD_NAVY = new Color(30, 41, 59);       // #1e293b
    public static final Color INPUT_DARK = new Color(31, 41, 55);      // #1f2937
    public static final Color BORDER_DARK = new Color(55, 65, 81);     // #374151

    public static final Color ACCENT_BLUE = new Color(37, 99, 235);    // #2563eb
    public static final Color ACCENT_CYAN = new Color(56, 189, 248);   // #38bdf8
    public static final Color ACCENT_EMERALD = new Color(52, 211, 153);// #34d399
    public static final Color ACCENT_PURPLE = new Color(168, 85, 247); // #a855f7
    public static final Color ACCENT_AMBER = new Color(245, 158, 11);  // #f59e0b
    public static final Color ACCENT_RED = new Color(239, 68, 68);     // #ef4444

    public static final Color TEXT_BRIGHT = new Color(248, 250, 252);  // #f8fafc
    public static final Color TEXT_MUTED = new Color(148, 163, 184);   // #94a3b8

    /**
     * Custom JButton implementation that bypasses native Look & Feel white fills.
     */
    public static class CustomDarkButton extends JButton {
        private Color normalBg;
        private Color hoverBg;
        private Color activeBg;
        private boolean isHovered = false;

        public CustomDarkButton(String text, Color bg, Color fg) {
            super(text);
            this.normalBg = bg;
            this.hoverBg = bg.brighter();
            this.activeBg = bg.darker();
            setForeground(fg);
            setFont(new Font("Segoe UI", Font.BOLD, 12));
            setFocusPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setBorder(new EmptyBorder(8, 16, 8, 16));
            setCursor(new Cursor(Cursor.HAND_CURSOR));

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    isHovered = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    isHovered = false;
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            if (getModel().isPressed()) {
                g2.setColor(activeBg);
            } else if (isHovered) {
                g2.setColor(hoverBg);
            } else {
                g2.setColor(normalBg);
            }

            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
            g2.setColor(BORDER_DARK);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);

            g2.dispose();
            super.paintComponent(g);
        }
    }

    /**
     * Apply strict dark styling to JTable to eliminate white headers and white row backgrounds.
     */
    public static void applyDarkTableStyle(JTable table) {
        table.setBackground(PANEL_SLATE);
        table.setForeground(TEXT_BRIGHT);
        table.setGridColor(BORDER_DARK);
        table.setRowHeight(32);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        // Dark Table Header
        JTableHeader header = table.getTableHeader();
        header.setOpaque(false);
        header.setBackground(CARD_NAVY);
        header.setForeground(ACCENT_CYAN);
        header.setFont(new Font("Segoe UI", Font.BOLD, 12));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, ACCENT_BLUE));

        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                lbl.setBackground(CARD_NAVY);
                lbl.setForeground(ACCENT_CYAN);
                lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
                lbl.setHorizontalAlignment(JLabel.CENTER);
                lbl.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 1, BORDER_DARK));
                return lbl;
            }
        };
        header.setDefaultRenderer(headerRenderer);

        // Dark Table Cells
        DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (isSelected) {
                    c.setBackground(ACCENT_BLUE);
                    c.setForeground(Color.WHITE);
                } else {
                    c.setBackground(row % 2 == 0 ? PANEL_SLATE : new Color(18, 28, 48));
                    c.setForeground(TEXT_BRIGHT);
                }
                ((JLabel) c).setHorizontalAlignment(JLabel.CENTER);
                return c;
            }
        };
        table.setDefaultRenderer(Object.class, cellRenderer);
    }

    /**
     * Dark styling for JSpinner and inner JTextField.
     */
    public static void applyDarkSpinnerStyle(JSpinner spinner) {
        spinner.setBackground(INPUT_DARK);
        spinner.setForeground(TEXT_BRIGHT);
        spinner.setBorder(BorderFactory.createLineBorder(BORDER_DARK, 1));

        JComponent editor = spinner.getEditor();
        if (editor instanceof JSpinner.DefaultEditor) {
            JTextField tf = ((JSpinner.DefaultEditor) editor).getTextField();
            tf.setBackground(INPUT_DARK);
            tf.setForeground(ACCENT_CYAN);
            tf.setCaretColor(TEXT_BRIGHT);
            tf.setFont(new Font("Segoe UI", Font.BOLD, 13));
        }

        for (Component child : spinner.getComponents()) {
            if (child instanceof JButton) {
                JButton btn = (JButton) child;
                btn.setBackground(CARD_NAVY);
                btn.setForeground(TEXT_BRIGHT);
                btn.setBorder(BorderFactory.createLineBorder(BORDER_DARK));
            }
        }
    }
}
