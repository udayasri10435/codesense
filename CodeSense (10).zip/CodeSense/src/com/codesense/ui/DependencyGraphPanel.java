package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Class Dependency & Routine Coupling Graph Visualizer.
 */
public class DependencyGraphPanel extends JPanel {

    private List<MethodMetrics> methods;

    public DependencyGraphPanel() {
        this.methods = new ArrayList<>();
        setBackground(BG_OBSIDIAN);
    }

    public void setMethods(List<MethodMetrics> methods) {
        this.methods = methods != null ? methods : new ArrayList<>();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        if (methods == null || methods.isEmpty()) {
            g2d.setColor(TEXT_MUTED);
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 15));
            String msg = "No routines loaded. Run a Workspace Scan to render Dependency Coupling Graph.";
            FontMetrics fm = g2d.getFontMetrics();
            g2d.drawString(msg, (width - fm.stringWidth(msg)) / 2, height / 2);
            return;
        }

        // Header Title
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 13));
        g2d.setColor(ACCENT_CYAN);
        g2d.drawString("🕸️ Class Dependency & Routine Coupling Graph", 20, 30);

        // Group methods by Class Name
        Map<String, List<MethodMetrics>> classMap = new LinkedHashMap<>();
        for (MethodMetrics m : methods) {
            classMap.computeIfAbsent(m.getClassName(), k -> new ArrayList<>()).add(m);
        }

        int n = classMap.size();
        if (n == 0) return;

        int centerX = width / 2;
        int centerY = height / 2 + 10;
        int radius = Math.min(width, height) / 3;

        List<String> classNames = new ArrayList<>(classMap.keySet());
        int[] nodeX = new int[n];
        int[] nodeY = new int[n];

        for (int i = 0; i < n; i++) {
            double angle = (2 * Math.PI * i) / n;
            nodeX[i] = centerX + (int) (radius * Math.cos(angle));
            nodeY[i] = centerY + (int) (radius * Math.sin(angle));
        }

        // Draw Inter-Class Coupling Connections
        g2d.setStroke(new BasicStroke(1.8f));
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                g2d.setColor(new Color(51, 65, 85, 140));
                g2d.drawLine(nodeX[i], nodeY[i], nodeX[j], nodeY[j]);
            }
        }

        // Draw Class Nodes
        int nodeSize = 65;
        for (int i = 0; i < n; i++) {
            String className = classNames.get(i);
            List<MethodMetrics> mList = classMap.get(className);

            double maxScore = 0;
            for (MethodMetrics m : mList) {
                if (m.getComplexityScore() > maxScore) maxScore = m.getComplexityScore();
            }

            Color color = ACCENT_EMERALD;
            if (maxScore >= 25) color = ACCENT_PURPLE;
            else if (maxScore >= 15) color = ACCENT_RED;
            else if (maxScore >= 8) color = ACCENT_AMBER;

            // Glow Ring
            g2d.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 50));
            g2d.fillOval(nodeX[i] - nodeSize / 2 - 5, nodeY[i] - nodeSize / 2 - 5, nodeSize + 10, nodeSize + 10);

            // Node Circle
            g2d.setColor(color);
            g2d.fillOval(nodeX[i] - nodeSize / 2, nodeY[i] - nodeSize / 2, nodeSize, nodeSize);
            g2d.setColor(Color.WHITE);
            g2d.setStroke(new BasicStroke(2.0f));
            g2d.drawOval(nodeX[i] - nodeSize / 2, nodeY[i] - nodeSize / 2, nodeSize, nodeSize);

            // Label
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 11));
            FontMetrics fm = g2d.getFontMetrics();
            int tx = nodeX[i] - (fm.stringWidth(className) / 2);
            int ty = nodeY[i] + 4;
            g2d.drawString(className, tx, ty);

            g2d.setFont(new Font("Segoe UI", Font.PLAIN, 9));
            String sub = mList.size() + " methods";
            fm = g2d.getFontMetrics();
            g2d.drawString(sub, nodeX[i] - (fm.stringWidth(sub) / 2), ty + 14);
        }
    }
}
