package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.features.TechnicalDebtEstimator;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Technical Debt Refactoring ROI & Financial Cost Savings Calculator Panel.
 */
public class ROICalculatorPanel extends JPanel {

    private List<MethodMetrics> methods;
    private final JSpinner hourlyRateSpinner;
    private final JLabel estDebtHoursLabel;
    private final JLabel totalRemediationCostLabel;
    private final JLabel annualMaintenanceSavingsLabel;
    private final JLabel bugReductionPercentLabel;

    public ROICalculatorPanel() {
        this.methods = new ArrayList<>();
        setLayout(new BorderLayout());
        setBackground(PANEL_SLATE);

        // Header
        JPanel banner = new JPanel(new BorderLayout());
        banner.setBackground(CARD_NAVY);
        banner.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK),
                BorderFactory.createEmptyBorder(12, 16, 12, 16)
        ));

        JLabel title = new JLabel("💰 Technical Debt ROI & Financial Cost Savings Calculator");
        title.setFont(new Font("Segoe UI", Font.BOLD, 14));
        title.setForeground(ACCENT_CYAN);

        banner.add(title, BorderLayout.WEST);
        add(banner, BorderLayout.NORTH);

        // Content
        JPanel content = new JPanel(new GridLayout(2, 2, 16, 16));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        // Control Box
        JPanel ctrlCard = createCard("DEVELOPER HOURLY RATE CONFIGURATION");
        JPanel ctrlSub = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        ctrlSub.setOpaque(false);

        JLabel rateLbl = new JLabel("Dev Rate ($/hr):");
        rateLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        rateLbl.setForeground(TEXT_BRIGHT);

        hourlyRateSpinner = new JSpinner(new SpinnerNumberModel(85.0, 20.0, 500.0, 5.0));
        applyDarkSpinnerStyle(hourlyRateSpinner);

        hourlyRateSpinner.addChangeListener(e -> recalculateROI());

        ctrlSub.add(rateLbl);
        ctrlSub.add(hourlyRateSpinner);
        ctrlCard.add(ctrlSub, BorderLayout.CENTER);

        // Card 1: Estimated Debt Hours
        JPanel card1 = createCard("ESTIMATED REFACTORING EFFORT");
        estDebtHoursLabel = createBigLabel(card1, "0.0 Hours", ACCENT_CYAN);

        // Card 2: Total Remediation Cost
        JPanel card2 = createCard("TOTAL REMEDIATION INVESTMENT");
        totalRemediationCostLabel = createBigLabel(card2, "$0.00", ACCENT_AMBER);

        // Card 3: 3-Year Maintenance Savings
        JPanel card3 = createCard("PROJECTED 3-YEAR MAINTENANCE SAVINGS");
        annualMaintenanceSavingsLabel = createBigLabel(card3, "$0.00 / yr", ACCENT_EMERALD);

        // Card 4: Bug Risk Reduction
        JPanel card4 = createCard("ESTIMATED BUG DENSITY REDUCTION");
        bugReductionPercentLabel = createBigLabel(card4, "0.0%", ACCENT_PURPLE);

        content.add(ctrlCard);
        content.add(card1);
        content.add(card2);
        content.add(card3);
        add(content, BorderLayout.CENTER);
    }

    private JPanel createCard(String titleText) {
        JPanel card = new JPanel(new BorderLayout(0, 8));
        card.setBackground(CARD_NAVY);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_DARK, 1),
                BorderFactory.createEmptyBorder(14, 14, 14, 14)
        ));

        JLabel title = new JLabel(titleText);
        title.setFont(new Font("Segoe UI", Font.BOLD, 11));
        title.setForeground(TEXT_MUTED);

        card.add(title, BorderLayout.NORTH);
        return card;
    }

    private JLabel createBigLabel(JPanel card, String initialText, Color accent) {
        JLabel lbl = new JLabel(initialText);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lbl.setForeground(accent);
        card.add(lbl, BorderLayout.CENTER);
        return lbl;
    }

    public void setMethods(List<MethodMetrics> methods) {
        this.methods = methods != null ? methods : new ArrayList<>();
        recalculateROI();
    }

    private void recalculateROI() {
        if (methods == null || methods.isEmpty()) return;

        double rate = ((Number) hourlyRateSpinner.getValue()).doubleValue();
        TechnicalDebtEstimator.TechnicalDebtSummary debt = TechnicalDebtEstimator.calculateTechnicalDebt(methods);

        int criticalCount = 0;
        int highCount = 0;
        for (MethodMetrics m : methods) {
            if (m.getRiskLevel() == MethodMetrics.RiskLevel.CRITICAL) criticalCount++;
            else if (m.getRiskLevel() == MethodMetrics.RiskLevel.HIGH) highCount++;
        }

        double hours = debt.getTotalPersonHours();
        double initialCost = hours * rate;
        double annualSavings = initialCost * 1.85; // Refactoring saves 1.85x maintenance effort per year
        double bugReduction = Math.min(85.0, (criticalCount * 18.0) + (highCount * 8.0));

        estDebtHoursLabel.setText(String.format("%.1f Person-Hours", hours));
        totalRemediationCostLabel.setText(String.format("$%,.2f", initialCost));
        annualMaintenanceSavingsLabel.setText(String.format("$%,.2f / yr", annualSavings));
        bugReductionPercentLabel.setText(String.format("-%.1f%% Bugs", bugReduction));
    }
}
