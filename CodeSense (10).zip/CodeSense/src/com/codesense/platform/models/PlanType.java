package com.codesense.platform.models;

public enum PlanType {
    FREE,
    PRO,
    TEAM,
    ENTERPRISE,
    EDUCATION
}
