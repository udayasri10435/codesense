package com.codesense.platform.db;

import java.io.*;
import java.util.*;

/**
 * A lightweight, zero-dependency embedded database using Java Object Serialization.
 * This simulates a real persistence layer for users, organizations, and plans
 * while keeping the project standalone.
 */
public class LocalDatabaseManager {
    
    private static final String DB_DIR = ".codesense_db";
    
    // In-memory cache
    private Map<String, Object> cache = new HashMap<>();

    public LocalDatabaseManager() {
        File dir = new File(DB_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }
    
    public <T extends Serializable> void save(String key, T object) {
        cache.put(key, object);
        File file = new File(DB_DIR, key + ".dat");
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(object);
        } catch (IOException e) {
            System.err.println("[DB Error] Failed to save " + key + ": " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public <T extends Serializable> T load(String key, Class<T> clazz) {
        if (cache.containsKey(key)) {
            return clazz.cast(cache.get(key));
        }
        File file = new File(DB_DIR, key + ".dat");
        if (!file.exists()) return null;
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            Object obj = ois.readObject();
            if (clazz.isInstance(obj)) {
                cache.put(key, obj);
                return clazz.cast(obj);
            }
        } catch (Exception e) {
            System.err.println("[DB Error] Failed to load " + key + ": " + e.getMessage());
        }
        return null;
    }
    
    public <T extends Serializable> List<T> loadAll(String prefix, Class<T> clazz) {
        List<T> results = new ArrayList<>();
        File dir = new File(DB_DIR);
        if (dir.exists()) {
            File[] files = dir.listFiles((d, name) -> name.startsWith(prefix) && name.endsWith(".dat"));
            if (files != null) {
                for (File file : files) {
                    String key = file.getName().replace(".dat", "");
                    T obj = load(key, clazz);
                    if (obj != null) {
                        results.add(obj);
                    }
                }
            }
        }
        return results;
    }
    
    public void delete(String key) {
        cache.remove(key);
        File file = new File(DB_DIR, key + ".dat");
        if (file.exists()) {
            file.delete();
        }
    }
}
