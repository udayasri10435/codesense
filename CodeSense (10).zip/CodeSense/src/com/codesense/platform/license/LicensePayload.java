package com.codesense.platform.license;

import com.codesense.platform.models.PlanType;
import java.io.Serializable;

public class LicensePayload implements Serializable {
    private static final long serialVersionUID = 1L;

    private String serialCode;
    private PlanType plan;
    private String customerId;
    private long issueDate;
    private long expiryDate;
    private int activationLimit;
    private String signature;

    public LicensePayload(String serialCode, PlanType plan, String customerId, long issueDate, long expiryDate, int activationLimit, String signature) {
        this.serialCode = serialCode;
        this.plan = plan;
        this.customerId = customerId;
        this.issueDate = issueDate;
        this.expiryDate = expiryDate;
        this.activationLimit = activationLimit;
        this.signature = signature;
    }

    public String getSerialCode() { return serialCode; }
    public PlanType getPlan() { return plan; }
    public String getCustomerId() { return customerId; }
    public long getIssueDate() { return issueDate; }
    public long getExpiryDate() { return expiryDate; }
    public int getActivationLimit() { return activationLimit; }
    public String getSignature() { return signature; }
    
    public String getRawPayloadForVerification() {
        return serialCode + "|" + plan.name() + "|" + customerId + "|" + issueDate + "|" + expiryDate + "|" + activationLimit;
    }
}
