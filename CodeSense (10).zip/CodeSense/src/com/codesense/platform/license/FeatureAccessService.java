package com.codesense.platform.license;

import com.codesense.platform.models.PlanType;

public class FeatureAccessService {

    public enum Feature {
        ADVANCED_ANALYSIS,
        TECHNICAL_DEBT,
        ROI_CALCULATOR,
        REFACTORING_SIMULATOR,
        TEAM_DASHBOARD,
        CI_CD,
        ENTERPRISE_CONTROLS,
        EDUCATION_DASHBOARD
    }

    private final LicenseManager licenseManager;

    public FeatureAccessService(LicenseManager licenseManager) {
        this.licenseManager = licenseManager;
    }

    public boolean hasFeature(Feature feature) {
        PlanType plan = licenseManager.getCurrentPlan();

        switch (feature) {
            case ADVANCED_ANALYSIS:
            case TECHNICAL_DEBT:
            case ROI_CALCULATOR:
            case REFACTORING_SIMULATOR:
                return plan == PlanType.PRO || plan == PlanType.TEAM || plan == PlanType.ENTERPRISE || plan == PlanType.EDUCATION;
            
            case TEAM_DASHBOARD:
            case CI_CD:
                return plan == PlanType.TEAM || plan == PlanType.ENTERPRISE;
            
            case ENTERPRISE_CONTROLS:
                return plan == PlanType.ENTERPRISE;
            
            case EDUCATION_DASHBOARD:
                return plan == PlanType.EDUCATION;
                
            default:
                return true;
        }
    }

    public boolean canAccessTab(String tabKey) {
        if ("DebtCost".equals(tabKey)) return hasFeature(Feature.TECHNICAL_DEBT);
        if ("ROI".equals(tabKey)) return hasFeature(Feature.ROI_CALCULATOR);
        if ("Simulator".equals(tabKey)) return hasFeature(Feature.REFACTORING_SIMULATOR);
        return true;
    }
}
