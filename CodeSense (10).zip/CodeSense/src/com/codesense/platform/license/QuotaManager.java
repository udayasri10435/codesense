package com.codesense.platform.license;

import com.codesense.platform.db.LocalDatabaseManager;
import com.codesense.platform.models.PlanType;

import java.io.Serializable;

public class QuotaManager {

    private static final String QUOTA_DB_KEY = "free_tier_quota";
    private static final int INITIAL_FREE_POINTS = 1000;

    private final LocalDatabaseManager db;
    private final LicenseManager licenseManager;
    private QuotaRecord currentQuota;

    public static class QuotaRecord implements Serializable {
        private static final long serialVersionUID = 1L;
        public int pointsRemaining;

        public QuotaRecord(int pointsRemaining) {
            this.pointsRemaining = pointsRemaining;
        }
    }

    public QuotaManager(LocalDatabaseManager db, LicenseManager licenseManager) {
        this.db = db;
        this.licenseManager = licenseManager;
        loadQuota();
    }

    private void loadQuota() {
        this.currentQuota = db.load(QUOTA_DB_KEY, QuotaRecord.class);
        if (this.currentQuota == null) {
            this.currentQuota = new QuotaRecord(INITIAL_FREE_POINTS);
            db.save(QUOTA_DB_KEY, this.currentQuota);
        }
    }

    public int getPointsRemaining() {
        return currentQuota.pointsRemaining;
    }

    public boolean canConsumePoints(int requiredPoints) {
        if (licenseManager.getCurrentPlan() != PlanType.FREE) {
            return true; // Commercial plans have unlimited points
        }
        return currentQuota.pointsRemaining >= requiredPoints;
    }

    public void consumePoints(int points) {
        if (licenseManager.getCurrentPlan() != PlanType.FREE) {
            return; // Commercial plans don't consume points
        }
        
        currentQuota.pointsRemaining = Math.max(0, currentQuota.pointsRemaining - points);
        db.save(QUOTA_DB_KEY, currentQuota);
    }
}
