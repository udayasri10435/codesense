package com.codesense.ds;

import java.util.ArrayList;
import java.util.List;

/**
 * Standard Unbalanced Binary Search Tree (BST) Node.
 * FOR BENCHMARKING PURPOSES ONLY - NOT USED IN PRIMARY ANALYTICAL PIPELINE.
 *
 * @param <T> Payload type stored within tree nodes
 */
public class BSTNode<T> {
    private final double key;
    private final List<T> dataList;
    private BSTNode<T> left;
    private BSTNode<T> right;

    public BSTNode(double key, T data) {
        this.key = key;
        this.dataList = new ArrayList<>();
        this.dataList.add(data);
        this.left = null;
        this.right = null;
    }

    public double getKey() {
        return key;
    }

    public List<T> getDataList() {
        return dataList;
    }

    public void addData(T data) {
        this.dataList.add(data);
    }

    public BSTNode<T> getLeft() {
        return left;
    }

    public void setLeft(BSTNode<T> left) {
        this.left = left;
    }

    public BSTNode<T> getRight() {
        return right;
    }

    public void setRight(BSTNode<T> right) {
        this.right = right;
    }
}
