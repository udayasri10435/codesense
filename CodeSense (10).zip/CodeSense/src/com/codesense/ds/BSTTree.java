package com.codesense.ds;

import java.util.ArrayList;
import java.util.List;

/**
 * Standard Unbalanced Binary Search Tree (BST) Implementation.
 * FOR BENCHMARKING PURPOSES ONLY - NOT USED IN PRIMARY ANALYTICAL PIPELINE.
 *
 * Demonstrates how pre-sorted or sequential inputs cause height degeneration toward O(N),
 * providing empirical evidence justifying the choice of self-balancing AVL Trees (O(log N)).
 *
 * @param <T> Payload type stored within tree nodes
 */
public class BSTTree<T> {

    private BSTNode<T> root;
    private int size;

    public BSTTree() {
        this.root = null;
        this.size = 0;
    }

    public BSTNode<T> getRoot() {
        return root;
    }

    public int getSize() {
        return size;
    }

    public int getHeight() {
        return getNodeHeight(root);
    }

    private int getNodeHeight(BSTNode<T> node) {
        if (node == null) return 0;
        return 1 + Math.max(getNodeHeight(node.getLeft()), getNodeHeight(node.getRight()));
    }

    public void insert(double key, T data) {
        root = insertRecursive(root, key, data);
        size++;
    }

    private BSTNode<T> insertRecursive(BSTNode<T> node, double key, T data) {
        if (node == null) {
            return new BSTNode<>(key, data);
        }

        double diff = key - node.getKey();
        if (Math.abs(diff) < 0.0001) {
            node.addData(data);
            return node;
        } else if (key < node.getKey()) {
            node.setLeft(insertRecursive(node.getLeft(), key, data));
        } else {
            node.setRight(insertRecursive(node.getRight(), key, data));
        }

        return node;
    }

    public BSTNode<T> searchNode(double key) {
        BSTNode<T> curr = root;
        while (curr != null) {
            double diff = key - curr.getKey();
            if (Math.abs(diff) < 0.0001) {
                return curr;
            } else if (key < curr.getKey()) {
                curr = curr.getLeft();
            } else {
                curr = curr.getRight();
            }
        }
        return null;
    }

    public List<T> rangeSearch(double minKey, double maxKey) {
        List<T> result = new ArrayList<>();
        rangeSearchRecursive(root, minKey, maxKey, result);
        return result;
    }

    private void rangeSearchRecursive(BSTNode<T> node, double minKey, double maxKey, List<T> result) {
        if (node == null) return;
        if (node.getKey() > minKey) {
            rangeSearchRecursive(node.getLeft(), minKey, maxKey, result);
        }
        if (node.getKey() >= minKey && node.getKey() <= maxKey) {
            result.addAll(node.getDataList());
        }
        if (node.getKey() < maxKey) {
            rangeSearchRecursive(node.getRight(), minKey, maxKey, result);
        }
    }

    public BSTNode<T> getMinNode() {
        if (root == null) return null;
        BSTNode<T> curr = root;
        while (curr.getLeft() != null) {
            curr = curr.getLeft();
        }
        return curr;
    }

    public BSTNode<T> getMaxNode() {
        if (root == null) return null;
        BSTNode<T> curr = root;
        while (curr.getRight() != null) {
            curr = curr.getRight();
        }
        return curr;
    }
}
