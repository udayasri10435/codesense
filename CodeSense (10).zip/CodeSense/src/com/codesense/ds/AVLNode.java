package com.codesense.ds;

import java.util.ArrayList;
import java.util.List;

/**
 * Generic node representation for the native self-balancing AVL Tree.
 *
 * @param <T> Payload type stored within the node
 */
public class AVLNode<T> {
    private double key;
    private List<T> dataList;
    private int height;
    private AVLNode<T> left;
    private AVLNode<T> right;

    public AVLNode(double key, T data) {
        this.key = key;
        this.dataList = new ArrayList<>();
        if (data != null) {
            this.dataList.add(data);
        }
        this.height = 1;
        this.left = null;
        this.right = null;
    }

    public double getKey() {
        return key;
    }

    public void setKey(double key) {
        this.key = key;
    }

    public List<T> getDataList() {
        return dataList;
    }

    public void addData(T data) {
        if (data != null) {
            this.dataList.add(data);
        }
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public AVLNode<T> getLeft() {
        return left;
    }

    public void setLeft(AVLNode<T> left) {
        this.left = left;
    }

    public AVLNode<T> getRight() {
        return right;
    }

    public void setRight(AVLNode<T> right) {
        this.right = right;
    }

    @Override
    public String toString() {
        return String.format("AVLNode[Key=%.2f, Items=%d, Height=%d]", key, dataList.size(), height);
    }
}
