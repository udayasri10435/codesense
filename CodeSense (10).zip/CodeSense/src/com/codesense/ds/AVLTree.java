package com.codesense.ds;

import java.util.ArrayList;
import java.util.List;

/**
 * Custom Native Implementation of a Self-Balancing AVL Tree.
 * Maintains strict height balance factor |BF| <= 1 for logarithmic search/insertion.
 *
 * @param <T> Payload type stored within tree nodes
 */
public class AVLTree<T> {

    private AVLNode<T> root;
    private int size;
    private int totalRotations;
    private final List<String> rotationLogs;

    public AVLTree() {
        this.root = null;
        this.size = 0;
        this.totalRotations = 0;
        this.rotationLogs = new ArrayList<>();
    }

    public AVLNode<T> getRoot() {
        return root;
    }

    public int getSize() {
        return size;
    }

    public int getTotalRotations() {
        return totalRotations;
    }

    public List<String> getRotationLogs() {
        return rotationLogs;
    }

    public int getHeight() {
        return getNodeHeight(root);
    }

    private int getNodeHeight(AVLNode<T> node) {
        return node == null ? 0 : node.getHeight();
    }

    private int getBalanceFactor(AVLNode<T> node) {
        return node == null ? 0 : getNodeHeight(node.getLeft()) - getNodeHeight(node.getRight());
    }

    private void updateHeight(AVLNode<T> node) {
        if (node != null) {
            node.setHeight(1 + Math.max(getNodeHeight(node.getLeft()), getNodeHeight(node.getRight())));
        }
    }

    /**
     * Right Rotation (LL Rotation)
     * Used when left child is left-heavy (balance factor > 1 and new key < left key)
     */
    private AVLNode<T> rotateRight(AVLNode<T> y) {
        AVLNode<T> x = y.getLeft();
        AVLNode<T> T2 = x.getRight();

        // Perform rotation
        x.setRight(y);
        y.setLeft(T2);

        // Update heights
        updateHeight(y);
        updateHeight(x);

        totalRotations++;
        rotationLogs.add(String.format("Single Right (LL) Rotation executed at Node Key=%.2f", y.getKey()));

        return x;
    }

    /**
     * Left Rotation (RR Rotation)
     * Used when right child is right-heavy (balance factor < -1 and new key > right key)
     */
    private AVLNode<T> rotateLeft(AVLNode<T> x) {
        AVLNode<T> y = x.getRight();
        AVLNode<T> T2 = y.getLeft();

        // Perform rotation
        y.setLeft(x);
        x.setRight(T2);

        // Update heights
        updateHeight(x);
        updateHeight(y);

        totalRotations++;
        rotationLogs.add(String.format("Single Left (RR) Rotation executed at Node Key=%.2f", x.getKey()));

        return y;
    }

    /**
     * Insert a key and item payload into the AVL tree.
     * Rebalances automatically using single or double rotations.
     */
    public void insert(double key, T data) {
        root = insertRecursive(root, key, data);
        size++;
    }

    private AVLNode<T> insertRecursive(AVLNode<T> node, double key, T data) {
        // 1. Standard BST insertion
        if (node == null) {
            return new AVLNode<>(key, data);
        }

        // Using small epsilon comparison for floating point keys
        double diff = key - node.getKey();
        if (Math.abs(diff) < 0.0001) {
            // Duplicate score - append payload to existing node list
            node.addData(data);
            return node;
        } else if (key < node.getKey()) {
            node.setLeft(insertRecursive(node.getLeft(), key, data));
        } else {
            node.setRight(insertRecursive(node.getRight(), key, data));
        }

        // 2. Update height of current node
        updateHeight(node);

        // 3. Get balance factor to check if node became unbalanced
        int balance = getBalanceFactor(node);

        // 4. Rebalance if needed

        // Left Left Case (LL)
        if (balance > 1 && key < node.getLeft().getKey()) {
            return rotateRight(node);
        }

        // Right Right Case (RR)
        if (balance < -1 && key > node.getRight().getKey()) {
            return rotateLeft(node);
        }

        // Left Right Case (LR)
        if (balance > 1 && key > node.getLeft().getKey()) {
            rotationLogs.add(String.format("LR Double Rotation initiated at Key=%.2f", node.getKey()));
            node.setLeft(rotateLeft(node.getLeft()));
            return rotateRight(node);
        }

        // Right Left Case (RL)
        if (balance < -1 && key < node.getRight().getKey()) {
            rotationLogs.add(String.format("RL Double Rotation initiated at Key=%.2f", node.getKey()));
            node.setRight(rotateRight(node.getRight()));
            return rotateLeft(node);
        }

        return node;
    }

    /**
     * Search for a node with the given key in O(log n) time
     */
    public AVLNode<T> searchNode(double key) {
        AVLNode<T> curr = root;
        while (curr != null) {
            double diff = key - curr.getKey();
            if (Math.abs(diff) < 0.0001) {
                return curr;
            } else if (key < curr.getKey()) {
                curr = curr.getLeft();
            } else {
                curr = curr.getRight();
            }
        }
        return null;
    }

    /**
     * In-Order Traversal returning all payloads sorted by key (complexity score ascending)
     */
    public List<T> inOrderTraversal() {
        List<T> result = new ArrayList<>();
        inOrderRecursive(root, result);
        return result;
    }

    private void inOrderRecursive(AVLNode<T> node, List<T> result) {
        if (node != null) {
            inOrderRecursive(node.getLeft(), result);
            result.addAll(node.getDataList());
            inOrderRecursive(node.getRight(), result);
        }
    }

    /**
     * Balanced Range Query: Extracts payloads whose key falls in [minKey, maxKey]
     * Leverages logarithmic sub-tree pruning to avoid scanning unneeded branches.
     */
    public List<T> rangeSearch(double minKey, double maxKey) {
        List<T> result = new ArrayList<>();
        rangeSearchRecursive(root, minKey, maxKey, result);
        return result;
    }

    private void rangeSearchRecursive(AVLNode<T> node, double minKey, double maxKey, List<T> result) {
        if (node == null) {
            return;
        }

        // If left child can fall into range, explore left
        if (node.getKey() > minKey) {
            rangeSearchRecursive(node.getLeft(), minKey, maxKey, result);
        }

        // If current node falls into range, include payload
        if (node.getKey() >= minKey && node.getKey() <= maxKey) {
            result.addAll(node.getDataList());
        }

        // If right child can fall into range, explore right
        if (node.getKey() < maxKey) {
            rangeSearchRecursive(node.getRight(), minKey, maxKey, result);
        }
    }

    /**
     * Get minimum key node in O(log n) time
     */
    public AVLNode<T> getMinNode() {
        if (root == null) return null;
        AVLNode<T> curr = root;
        while (curr.getLeft() != null) {
            curr = curr.getLeft();
        }
        return curr;
    }

    /**
     * Get maximum key node in O(log n) time
     */
    public AVLNode<T> getMaxNode() {
        if (root == null) return null;
        AVLNode<T> curr = root;
        while (curr.getRight() != null) {
            curr = curr.getRight();
        }
        return curr;
    }

    public void clear() {
        root = null;
        size = 0;
        totalRotations = 0;
        rotationLogs.clear();
    }
}
