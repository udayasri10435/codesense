package com.codesense;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.analyzer.WorkspaceScanner;
import com.codesense.ds.AVLTree;
import com.codesense.features.AlertManager;
import com.codesense.features.SnapshotManager;

import java.io.File;
import java.util.List;

public class VerifyCodeSense {
    public static void main(String[] args) {
        System.out.println("==========================================================");
        System.out.println("  CodeSense Automated Verification Suite & Test Suite     ");
        System.out.println("==========================================================");

        // 1. Verify AVL Tree Core Rotations & Range Search
        System.out.println("\n[TEST 1] Native AVL Tree Data Structure Verification...");
        AVLTree<MethodMetrics> avl = new AVLTree<>();

        MethodMetrics m1 = new MethodMetrics("m1", "TestClass", "path", 1, 10, 2, 1, 1, 10, 0);
        MethodMetrics m2 = new MethodMetrics("m2", "TestClass", "path", 1, 15, 6, 4, 2, 15, 1);
        MethodMetrics m3 = new MethodMetrics("m3", "TestClass", "path", 1, 50, 14, 12, 4, 50, 2);
        MethodMetrics m4 = new MethodMetrics("m4", "TestClass", "path", 1, 30, 9, 7, 3, 30, 1);

        avl.insert(m1.getComplexityScore(), m1);
        avl.insert(m2.getComplexityScore(), m2);
        avl.insert(m3.getComplexityScore(), m3);
        avl.insert(m4.getComplexityScore(), m4);

        System.out.println(" -> Total Nodes Indexed: " + avl.getSize());
        System.out.println(" -> AVL Tree Height: " + avl.getHeight());
        System.out.println(" -> Total Rotations Triggered: " + avl.getTotalRotations());

        List<MethodMetrics> inOrder = avl.inOrderTraversal();
        System.out.println(" -> In-Order Sorted Complexity Scores:");
        for (MethodMetrics m : inOrder) {
            System.out.printf("     - %s: Score = %.2f\n", m.getMethodName(), m.getComplexityScore());
        }

        // Test Logarithmic Range Search
        System.out.println("\n[TEST 2] Logarithmic Sub-tree Range Query [10.0 <= Score <= 25.0]...");
        List<MethodMetrics> rangeResult = avl.rangeSearch(10.0, 25.0);
        for (MethodMetrics m : rangeResult) {
            System.out.printf("     - Match: %s (Score = %.2f)\n", m.getMethodName(), m.getComplexityScore());
        }

        // 2. Verify AST Parsing & Workspace Scanner
        System.out.println("\n[TEST 3] AST Workspace Routine Scanner Verification...");
        File samplesDir = new File("samples");
        WorkspaceScanner.ScanResult result = WorkspaceScanner.scanWorkspace(samplesDir);
        System.out.printf(" -> Scanned Files: %d | Indexed Methods: %d | LOC: %d\n",
                result.getScannedFilesCount(), result.getTotalMethodsCount(), result.getTotalLinesOfCode());

        System.out.println("\nIndexed Method Routines:");
        for (MethodMetrics m : result.getAvlTree().inOrderTraversal()) {
            System.out.printf("   ▸ %-25s | Score: %-6.2f | CC: %-2d | Cog: %-2d | MND: %-2d | MI: %-5.1f | Risk: %s\n",
                    m.getClassName() + "." + m.getMethodName() + "()",
                    m.getComplexityScore(), m.getCyclomaticComplexity(),
                    m.getCognitiveComplexity(), m.getMaxNestingDepth(),
                    m.getMaintainabilityIndex(), m.getRiskLevel().getLabel());
        }

        // 3. Verify Live Refactor Alerts & Export Fresh Reports
        System.out.println("\n[TEST 4] Live Refactor Alerts Verification...");
        AlertManager alertManager = new AlertManager();
        List<AlertManager.RefactorAlert> alerts = alertManager.evaluateMetrics(result.getAllMethods());
        for (AlertManager.RefactorAlert alert : alerts) {
            System.out.println("   🚨 " + alert);
        }

        try {
            com.codesense.exporter.ReportExporter.exportAll(result, alerts, new File("reports"));
            System.out.println("   ✓ Fresh reports exported to ./reports directory.");
        } catch (Exception e) {
            System.err.println("   ! Error exporting reports: " + e.getMessage());
        }

        // 4. Verify Trend Snapshots
        System.out.println("\n[TEST 5] Trend Revision Snapshots Verification...");
        SnapshotManager snapshotManager = new SnapshotManager();
        snapshotManager.captureSnapshot("Revision 1 (Base)", result.getAvlTree(), result.getAllMethods());
        snapshotManager.captureSnapshot("Revision 2 (Post-Refactor Sweep)", result.getAvlTree(), result.getAllMethods());

        System.out.println(snapshotManager.generateTrajectorySummary());

        System.out.println("\n==========================================================");
        System.out.println("  ALL CODESENSE VERIFICATION TESTS PASSED SUCCESSFULLY!  ");
        System.out.println("==========================================================");
    }
}
