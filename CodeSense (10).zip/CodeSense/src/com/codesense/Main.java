package com.codesense;

import com.codesense.cli.CodeSenseCLI;
import com.codesense.ui.CodeSenseDashboard;

import javax.swing.*;
import java.awt.*;

/**
 * Entry Point for CodeSense Analytical Utility.
 */
public class Main {
    public static void main(String[] args) {
        int exitCode = processArgs(args);
        if (exitCode != -1) {
            System.exit(exitCode);
        }
        
        // -1 means no arguments or invalid display environment, so proceed to GUI launch fallback
        launchGUI();
    }

    // Returns an exit code. Returns -1 if it should proceed to GUI launch.
    public static int processArgs(String[] args) {
        if (args.length > 0) {
            String primaryArg = args[0].toLowerCase();
            
            if (primaryArg.equals("--help") || primaryArg.equals("-h")) {
                printHelp();
                return 0;
            } else if (primaryArg.equals("--cli")) {
                launchCLI(args);
                return 0;
            } else if (primaryArg.equals("--analyze")) {
                if (args.length < 2) {
                    System.err.println("Error: --analyze requires a target path.");
                    printHelp();
                    return 1;
                }
                launchDirectAnalyze(args[1]);
                return 0;
            } else {
                System.err.println("Error: Unknown argument -> " + primaryArg);
                printHelp();
                return 1;
            }
        }

        // If no args, check headless
        if (GraphicsEnvironment.isHeadless()) {
            System.err.println("Error: No graphical display detected. Launching in CLI mode automatically.");
            launchCLI(new String[]{"--cli"});
            return 0;
        }

        return -1;
    }

    private static void printHelp() {
        System.out.println("=========================================================================");
        System.out.println("   CodeSense - Smart Code Complexity Analyzer Using Custom AVL Trees     ");
        System.out.println("=========================================================================");
        System.out.println("Usage:");
        System.out.println("  java -jar codesense.jar                  Launch the graphical UI (Swing)");
        System.out.println("  java -jar codesense.jar --cli            Launch interactive CLI mode");
        System.out.println("  java -jar codesense.jar --analyze <path> Directly analyze a file/folder");
        System.out.println("  java -jar codesense.jar --help, -h       Display this help message");
    }

    private static void launchCLI(String[] args) {
        com.codesense.platform.db.LocalDatabaseManager db = new com.codesense.platform.db.LocalDatabaseManager();
        com.codesense.platform.license.LicenseManager licenseManager = new com.codesense.platform.license.LicenseManager(db);
        CodeSenseCLI cli = new CodeSenseCLI(licenseManager);
        cli.startInteractiveShell();
    }
    
    private static void launchDirectAnalyze(String path) {
        com.codesense.platform.db.LocalDatabaseManager db = new com.codesense.platform.db.LocalDatabaseManager();
        com.codesense.platform.license.LicenseManager licenseManager = new com.codesense.platform.license.LicenseManager(db);
        CodeSenseCLI cli = new CodeSenseCLI(licenseManager);
        // The CodeSenseCLI processCommand method supports 'scan <path>' natively
        cli.processCommand("scan " + path);
        // After scan is complete, print out the in-order list to console 
        cli.processCommand("list");
    }

    private static void launchGUI() {
        SwingUtilities.invokeLater(() -> {
            com.codesense.platform.db.LocalDatabaseManager db = new com.codesense.platform.db.LocalDatabaseManager();
            com.codesense.platform.license.LicenseManager licenseManager = new com.codesense.platform.license.LicenseManager(db);
            com.codesense.platform.license.FeatureAccessService featureAccessService = new com.codesense.platform.license.FeatureAccessService(licenseManager);
            com.codesense.platform.license.QuotaManager quotaManager = new com.codesense.platform.license.QuotaManager(db, licenseManager);
            
            CodeSenseDashboard dashboard = new CodeSenseDashboard(licenseManager, featureAccessService, quotaManager);
            dashboard.setVisible(true);
        });
    }
}
