package com.codesense.analyzer;

import java.util.ArrayList;
import java.util.List;

/**
 * Enhanced Data Model representing full routine-level complexity metrics:
 * Cyclomatic Complexity, Cognitive Complexity, Max Nesting Depth, Lines of Code,
 * Parameter Count, Maintainability Index, and Code Smells.
 */
public class MethodMetrics implements Comparable<MethodMetrics> {
    private final String methodName;
    private final String className;
    private final String filePath;
    private final int startLine;
    private final int endLine;
    private final int cyclomaticComplexity;
    private final int cognitiveComplexity;
    private final int maxNestingDepth;
    private final int linesOfCode;
    private final int parameterCount;
    private final double maintainabilityIndex;
    private final double complexityScore;
    private final List<String> codeSmells;

    public enum RiskLevel {
        LOW("Low Complexity", "#10b981", "#064e3b"),
        MEDIUM("Moderate Risk", "#f59e0b", "#78350f"),
        HIGH("High Complexity", "#ef4444", "#7f1d1d"),
        CRITICAL("Critical Refactor Target", "#a855f7", "#581c87");

        private final String label;
        private final String colorHex;
        private final String bgHex;

        RiskLevel(String label, String colorHex, String bgHex) {
            this.label = label;
            this.colorHex = colorHex;
            this.bgHex = bgHex;
        }

        public String getLabel() {
            return label;
        }

        public String getColorHex() {
            return colorHex;
        }

        public String getBgHex() {
            return bgHex;
        }
    }

    public MethodMetrics(String methodName, String className, String filePath, int startLine, int endLine,
                         int cyclomaticComplexity, int cognitiveComplexity, int maxNestingDepth,
                         int linesOfCode, int parameterCount) {
        this.methodName = methodName;
        this.className = className;
        this.filePath = filePath;
        this.startLine = startLine;
        this.endLine = endLine;
        this.cyclomaticComplexity = cyclomaticComplexity;
        this.cognitiveComplexity = cognitiveComplexity;
        this.maxNestingDepth = maxNestingDepth;
        this.linesOfCode = linesOfCode;
        this.parameterCount = parameterCount;
        this.codeSmells = detectCodeSmells(cyclomaticComplexity, cognitiveComplexity, maxNestingDepth, linesOfCode, parameterCount);
        this.maintainabilityIndex = calculateMaintainabilityIndex(cyclomaticComplexity, linesOfCode);
        this.complexityScore = calculateFullComplexityScore(cyclomaticComplexity, cognitiveComplexity, maxNestingDepth, linesOfCode, parameterCount);
    }

    private List<String> detectCodeSmells(int cc, int cog, int mnd, int loc, int params) {
        List<String> smells = new ArrayList<>();
        if (loc > 40) smells.add("Long Method (LOC > 40)");
        if (cc > 10) smells.add("High Cyclomatic Complexity (CC > 10)");
        if (cog > 12) smells.add("Cognitive Overload (Cog > 12)");
        if (mnd > 3) smells.add("Deep Arrow Anti-Pattern (Nesting > 3)");
        if (params > 4) smells.add("Excessive Parameters (Params > 4)");
        if (smells.isEmpty()) smells.add("Clean Routine");
        return smells;
    }

    /**
     * Calculates the Maintainability Index (MI) based on the standard SEI / Oman & Hagemeister (1992) formula:
     * MI = 171.0 - 5.2 * ln(HalsteadVolume) - 0.23 * CC - 16.2 * ln(LOC)
     * Normalized to a 0-100 scale: MI_normalized = max(0, min(100, (MI * 100.0) / 171.0))
     *
     * @param cc  Cyclomatic Complexity
     * @param loc Lines of Code
     * @return normalized Maintainability Index score (0 to 100)
     */
    private double calculateMaintainabilityIndex(int cc, int loc) {
        double volume = Math.max(1.0, loc * 5.5); // Estimated Halstead Volume based on token density
        double mi = 171.0 - (5.2 * Math.log(volume)) - (0.23 * cc) - (16.2 * Math.log(Math.max(1, loc)));
        mi = Math.max(0.0, Math.min(100.0, (mi * 100.0) / 171.0));
        return Math.round(mi * 10.0) / 10.0;
    }

    /**
     * Calculates the Full Architectural Complexity Score using a Custom-Weighted Composite Formula.
     * CITE/NOTE: Custom-weighted multi-attribute score (not a standard textbook formula):
     * Score = (CC * 1.1) + (Cog * 1.3) + (MND * 1.6) + (LOC * 0.06) + (Params * 0.8)
     * Weighting Rationale: Emphasizes nesting depth (1.6) and cognitive load (1.3) as primary drivers of mental trace complexity.
     */
    private double calculateFullComplexityScore(int cc, int cog, int mnd, int loc, int params) {
        // Custom-weighted composite architectural complexity formula
        double score = (cc * 1.1) + (cog * 1.3) + (mnd * 1.6) + (loc * 0.06) + (params * 0.8);
        return Math.round(score * 100.0) / 100.0;
    }

    public String getMethodName() {
        return methodName;
    }

    public String getClassName() {
        return className;
    }

    public String getFilePath() {
        return filePath;
    }

    public int getStartLine() {
        return startLine;
    }

    public int getEndLine() {
        return endLine;
    }

    public int getCyclomaticComplexity() {
        return cyclomaticComplexity;
    }

    public int getCognitiveComplexity() {
        return cognitiveComplexity;
    }

    public int getMaxNestingDepth() {
        return maxNestingDepth;
    }

    public int getLinesOfCode() {
        return linesOfCode;
    }

    public int getParameterCount() {
        return parameterCount;
    }

    public double getMaintainabilityIndex() {
        return maintainabilityIndex;
    }

    public double getComplexityScore() {
        return complexityScore;
    }

    public List<String> getCodeSmells() {
        return codeSmells;
    }

    public String getCodeSmellsFormatted() {
        return String.join(", ", codeSmells);
    }

    public RiskLevel getRiskLevel() {
        if (complexityScore >= 25.0 || cyclomaticComplexity > 15 || maxNestingDepth > 4) {
            return RiskLevel.CRITICAL;
        } else if (complexityScore >= 15.0 || cyclomaticComplexity > 9 || maxNestingDepth > 3) {
            return RiskLevel.HIGH;
        } else if (complexityScore >= 8.0 || cyclomaticComplexity > 4) {
            return RiskLevel.MEDIUM;
        } else {
            return RiskLevel.LOW;
        }
    }

    @Override
    public int compareTo(MethodMetrics o) {
        return Double.compare(this.complexityScore, o.complexityScore);
    }

    @Override
    public String toString() {
        return String.format("%s.%s() [Score=%.2f, CC=%d, Cog=%d, MND=%d, LOC=%d, MI=%.1f] (%s)",
                className, methodName, complexityScore, cyclomaticComplexity, cognitiveComplexity,
                maxNestingDepth, linesOfCode, maintainabilityIndex, getRiskLevel().getLabel());
    }
}
