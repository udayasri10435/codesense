package com.codesense.analyzer;

import com.codesense.ds.AVLTree;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Workspace package scanner supporting Java, Python, JS/TS, and C/C++ source files.
 * Recursively inspects directories, invokes CodeParser on discovered files, and populates the AVL Tree index.
 */
public class WorkspaceScanner {

    /**
     * Immutable data object encapsulating the output of a workspace scan operation.
     * Holds the populated AVL tree index, file and method metrics counts, and execution duration.
     */
    public static class ScanResult {
        private final AVLTree<MethodMetrics> avlTree;
        private final int scannedFilesCount;
        private final int totalMethodsCount;
        private final long totalLinesOfCode;
        private final long elapsedTimeMs;
        private final List<MethodMetrics> allMethods;

        /**
         * Constructs a new ScanResult container.
         *
         * @param avlTree           populated AVL tree containing indexed method metrics
         * @param scannedFilesCount total number of source code files scanned
         * @param totalMethodsCount total number of methods parsed and indexed
         * @param totalLinesOfCode  combined lines of code across all scanned methods
         * @param elapsedTimeMs     duration of the scan operation in milliseconds
         * @param allMethods        flat list of all parsed method metrics
         */
        public ScanResult(AVLTree<MethodMetrics> avlTree, int scannedFilesCount,
                          int totalMethodsCount, long totalLinesOfCode,
                          long elapsedTimeMs, List<MethodMetrics> allMethods) {
            this.avlTree = avlTree;
            this.scannedFilesCount = scannedFilesCount;
            this.totalMethodsCount = totalMethodsCount;
            this.totalLinesOfCode = totalLinesOfCode;
            this.elapsedTimeMs = elapsedTimeMs;
            this.allMethods = allMethods;
        }

        /**
         * @return populated AVL tree index
         */
        public AVLTree<MethodMetrics> getAvlTree() {
            return avlTree;
        }

        /**
         * @return count of scanned source files
         */
        public int getScannedFilesCount() {
            return scannedFilesCount;
        }

        /**
         * @return count of indexed methods
         */
        public int getTotalMethodsCount() {
            return totalMethodsCount;
        }

        /**
         * @return total lines of code scanned
         */
        public long getTotalLinesOfCode() {
            return totalLinesOfCode;
        }

        /**
         * @return total scan duration in milliseconds
         */
        public long getElapsedTimeMs() {
            return elapsedTimeMs;
        }

        /**
         * @return list of all parsed method metrics
         */
        public List<MethodMetrics> getAllMethods() {
            return allMethods;
        }
    }

    /**
     * Executes a full recursive scan on the given file or directory target path.
     *
     * @param targetPath directory or file path to scan
     * @return populated ScanResult container
     */
    public static ScanResult scanWorkspace(File targetPath) {
        long startTime = System.currentTimeMillis();
        AVLTree<MethodMetrics> tree = new AVLTree<>();
        List<File> sourceFiles = new ArrayList<>();
        List<MethodMetrics> allMethods = new ArrayList<>();

        Set<String> visitedPaths = new HashSet<>();
        collectSourceFiles(targetPath, sourceFiles, visitedPaths, 0);

        if (sourceFiles.isEmpty()) {
            System.out.println("[Info] No supported source files (.java, .py, .js, .ts, .c, .cpp) found in target path: " + (targetPath != null ? targetPath.getAbsolutePath() : "null"));
        }

        long totalLoc = 0;
        for (File file : sourceFiles) {
            try {
                List<MethodMetrics> methods = CodeParser.parseFile(file);
                if (methods != null) {
                    for (MethodMetrics m : methods) {
                        tree.insert(m.getComplexityScore(), m);
                        allMethods.add(m);
                        totalLoc += m.getLinesOfCode();
                    }
                }
            } catch (Throwable e) {
                System.err.println("[Warning] Skipping unparseable or corrupted file: " + file.getAbsolutePath() + " (" + e.getMessage() + ")");
            }
        }

        long elapsedTime = System.currentTimeMillis() - startTime;
        return new ScanResult(tree, sourceFiles.size(), allMethods.size(), totalLoc, elapsedTime, allMethods);
    }

    private static final int MAX_TRAVERSAL_DEPTH = 30;
    private static final int MAX_SCANNED_FILES = 50000;

    private static void collectSourceFiles(File file, List<File> accumulator, Set<String> visitedPaths, int depth) {
        if (file == null || !file.exists()) return;
        if (accumulator.size() >= MAX_SCANNED_FILES) {
            System.err.println("[Warning] Maximum scan file cutoff reached (" + MAX_SCANNED_FILES + " files). Truncating traversal.");
            return;
        }
        if (depth > MAX_TRAVERSAL_DEPTH) {
            System.err.println("[Warning] Maximum directory traversal depth reached at: " + file.getAbsolutePath());
            return;
        }

        try {
            String canonicalPath = file.getCanonicalPath();
            if (!visitedPaths.add(canonicalPath)) {
                // Symlink loop / duplicate path detected - skip safely
                return;
            }
        } catch (IOException e) {
            // Cannot resolve canonical path - skip safely
            return;
        }

        if (file.isFile()) {
            String name = file.getName().toLowerCase();
            if (name.endsWith(".java") || name.endsWith(".py") || name.endsWith(".js") ||
                name.endsWith(".ts") || name.endsWith(".c") || name.endsWith(".cpp") || name.endsWith(".h")) {
                accumulator.add(file);
            }
        } else if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    collectSourceFiles(child, accumulator, visitedPaths, depth + 1);
                }
            }
        }
    }
}
