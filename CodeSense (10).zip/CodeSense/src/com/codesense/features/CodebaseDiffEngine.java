package com.codesense.features;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.analyzer.WorkspaceScanner;

import java.io.File;
import java.util.*;

/**
 * Codebase Version Diffing Engine.
 * Compares two workspace folders (e.g. V1 vs V2 or Master vs Branch)
 * and calculates method-level complexity deltas.
 */
public class CodebaseDiffEngine {

    public static class MethodDiff {
        private final String routineKey;
        private final MethodMetrics baseMetrics;
        private final MethodMetrics targetMetrics;
        private final double scoreDelta;
        private final int ccDelta;
        private final double miDelta;
        private final String status; // "ADDED", "REMOVED", "MODIFIED", "UNCHANGED"

        public MethodDiff(String routineKey, MethodMetrics baseMetrics, MethodMetrics targetMetrics, String status) {
            this.routineKey = routineKey;
            this.baseMetrics = baseMetrics;
            this.targetMetrics = targetMetrics;
            this.status = status;

            if (baseMetrics != null && targetMetrics != null) {
                this.scoreDelta = Math.round((targetMetrics.getComplexityScore() - baseMetrics.getComplexityScore()) * 100.0) / 100.0;
                this.ccDelta = targetMetrics.getCyclomaticComplexity() - baseMetrics.getCyclomaticComplexity();
                this.miDelta = Math.round((targetMetrics.getMaintainabilityIndex() - baseMetrics.getMaintainabilityIndex()) * 10.0) / 10.0;
            } else if (targetMetrics != null) {
                this.scoreDelta = targetMetrics.getComplexityScore();
                this.ccDelta = targetMetrics.getCyclomaticComplexity();
                this.miDelta = targetMetrics.getMaintainabilityIndex();
            } else if (baseMetrics != null) {
                this.scoreDelta = -baseMetrics.getComplexityScore();
                this.ccDelta = -baseMetrics.getCyclomaticComplexity();
                this.miDelta = -baseMetrics.getMaintainabilityIndex();
            } else {
                this.scoreDelta = 0;
                this.ccDelta = 0;
                this.miDelta = 0;
            }
        }

        public String getRoutineKey() { return routineKey; }
        public MethodMetrics getBaseMetrics() { return baseMetrics; }
        public MethodMetrics getTargetMetrics() { return targetMetrics; }
        public double getScoreDelta() { return scoreDelta; }
        public int getCcDelta() { return ccDelta; }
        public double getMiDelta() { return miDelta; }
        public String getStatus() { return status; }
    }

    public static class DiffResult {
        private final List<MethodDiff> diffList;
        private final int addedCount;
        private final int removedCount;
        private final int modifiedCount;
        private final double netAvgScoreDelta;

        public DiffResult(List<MethodDiff> diffList, int addedCount, int removedCount, int modifiedCount, double netAvgScoreDelta) {
            this.diffList = diffList;
            this.addedCount = addedCount;
            this.removedCount = removedCount;
            this.modifiedCount = modifiedCount;
            this.netAvgScoreDelta = netAvgScoreDelta;
        }

        public List<MethodDiff> getDiffList() { return diffList; }
        public int getAddedCount() { return addedCount; }
        public int getRemovedCount() { return removedCount; }
        public int getModifiedCount() { return modifiedCount; }
        public double getNetAvgScoreDelta() { return netAvgScoreDelta; }
    }

    public static DiffResult compareWorkspaces(File basePath, File targetPath) {
        WorkspaceScanner.ScanResult baseScan = WorkspaceScanner.scanWorkspace(basePath);
        WorkspaceScanner.ScanResult targetScan = WorkspaceScanner.scanWorkspace(targetPath);

        Map<String, MethodMetrics> baseMap = new HashMap<>();
        for (MethodMetrics m : baseScan.getAllMethods()) {
            baseMap.put(m.getClassName() + "." + m.getMethodName(), m);
        }

        Map<String, MethodMetrics> targetMap = new HashMap<>();
        for (MethodMetrics m : targetScan.getAllMethods()) {
            targetMap.put(m.getClassName() + "." + m.getMethodName(), m);
        }

        Set<String> allKeys = new HashSet<>();
        allKeys.addAll(baseMap.keySet());
        allKeys.addAll(targetMap.keySet());

        List<MethodDiff> diffs = new ArrayList<>();
        int added = 0, removed = 0, modified = 0;
        double totalDelta = 0;

        for (String key : allKeys) {
            MethodMetrics b = baseMap.get(key);
            MethodMetrics t = targetMap.get(key);

            if (b == null && t != null) {
                diffs.add(new MethodDiff(key, null, t, "ADDED"));
                added++;
            } else if (b != null && t == null) {
                diffs.add(new MethodDiff(key, b, null, "REMOVED"));
                removed++;
            } else if (b != null && t != null) {
                double delta = t.getComplexityScore() - b.getComplexityScore();
                if (Math.abs(delta) > 0.05) {
                    diffs.add(new MethodDiff(key, b, t, "MODIFIED"));
                    modified++;
                    totalDelta += delta;
                } else {
                    diffs.add(new MethodDiff(key, b, t, "UNCHANGED"));
                }
            }
        }

        double netAvgDelta = modified > 0 ? (totalDelta / modified) : 0.0;
        netAvgDelta = Math.round(netAvgDelta * 100.0) / 100.0;

        return new DiffResult(diffs, added, removed, modified, netAvgDelta);
    }
}
