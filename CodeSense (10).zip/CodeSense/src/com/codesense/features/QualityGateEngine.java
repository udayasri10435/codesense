package com.codesense.features;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.analyzer.WorkspaceScanner;

import java.util.ArrayList;
import java.util.List;

/**
 * CI/CD Quality Gate Threshold Rule Engine.
 * Evaluates codebase compliance against engineering quality thresholds.
 */
public class QualityGateEngine {

    public static class QualityGateConfig {
        public int maxAllowedCc = 15;
        public int maxAllowedCriticalAlerts = 0;
        public double minAllowedMaintainabilityIndex = 50.0;
        public double maxAllowedAvgScore = 20.0;
    }

    public static class QualityGateResult {
        private final boolean passed;
        private final List<String> violations;
        private final double complianceScore;

        public QualityGateResult(boolean passed, List<String> violations, double complianceScore) {
            this.passed = passed;
            this.violations = violations;
            this.complianceScore = complianceScore;
        }

        public boolean isPassed() { return passed; }
        public List<String> getViolations() { return violations; }
        public double getComplianceScore() { return complianceScore; }
    }

    public static QualityGateResult evaluateQualityGate(WorkspaceScanner.ScanResult scan, QualityGateConfig config, List<AlertManager.RefactorAlert> alerts) {
        List<String> violations = new ArrayList<>();
        if (scan == null) {
            violations.add("No scan data available.");
            return new QualityGateResult(false, violations, 0.0);
        }

        int criticalCount = 0;
        for (AlertManager.RefactorAlert a : alerts) {
            if (a.getSeverity() == MethodMetrics.RiskLevel.CRITICAL) criticalCount++;
        }

        if (criticalCount > config.maxAllowedCriticalAlerts) {
            violations.add(String.format("Critical Alerts Limit Breached: %d critical routines found (Max Allowed: %d)", criticalCount, config.maxAllowedCriticalAlerts));
        }

        List<MethodMetrics> methods = scan.getAllMethods();
        double sumScore = 0;
        for (MethodMetrics m : methods) {
            sumScore += m.getComplexityScore();
            if (m.getCyclomaticComplexity() > config.maxAllowedCc) {
                violations.add(String.format("Routine %s.%s() breaches Max Cyclomatic Complexity (%d > %d)", m.getClassName(), m.getMethodName(), m.getCyclomaticComplexity(), config.maxAllowedCc));
            }
            if (m.getMaintainabilityIndex() < config.minAllowedMaintainabilityIndex) {
                violations.add(String.format("Routine %s.%s() breaches Min Maintainability Index (%.1f < %.1f)", m.getClassName(), m.getMethodName(), m.getMaintainabilityIndex(), config.minAllowedMaintainabilityIndex));
            }
        }

        double avgScore = methods.size() > 0 ? (sumScore / methods.size()) : 0;
        if (avgScore > config.maxAllowedAvgScore) {
            violations.add(String.format("Average Complexity Score Breached: %.2f > %.2f", avgScore, config.maxAllowedAvgScore));
        }

        boolean passed = violations.isEmpty();
        double compliance = Math.max(0.0, 100.0 - (violations.size() * 20.0));
        return new QualityGateResult(passed, violations, Math.round(compliance * 10.0) / 10.0);
    }
}
