package com.codesense.features;

import com.codesense.analyzer.MethodMetrics;

import java.util.List;

/**
 * Technical Debt & Refactoring Effort Estimator.
 * Computes person-hours required to remediate complex routines and estimated financial debt index.
 */
public class TechnicalDebtEstimator {

    public static class TechnicalDebtSummary {
        private final double totalPersonHours;
        private final double estimatedCostDollars;
        private final int quickWinRoutinesCount;
        private final int highPriorityRoutinesCount;

        public TechnicalDebtSummary(double totalPersonHours, double estimatedCostDollars, int quickWinRoutinesCount, int highPriorityRoutinesCount) {
            this.totalPersonHours = totalPersonHours;
            this.estimatedCostDollars = estimatedCostDollars;
            this.quickWinRoutinesCount = quickWinRoutinesCount;
            this.highPriorityRoutinesCount = highPriorityRoutinesCount;
        }

        public double getTotalPersonHours() { return totalPersonHours; }
        public double getEstimatedCostDollars() { return estimatedCostDollars; }
        public int getQuickWinRoutinesCount() { return quickWinRoutinesCount; }
        public int getHighPriorityRoutinesCount() { return highPriorityRoutinesCount; }
    }

    public static TechnicalDebtSummary calculateTechnicalDebt(List<MethodMetrics> methods) {
        if (methods == null || methods.isEmpty()) {
            return new TechnicalDebtSummary(0, 0, 0, 0);
        }

        double totalHours = 0;
        int quickWins = 0;
        int highPriority = 0;

        for (MethodMetrics m : methods) {
            double score = m.getComplexityScore();
            if (score > 10.0) {
                double hours = (score - 8.0) * 0.45;
                totalHours += hours;

                if (score >= 25.0 || m.getCyclomaticComplexity() > 12) {
                    highPriority++;
                } else if (score >= 10.0 && score < 20.0) {
                    quickWins++;
                }
            }
        }

        totalHours = Math.round(totalHours * 10.0) / 10.0;
        double cost = Math.round(totalHours * 75.0); // Assuming $75/hr engineering cost baseline

        return new TechnicalDebtSummary(totalHours, cost, quickWins, highPriority);
    }
}
