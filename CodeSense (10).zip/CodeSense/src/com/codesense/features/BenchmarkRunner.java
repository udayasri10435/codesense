package com.codesense.features;

import com.codesense.ds.AVLTree;
import com.codesense.ds.BSTTree;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Empirical Benchmark Suite comparing Custom AVL Trees against Unbalanced Binary Search Trees (BST).
 * Evaluates tree height degeneration and search lookup latency under Random, Ascending (Sorted),
 * and Descending insertion sequences.
 */
public class BenchmarkRunner {

    public static class MetricResult {
        public final int n;
        public final String ordering;
        public final int avlHeight;
        public final int bstHeight;
        public final double avlSearchTimeNs;
        public final double bstSearchTimeNs;

        public MetricResult(int n, String ordering, int avlHeight, int bstHeight, double avlSearchTimeNs, double bstSearchTimeNs) {
            this.n = n;
            this.ordering = ordering;
            this.avlHeight = avlHeight;
            this.bstHeight = bstHeight;
            this.avlSearchTimeNs = avlSearchTimeNs;
            this.bstSearchTimeNs = bstSearchTimeNs;
        }
    }

    public static List<MetricResult> runFullBenchmarkSuite() {
        List<MetricResult> results = new ArrayList<>();
        int[] sizes = {100, 1000, 5000, 10000};
        String[] orderings = {"Random", "Ascending", "Descending"};

        for (int n : sizes) {
            for (String order : orderings) {
                double[] keys = generateKeys(n, order);

                // 1. Benchmark AVL Tree
                AVLTree<String> avl = new AVLTree<>();
                for (double k : keys) {
                    avl.insert(k, "Data_" + k);
                }
                int avlHeight = avl.getHeight();
                double avlSearchNs = measureAvgSearchTimeAVL(avl, keys);

                // 2. Benchmark Unbalanced BST
                BSTTree<String> bst = new BSTTree<>();
                int bstHeight = 0;
                double bstSearchNs = 0.0;

                try {
                    for (double k : keys) {
                        bst.insert(k, "Data_" + k);
                    }
                    bstHeight = bst.getHeight();
                    bstSearchNs = measureAvgSearchTimeBST(bst, keys);
                } catch (StackOverflowError e) {
                    // For massive pre-sorted inputs, unbalanced BST recursion depth exceeds stack limit
                    bstHeight = n; // Degenerates to linear chain height N
                    bstSearchNs = -1.0; // Stack limit exceeded
                }

                results.add(new MetricResult(n, order, avlHeight, bstHeight, avlSearchNs, bstSearchNs));
            }
        }

        exportResultsToCSV(results);
        return results;
    }

    private static double[] generateKeys(int n, String order) {
        double[] keys = new double[n];
        for (int i = 0; i < n; i++) {
            keys[i] = (i + 1) * 1.5;
        }

        if (order.equalsIgnoreCase("Random")) {
            List<Double> list = new ArrayList<>();
            for (double k : keys) list.add(k);
            Collections.shuffle(list, new Random(42));
            for (int i = 0; i < n; i++) keys[i] = list.get(i);
        } else if (order.equalsIgnoreCase("Descending")) {
            for (int i = 0; i < n / 2; i++) {
                double temp = keys[i];
                keys[i] = keys[n - 1 - i];
                keys[n - 1 - i] = temp;
            }
        }
        return keys;
    }

    private static double measureAvgSearchTimeAVL(AVLTree<String> avl, double[] keys) {
        int lookups = Math.min(1000, keys.length);
        long start = System.nanoTime();
        for (int i = 0; i < lookups; i++) {
            avl.searchNode(keys[i % keys.length]);
        }
        long duration = System.nanoTime() - start;
        return (double) duration / lookups;
    }

    private static double measureAvgSearchTimeBST(BSTTree<String> bst, double[] keys) {
        int lookups = Math.min(1000, keys.length);
        long start = System.nanoTime();
        for (int i = 0; i < lookups; i++) {
            bst.searchNode(keys[i % keys.length]);
        }
        long duration = System.nanoTime() - start;
        return (double) duration / lookups;
    }

    private static void exportResultsToCSV(List<MetricResult> results) {
        File reportsDir = new File("reports");
        if (!reportsDir.exists()) reportsDir.mkdirs();

        File csvFile = new File(reportsDir, "avl-vs-bst-benchmark.csv");
        try (PrintWriter writer = new PrintWriter(new FileWriter(csvFile))) {
            writer.println("N,Ordering,AVL_Height,BST_Height,AVL_Search_Time_ns,BST_Search_Time_ns");
            for (MetricResult r : results) {
                writer.printf("%d,%s,%d,%s,%.2f,%s\n",
                        r.n, r.ordering, r.avlHeight,
                        (r.bstSearchTimeNs < 0 ? "StackOverflow (" + r.n + ")" : String.valueOf(r.bstHeight)),
                        r.avlSearchTimeNs,
                        (r.bstSearchTimeNs < 0 ? "N/A" : String.format("%.2f", r.bstSearchTimeNs)));
            }
        } catch (IOException e) {
            System.err.println("Failed to write benchmark CSV: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        System.out.println("Running CodeSense AVL vs BST Benchmark Suite...");
        List<MetricResult> results = runFullBenchmarkSuite();
        System.out.println("\nEmpirical Benchmark Results:");
        System.out.printf("%-8s %-12s %-12s %-15s %-18s %-18s\n", "N", "Ordering", "AVL Height", "BST Height", "AVL Search (ns)", "BST Search (ns)");
        System.out.println("-----------------------------------------------------------------------------------------");
        for (MetricResult r : results) {
            System.out.printf("%-8d %-12s %-12d %-15s %-18.2f %-18s\n",
                    r.n, r.ordering, r.avlHeight,
                    (r.bstSearchTimeNs < 0 ? "StackOverflow" : String.valueOf(r.bstHeight)),
                    r.avlSearchTimeNs,
                    (r.bstSearchTimeNs < 0 ? "N/A" : String.format("%.2f", r.bstSearchTimeNs)));
        }
    }
}
