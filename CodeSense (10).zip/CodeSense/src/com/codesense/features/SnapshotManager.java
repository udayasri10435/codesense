package com.codesense.features;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.ds.AVLTree;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Novel Feature: Trend Snapshots
 * Tracks AVL Tree revisions over sequential commit cycles or scan runs,
 * giving engineering teams structural trajectory graphs regarding code quality shifts.
 */
public class SnapshotManager {

    public static class TreeSnapshot {
        private final String snapshotId;
        private final String label;
        private final LocalDateTime timestamp;
        private final int totalMethods;
        private final double avgComplexity;
        private final double maxComplexity;
        private final int treeHeight;
        private final int totalRotations;
        private final int criticalCount;
        private final int highCount;

        public TreeSnapshot(String snapshotId, String label, int totalMethods, double avgComplexity,
                            double maxComplexity, int treeHeight, int totalRotations,
                            int criticalCount, int highCount) {
            this.snapshotId = snapshotId;
            this.label = label;
            this.timestamp = LocalDateTime.now();
            this.totalMethods = totalMethods;
            this.avgComplexity = avgComplexity;
            this.maxComplexity = maxComplexity;
            this.treeHeight = treeHeight;
            this.totalRotations = totalRotations;
            this.criticalCount = criticalCount;
            this.highCount = highCount;
        }

        public String getSnapshotId() {
            return snapshotId;
        }

        public String getLabel() {
            return label;
        }

        public String getFormattedTimestamp() {
            return timestamp.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
        }

        public int getTotalMethods() {
            return totalMethods;
        }

        public double getAvgComplexity() {
            return avgComplexity;
        }

        public double getMaxComplexity() {
            return maxComplexity;
        }

        public int getTreeHeight() {
            return treeHeight;
        }

        public int getTotalRotations() {
            return totalRotations;
        }

        public int getCriticalCount() {
            return criticalCount;
        }

        public int getHighCount() {
            return highCount;
        }
    }

    private final List<TreeSnapshot> snapshotHistory;

    public SnapshotManager() {
        this.snapshotHistory = new ArrayList<>();
    }

    public TreeSnapshot captureSnapshot(String label, AVLTree<MethodMetrics> avlTree, List<MethodMetrics> allMethods) {
        int totalMethods = allMethods.size();
        double sum = 0;
        double maxComp = 0;
        int critical = 0;
        int high = 0;

        for (MethodMetrics m : allMethods) {
            sum += m.getComplexityScore();
            if (m.getComplexityScore() > maxComp) {
                maxComp = m.getComplexityScore();
            }
            if (m.getRiskLevel() == MethodMetrics.RiskLevel.CRITICAL) {
                critical++;
            } else if (m.getRiskLevel() == MethodMetrics.RiskLevel.HIGH) {
                high++;
            }
        }

        double avg = totalMethods > 0 ? (sum / totalMethods) : 0.0;
        avg = Math.round(avg * 100.0) / 100.0;

        String id = "REV-" + (snapshotHistory.size() + 1);
        TreeSnapshot snapshot = new TreeSnapshot(
                id, label, totalMethods, avg, maxComp,
                avlTree.getHeight(), avlTree.getTotalRotations(), critical, high
        );

        snapshotHistory.add(snapshot);
        return snapshot;
    }

    public List<TreeSnapshot> getHistory() {
        return new ArrayList<>(snapshotHistory);
    }

    public String generateTrajectorySummary() {
        if (snapshotHistory.size() < 2) {
            return "Insufficient revisions captured. Run additional codebase scans to plot trajectory.";
        }

        TreeSnapshot first = snapshotHistory.get(0);
        TreeSnapshot latest = snapshotHistory.get(snapshotHistory.size() - 1);

        double deltaAvg = latest.getAvgComplexity() - first.getAvgComplexity();
        int deltaCritical = latest.getCriticalCount() - first.getCriticalCount();

        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Trajectory across %d Revisions:\n", snapshotHistory.size()));
        sb.append(String.format(" - Initial Avg Complexity: %.2f | Current Avg Complexity: %.2f (Delta: %+.2f)\n",
                first.getAvgComplexity(), latest.getAvgComplexity(), deltaAvg));
        sb.append(String.format(" - Critical Refactor Targets: %d -> %d (%+d)\n",
                first.getCriticalCount(), latest.getCriticalCount(), deltaCritical));

        if (deltaAvg < 0) {
            sb.append(" Status: IMPROVING - Codebase refactoring efforts are reducing complexity!");
        } else if (deltaAvg > 0) {
            sb.append(" Status: DEGRADED - Structural complexity is increasing. Review live refactor alerts.");
        } else {
            sb.append(" Status: STABLE - Structural complexity remains balanced.");
        }

        return sb.toString();
    }
}
