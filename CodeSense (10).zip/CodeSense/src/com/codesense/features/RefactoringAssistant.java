package com.codesense.features;

import com.codesense.analyzer.MethodMetrics;

/**
 * Automated Refactoring Recipe & Code Transformation Generator.
 * Computes predicted metrics impact (CC reduction, MI gain) and generates refactoring code templates.
 */
public class RefactoringAssistant {

    public static class RefactoringRecipe {
        private final MethodMetrics originalMetrics;
        private final String recipeTitle;
        private final String primaryPattern;
        private final int predictedCc;
        private final int predictedCognitive;
        private final int predictedMaxNesting;
        private final double predictedMaintainabilityIndex;
        private final double predictedScore;
        private final String refactoredCodeTemplate;
        private final String stepByStepGuide;

        public RefactoringRecipe(MethodMetrics originalMetrics, String recipeTitle, String primaryPattern,
                                 int predictedCc, int predictedCognitive, int predictedMaxNesting,
                                 double predictedMaintainabilityIndex, double predictedScore,
                                 String refactoredCodeTemplate, String stepByStepGuide) {
            this.originalMetrics = originalMetrics;
            this.recipeTitle = recipeTitle;
            this.primaryPattern = primaryPattern;
            this.predictedCc = predictedCc;
            this.predictedCognitive = predictedCognitive;
            this.predictedMaxNesting = predictedMaxNesting;
            this.predictedMaintainabilityIndex = predictedMaintainabilityIndex;
            this.predictedScore = predictedScore;
            this.refactoredCodeTemplate = refactoredCodeTemplate;
            this.stepByStepGuide = stepByStepGuide;
        }

        public MethodMetrics getOriginalMetrics() {
            return originalMetrics;
        }

        public String getRecipeTitle() {
            return recipeTitle;
        }

        public String getPrimaryPattern() {
            return primaryPattern;
        }

        public int getPredictedCc() {
            return predictedCc;
        }

        public int getPredictedCognitive() {
            return predictedCognitive;
        }

        public int getPredictedMaxNesting() {
            return predictedMaxNesting;
        }

        public double getPredictedMaintainabilityIndex() {
            return predictedMaintainabilityIndex;
        }

        public double getPredictedScore() {
            return predictedScore;
        }

        public String getRefactoredCodeTemplate() {
            return refactoredCodeTemplate;
        }

        public String getStepByStepGuide() {
            return stepByStepGuide;
        }
    }

    public static RefactoringRecipe generateRecipe(MethodMetrics m) {
        if (m == null) return null;

        int origCc = m.getCyclomaticComplexity();
        int origCog = m.getCognitiveComplexity();
        int origMnd = m.getMaxNestingDepth();
        double origScore = m.getComplexityScore();
        double origMi = m.getMaintainabilityIndex();

        // Calculate predicted improved metrics after refactoring
        int predCc = Math.max(2, (int) Math.ceil(origCc * 0.35));
        int predCog = Math.max(1, (int) Math.ceil(origCog * 0.25));
        int predMnd = Math.min(2, Math.max(1, origMnd - 2));
        double predMi = Math.min(95.0, origMi + 32.5);
        double predScore = Math.round(((predCc * 1.1) + (predCog * 1.3) + (predMnd * 1.6) + 2.0) * 100.0) / 100.0;

        String patternName;
        StringBuilder guide = new StringBuilder();
        StringBuilder codeTemplate = new StringBuilder();

        if (origCc > 15 || origCog > 20) {
            patternName = "Strategy Pattern + Extract Method Decomposition";
            guide.append("1. Replace monolithic conditional branches with Strategy interface handlers.\n");
            guide.append("2. Extract sub-calculations into cohesive private helper methods.\n");
            guide.append("3. Apply Early Guard Clauses to fail fast on invalid arguments.\n");

            codeTemplate.append("// BEFORE: Monolithic routine with high complexity (Score = ").append(origScore).append(")\n");
            codeTemplate.append("// ").append(m.getClassName()).append(".").append(m.getMethodName()).append("()\n\n");
            codeTemplate.append("// AFTER REFACTORED PATTERN (Predicted Score = ").append(predScore).append("):\n");
            codeTemplate.append("public class ").append(m.getClassName()).append("Refactored {\n");
            codeTemplate.append("    private final Map<String, ExecutionStrategy> strategyRegistry = new HashMap<>();\n\n");
            codeTemplate.append("    public double ").append(m.getMethodName()).append("(OrderRequest request) {\n");
            codeTemplate.append("        // 1. Guard Clause - Fail Fast\n");
            codeTemplate.append("        if (request == null || !request.isValid()) return 0.0;\n\n");
            codeTemplate.append("        // 2. Delegate to Strategy Handler\n");
            codeTemplate.append("        ExecutionStrategy strategy = strategyRegistry.getOrDefault(request.getType(), defaultStrategy);\n");
            codeTemplate.append("        return strategy.execute(request);\n");
            codeTemplate.append("    }\n");
            codeTemplate.append("}\n");
        } else if (origMnd > 3) {
            patternName = "Guard Clauses (Early Exit / Flatten Nesting)";
            guide.append("1. Invert nested if-statements into top-level guard clauses.\n");
            guide.append("2. Remove nested else blocks to reduce brace nesting depth to <= 2.\n");

            codeTemplate.append("// AFTER REFACTORED PATTERN (Predicted Score = ").append(predScore).append("):\n");
            codeTemplate.append("public double ").append(m.getMethodName()).append("(double amount, int tier) {\n");
            codeTemplate.append("    if (amount <= 0) throw new IllegalArgumentException();\n");
            codeTemplate.append("    if (tier == 0) return amount;\n\n");
            codeTemplate.append("    // Flattened main execution logic\n");
            codeTemplate.append("    return calculateTierDiscount(amount, tier);\n");
            codeTemplate.append("}\n");
        } else {
            patternName = "Extract Helper Method";
            guide.append("1. Extract secondary logic block into a dedicated helper routine.\n");
            guide.append("2. Maintain single responsibility per method.\n");

            codeTemplate.append("// AFTER REFACTORED PATTERN (Predicted Score = ").append(predScore).append("):\n");
            codeTemplate.append("public void ").append(m.getMethodName()).append("() {\n");
            codeTemplate.append("    validateState();\n");
            codeTemplate.append("    executeCoreRoutine();\n");
            codeTemplate.append("}\n");
        }

        return new RefactoringRecipe(m, "Refactoring Recipe for " + m.getMethodName() + "()",
                patternName, predCc, predCog, predMnd, predMi, predScore, codeTemplate.toString(), guide.toString());
    }
}
