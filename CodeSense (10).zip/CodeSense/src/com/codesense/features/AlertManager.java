package com.codesense.features;

import com.codesense.analyzer.MethodMetrics;

import java.util.ArrayList;
import java.util.List;

/**
 * Enhanced Live Refactor Alerts Engine.
 * Isolates high-weight routines breaching design baselines with precise architectural recommendations.
 */
public class AlertManager {

    /**
     * Immutable alert object representing a routine that has breached complexity baseline thresholds.
     * Contains method metrics payload, issue description, refactoring advice, and severity level.
     */
    public static class RefactorAlert {
        private final MethodMetrics metrics;
        private final String issueSummary;
        private final String refactoringRecommendation;
        private final MethodMetrics.RiskLevel severity;

        /**
         * Constructs a new RefactorAlert instance.
         *
         * @param metrics                   method metrics payload triggering the alert
         * @param issueSummary              summary string of breached baseline conditions
         * @param refactoringRecommendation actionable architectural advice string
         * @param severity                  calculated risk level severity
         */
        public RefactorAlert(MethodMetrics metrics, String issueSummary, String refactoringRecommendation, MethodMetrics.RiskLevel severity) {
            this.metrics = metrics;
            this.issueSummary = issueSummary;
            this.refactoringRecommendation = refactoringRecommendation;
            this.severity = severity;
        }

        /**
         * @return method metrics payload associated with this alert
         */
        public MethodMetrics getMetrics() {
            return metrics;
        }

        /**
         * @return non-empty summary description of breached metrics
         */
        public String getIssueSummary() {
            return issueSummary;
        }

        /**
         * @return non-empty architectural refactoring recommendation
         */
        public String getRefactoringRecommendation() {
            return refactoringRecommendation;
        }

        /**
         * @return risk severity level (LOW, MEDIUM, HIGH, CRITICAL)
         */
        public MethodMetrics.RiskLevel getSeverity() {
            return severity;
        }

        @Override
        public String toString() {
            return String.format("[%s] %s.%s() -> %s | Recommendation: %s",
                    severity.name(), metrics.getClassName(), metrics.getMethodName(), issueSummary, refactoringRecommendation);
        }
    }

    private double maxScoreThreshold = 15.0;
    private int maxCcThreshold = 9;
    private int maxMndThreshold = 3;

    /**
     * Evaluates a list of method metrics against complexity baseline thresholds.
     * Generates a RefactorAlert for each routine that breaches overall complexity score,
     * CC, MND, or Maintainability Index baselines.
     *
     * @param methods list of MethodMetrics to evaluate
     * @return list of generated RefactorAlert instances
     */
    public List<RefactorAlert> evaluateMetrics(List<MethodMetrics> methods) {
        List<RefactorAlert> alerts = new ArrayList<>();
        if (methods == null) return alerts;

        for (MethodMetrics m : methods) {
            boolean scoreBreach = m.getComplexityScore() >= maxScoreThreshold;
            boolean ccBreach = m.getCyclomaticComplexity() >= maxCcThreshold;
            boolean mndBreach = m.getMaxNestingDepth() >= maxMndThreshold;
            boolean miBreach = m.getMaintainabilityIndex() < 55.0;

            if (scoreBreach || ccBreach || mndBreach || miBreach) {
                StringBuilder issues = new StringBuilder();
                StringBuilder recs = new StringBuilder();

                if (ccBreach) {
                    issues.append(String.format("Cyclomatic Complexity (%d >= %d) ", m.getCyclomaticComplexity(), maxCcThreshold));
                    recs.append("Replace Conditional Logic with Polymorphism or Command Pattern. ");
                }
                if (mndBreach) {
                    issues.append(String.format("Max Nesting Depth (%d >= %d) ", m.getMaxNestingDepth(), maxMndThreshold));
                    recs.append("Flatten nested branches using Early Return Guard Clauses. ");
                }
                if (m.getCognitiveComplexity() > 10) {
                    issues.append(String.format("Cognitive Overload (%d) ", m.getCognitiveComplexity()));
                    recs.append("Extract helper routines to lower mental trace load. ");
                }
                if (miBreach) {
                    issues.append(String.format("Low Maintainability Index (%.1f/100) ", m.getMaintainabilityIndex()));
                    recs.append("Decompose monolithic routine into cohesive domain services. ");
                }

                if (issues.length() == 0) {
                    issues.append(String.format("Composite Complexity Score (%.1f >= %.1f) ", m.getComplexityScore(), maxScoreThreshold));
                    recs.append("Refactor routine into smaller sub-methods to reduce combined complexity score. ");
                }

                alerts.add(new RefactorAlert(m, issues.toString().trim(), recs.toString().trim(), m.getRiskLevel()));
            }
        }

        return alerts;
    }
}
