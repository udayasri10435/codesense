package com.codesense.exporter;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.analyzer.WorkspaceScanner;
import com.codesense.features.AlertManager;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Report Exporter for CodeSense.
 * Generates standalone interactive HTML reports, Markdown documentation, PR templates, SARIF static analysis reports, JSON data dumps, and CSV exports.
 */
public class ReportExporter {

    public static File exportHtmlReport(WorkspaceScanner.ScanResult scanResult, List<AlertManager.RefactorAlert> alerts, File outputDir) throws IOException {
        if (!outputDir.exists()) outputDir.mkdirs();
        File reportFile = new File(outputDir, "codesense-report.html");
        List<MethodMetrics> sortedMethods = scanResult.getAvlTree().inOrderTraversal();

        StringBuilder html = new StringBuilder();
        html.append("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n");
        html.append("<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n");
        html.append("<title>CodeSense Architectural Complexity Report</title>\n");
        html.append("<style>\n");
        html.append("  body { font-family: 'Segoe UI', Tahoma, sans-serif; background-color: #0a0e17; color: #f8fafc; margin: 0; padding: 24px; }\n");
        html.append("  .header { background: #0f172a; border-bottom: 2px solid #2563eb; padding: 20px; border-radius: 10px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; }\n");
        html.append("  h1 { margin: 0; color: #38bdf8; font-size: 24px; }\n");
        html.append("  .subtitle { color: #94a3b8; font-size: 13px; margin-top: 4px; }\n");
        html.append("  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; margin-bottom: 24px; }\n");
        html.append("  .card { background: #0f172a; border: 1px solid #374151; padding: 16px; border-radius: 8px; border-top: 4px solid #2563eb; }\n");
        html.append("  .card-title { font-size: 12px; color: #94a3b8; font-weight: bold; text-transform: uppercase; }\n");
        html.append("  .card-value { font-size: 22px; font-weight: bold; color: #38bdf8; margin-top: 6px; }\n");
        html.append("  .section { background: #0f172a; border: 1px solid #374151; border-radius: 10px; padding: 20px; margin-bottom: 24px; }\n");
        html.append("  h2 { color: #34d399; font-size: 18px; margin-top: 0; border-bottom: 1px solid #374151; padding-bottom: 10px; }\n");
        html.append("  table { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 13px; }\n");
        html.append("  th, td { padding: 12px 14px; text-align: center; border-bottom: 1px solid #1e293b; }\n");
        html.append("  th { background-color: #1e293b; color: #38bdf8; font-weight: bold; }\n");
        html.append("  tr:nth-child(even) { background-color: #111827; }\n");
        html.append("  .badge { padding: 4px 10px; border-radius: 12px; font-weight: bold; font-size: 11px; display: inline-block; }\n");
        html.append("  .badge-low { background: #064e3b; color: #34d399; }\n");
        html.append("  .badge-medium { background: #78350f; color: #f59e0b; }\n");
        html.append("  .badge-high { background: #7f1d1d; color: #ef4444; }\n");
        html.append("  .badge-critical { background: #581c87; color: #a855f7; }\n");
        html.append("  .alert-box { background: #1e1b4b; border-left: 4px solid #a855f7; padding: 14px; margin-bottom: 12px; border-radius: 6px; }\n");
        html.append("  .alert-title { font-weight: bold; color: #a855f7; margin-bottom: 4px; }\n");
        html.append("</style>\n</head>\n<body>\n");

        html.append("<div class=\"header\">\n<div>\n");
        html.append("  <h1>⚡ CodeSense Complexity Architecture Report</h1>\n");
        html.append("  <div class=\"subtitle\">Generated on ").append(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))).append("</div>\n");
        html.append("</div>\n<div style=\"text-align:right; font-size:12px; color:#94a3b8;\">\n");
        html.append("  <b>PDSA Assignment Project</b><br>Custom Self-Balancing AVL Tree Engine\n");
        html.append("</div>\n</div>\n");

        html.append("<div class=\"grid\">\n");
        html.append("  <div class=\"card\" style=\"border-top-color:#2563eb;\"><div class=\"card-title\">Total Methods</div><div class=\"card-value\">").append(scanResult.getTotalMethodsCount()).append("</div></div>\n");
        html.append("  <div class=\"card\" style=\"border-top-color:#38bdf8;\"><div class=\"card-title\">Scanned Files</div><div class=\"card-value\">").append(scanResult.getScannedFilesCount()).append("</div></div>\n");
        html.append("  <div class=\"card\" style=\"border-top-color:#34d399;\"><div class=\"card-title\">AVL Tree Height</div><div class=\"card-value\">").append(scanResult.getAvlTree().getHeight()).append("</div></div>\n");
        html.append("  <div class=\"card\" style=\"border-top-color:#a855f7;\"><div class=\"card-title\">AVL Rotations</div><div class=\"card-value\">").append(scanResult.getAvlTree().getTotalRotations()).append("</div></div>\n");
        html.append("  <div class=\"card\" style=\"border-top-color:#ef4444;\"><div class=\"card-title\">Critical Alerts</div><div class=\"card-value\">").append(alerts.size()).append("</div></div>\n");
        html.append("</div>\n");

        html.append("<div class=\"section\">\n<h2>🚨 Live Refactor Alerts</h2>\n");
        if (alerts.isEmpty()) {
            html.append("<p style=\"color:#34d399;\">All methods operate within design thresholds! No critical alerts.</p>\n");
        } else {
            for (AlertManager.RefactorAlert a : alerts) {
                html.append("<div class=\"alert-box\">\n");
                html.append("<div class=\"alert-title\">[").append(a.getSeverity().name()).append("] ").append(a.getMetrics().getClassName()).append(".").append(a.getMetrics().getMethodName()).append("()</div>\n");
                html.append("<div><b>Issues:</b> ").append(a.getIssueSummary()).append("</div>\n");
                html.append("<div style=\"color:#38bdf8; margin-top:4px;\"><b>Refactoring Recipe:</b> ").append(a.getRefactoringRecommendation()).append("</div>\n");
                html.append("</div>\n");
            }
        }
        html.append("</div>\n");

        html.append("<div class=\"section\">\n<h2>📋 Routine Complexity Roadmap (AVL In-Order Sweeps)</h2>\n");
        html.append("<table>\n<thead><tr>\n");
        html.append("  <th>Method Name</th><th>Class</th><th>LOC</th><th>CC</th><th>Cognitive</th><th>Nesting</th><th>MI (100)</th><th>Score</th><th>Risk Level</th><th>Code Smells</th>\n");
        html.append("</tr></thead>\n<tbody>\n");

        for (MethodMetrics m : sortedMethods) {
            String badgeClass = "badge-low";
            if (m.getRiskLevel() == MethodMetrics.RiskLevel.CRITICAL) badgeClass = "badge-critical";
            else if (m.getRiskLevel() == MethodMetrics.RiskLevel.HIGH) badgeClass = "badge-high";
            else if (m.getRiskLevel() == MethodMetrics.RiskLevel.MEDIUM) badgeClass = "badge-medium";

            html.append("<tr>\n");
            html.append("  <td style=\"font-weight:bold; text-align:left;\">").append(m.getMethodName()).append("()</td>\n");
            html.append("  <td>").append(m.getClassName()).append("</td>\n");
            html.append("  <td>").append(m.getLinesOfCode()).append("</td>\n");
            html.append("  <td>").append(m.getCyclomaticComplexity()).append("</td>\n");
            html.append("  <td>").append(m.getCognitiveComplexity()).append("</td>\n");
            html.append("  <td>").append(m.getMaxNestingDepth()).append("</td>\n");
            html.append("  <td>").append(m.getMaintainabilityIndex()).append("</td>\n");
            html.append("  <td style=\"font-weight:bold; color:#38bdf8;\">").append(String.format("%.2f", m.getComplexityScore())).append("</td>\n");
            html.append("  <td><span class=\"badge ").append(badgeClass).append("\">").append(m.getRiskLevel().getLabel()).append("</span></td>\n");
            html.append("  <td style=\"font-size:11px; text-align:left;\">").append(m.getCodeSmellsFormatted()).append("</td>\n");
            html.append("</tr>\n");
        }

        html.append("</tbody>\n</table>\n</div>\n");
        html.append("</body>\n</html>");

        try (FileWriter writer = new FileWriter(reportFile)) {
            writer.write(html.toString());
        }

        return reportFile;
    }

    public static File exportMarkdownReport(WorkspaceScanner.ScanResult scanResult, List<AlertManager.RefactorAlert> alerts, File outputDir) throws IOException {
        if (!outputDir.exists()) outputDir.mkdirs();
        File mdFile = new File(outputDir, "codesense-report.md");
        List<MethodMetrics> sorted = scanResult.getAvlTree().inOrderTraversal();

        StringBuilder md = new StringBuilder();
        md.append("# ⚡ CodeSense Architectural Complexity Report\n\n");
        md.append("**Generated:** ").append(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))).append("\n\n");
        md.append("## Executive Metrics Summary\n");
        md.append("- **Total Methods Indexed:** ").append(scanResult.getTotalMethodsCount()).append("\n");
        md.append("- **Scanned Source Files:** ").append(scanResult.getScannedFilesCount()).append("\n");
        md.append("- **AVL Tree Height:** ").append(scanResult.getAvlTree().getHeight()).append("\n");
        md.append("- **AVL Rotations Triggered:** ").append(scanResult.getAvlTree().getTotalRotations()).append("\n");
        md.append("- **Refactor Alerts:** ").append(alerts.size()).append("\n\n");

        md.append("## 🚨 Refactor Alerts\n\n");
        for (AlertManager.RefactorAlert a : alerts) {
            md.append("### [").append(a.getSeverity().name()).append("] `").append(a.getMetrics().getClassName()).append(".").append(a.getMetrics().getMethodName()).append("()`\n");
            md.append("- **Issue:** ").append(a.getIssueSummary()).append("\n");
            md.append("- **Recommendation:** ").append(a.getRefactoringRecommendation()).append("\n\n");
        }

        md.append("## 📋 Method Complexity Roadmap (AVL In-Order Sweep)\n\n");
        md.append("| Method Name | Class | LOC | CC | Cog | Nesting | MI | Score | Risk Level |\n");
        md.append("|---|---|---|---|---|---|---|---|---|\n");
        for (MethodMetrics m : sorted) {
            md.append("| `").append(m.getMethodName()).append("()` | ").append(m.getClassName())
              .append(" | ").append(m.getLinesOfCode()).append(" | ").append(m.getCyclomaticComplexity())
              .append(" | ").append(m.getCognitiveComplexity()).append(" | ").append(m.getMaxNestingDepth())
              .append(" | ").append(m.getMaintainabilityIndex()).append(" | **").append(String.format("%.2f", m.getComplexityScore()))
              .append("** | ").append(m.getRiskLevel().getLabel()).append(" |\n");
        }

        try (FileWriter writer = new FileWriter(mdFile)) {
            writer.write(md.toString());
        }
        return mdFile;
    }

    public static File exportPullRequestTemplate(WorkspaceScanner.ScanResult scanResult, List<AlertManager.RefactorAlert> alerts, File outputDir) throws IOException {
        if (!outputDir.exists()) outputDir.mkdirs();
        File prFile = new File(outputDir, "PULL_REQUEST.md");

        StringBuilder sb = new StringBuilder();
        sb.append("## 🛠️ CodeSense Automated Architectural Refactoring Pull Request\n\n");
        sb.append("### 📝 Description\n");
        sb.append("This PR performs architectural code refactoring to remediate high-complexity routines identified by **CodeSense**.\n\n");
        sb.append("### 📊 Metrics Impact Summary\n");
        sb.append("- **Total Routines Analyzed:** ").append(scanResult.getTotalMethodsCount()).append("\n");
        sb.append("- **Refactor Targets Addressed:** ").append(alerts.size()).append("\n");
        sb.append("- **Quality Gate Compliance:** PASS ✅\n\n");
        sb.append("### 🧪 Refactored Routines\n");
        for (AlertManager.RefactorAlert a : alerts) {
            sb.append("- [x] `").append(a.getMetrics().getClassName()).append(".").append(a.getMetrics().getMethodName()).append("()`: Injected Guard Clauses & flattened nested loops.\n");
        }
        sb.append("\n### 🔍 Verification\n");
        sb.append("- [x] Automated JUnit 5 Test Harnesses verified zero regressions.\n");
        sb.append("- [x] CodeSense Quality Gate CI/CD checks passed.\n");

        try (FileWriter writer = new FileWriter(prFile)) {
            writer.write(sb.toString());
        }
        return prFile;
    }

    public static File exportSarifReport(WorkspaceScanner.ScanResult scanResult, List<AlertManager.RefactorAlert> alerts, File outputDir) throws IOException {
        if (!outputDir.exists()) outputDir.mkdirs();
        File sarifFile = new File(outputDir, "codesense-report.sarif");

        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"$schema\": \"https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json\",\n");
        sb.append("  \"version\": \"2.1.0\",\n");
        sb.append("  \"runs\": [\n");
        sb.append("    {\n");
        sb.append("      \"tool\": {\n");
        sb.append("        \"driver\": {\n");
        sb.append("          \"name\": \"CodeSense\",\n");
        sb.append("          \"informationUri\": \"https://github.com/codesense\",\n");
        sb.append("          \"rules\": [\n");
        sb.append("            {\n");
        sb.append("              \"id\": \"CS001\",\n");
        sb.append("              \"name\": \"HighComplexityRoutine\",\n");
        sb.append("              \"shortDescription\": { \"text\": \"Routine exceeds Cyclomatic and Cognitive Complexity thresholds.\" }\n");
        sb.append("            }\n");
        sb.append("          ]\n");
        sb.append("        }\n");
        sb.append("      },\n");
        sb.append("      \"results\": [\n");

        for (int i = 0; i < alerts.size(); i++) {
            AlertManager.RefactorAlert a = alerts.get(i);
            sb.append("        {\n");
            sb.append("          \"ruleId\": \"CS001\",\n");
            sb.append("          \"message\": { \"text\": \"").append(a.getIssueSummary().replace("\"", "'")).append("\" },\n");
            sb.append("          \"locations\": [\n");
            sb.append("            {\n");
            sb.append("              \"physicalLocation\": {\n");
            sb.append("                \"artifactLocation\": { \"uri\": \"").append(a.getMetrics().getFilePath().replace("\\", "/")).append("\" },\n");
            sb.append("                \"region\": { \"startLine\": ").append(a.getMetrics().getStartLine()).append(", \"endLine\": ").append(a.getMetrics().getEndLine()).append(" }\n");
            sb.append("              }\n");
            sb.append("            }\n");
            sb.append("          ]\n");
            sb.append("        }").append(i < alerts.size() - 1 ? "," : "").append("\n");
        }

        sb.append("      ]\n");
        sb.append("    }\n");
        sb.append("  ]\n");
        sb.append("}\n");

        try (FileWriter writer = new FileWriter(sarifFile)) {
            writer.write(sb.toString());
        }
        return sarifFile;
    }

    public static File exportJsonMetrics(WorkspaceScanner.ScanResult scanResult, File outputDir) throws IOException {
        if (!outputDir.exists()) outputDir.mkdirs();
        File jsonFile = new File(outputDir, "codesense-metrics.json");
        List<MethodMetrics> sorted = scanResult.getAvlTree().inOrderTraversal();

        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"totalMethods\": ").append(scanResult.getTotalMethodsCount()).append(",\n");
        sb.append("  \"scannedFiles\": ").append(scanResult.getScannedFilesCount()).append(",\n");
        sb.append("  \"treeHeight\": ").append(scanResult.getAvlTree().getHeight()).append(",\n");
        sb.append("  \"totalRotations\": ").append(scanResult.getAvlTree().getTotalRotations()).append(",\n");
        sb.append("  \"methods\": [\n");

        for (int i = 0; i < sorted.size(); i++) {
            MethodMetrics m = sorted.get(i);
            sb.append("    {\n");
            sb.append("      \"methodName\": \"").append(m.getMethodName()).append("\",\n");
            sb.append("      \"className\": \"").append(m.getClassName()).append("\",\n");
            sb.append("      \"loc\": ").append(m.getLinesOfCode()).append(",\n");
            sb.append("      \"cyclomaticComplexity\": ").append(m.getCyclomaticComplexity()).append(",\n");
            sb.append("      \"cognitiveComplexity\": ").append(m.getCognitiveComplexity()).append(",\n");
            sb.append("      \"maxNestingDepth\": ").append(m.getMaxNestingDepth()).append(",\n");
            sb.append("      \"maintainabilityIndex\": ").append(m.getMaintainabilityIndex()).append(",\n");
            sb.append("      \"complexityScore\": ").append(String.format("%.2f", m.getComplexityScore())).append(",\n");
            sb.append("      \"riskLevel\": \"").append(m.getRiskLevel().name()).append("\"\n");
            sb.append("    }").append(i < sorted.size() - 1 ? "," : "").append("\n");
        }

        sb.append("  ]\n}\n");

        try (FileWriter writer = new FileWriter(jsonFile)) {
            writer.write(sb.toString());
        }
        return jsonFile;
    }

    public static File exportCsvMetrics(List<MethodMetrics> methods, File outputDir) throws IOException {
        if (!outputDir.exists()) outputDir.mkdirs();
        File csvFile = new File(outputDir, "codesense-metrics.csv");

        try (FileWriter writer = new FileWriter(csvFile)) {
            writer.write("MethodName,ClassName,LOC,CC,CognitiveComplexity,MaxNestingDepth,MaintainabilityIndex,ComplexityScore,RiskLevel,CodeSmells\n");
            for (MethodMetrics m : methods) {
                writer.write(String.format("\"%s\",\"%s\",%d,%d,%d,%d,%.1f,%.2f,\"%s\",\"%s\"\n",
                        m.getMethodName(), m.getClassName(), m.getLinesOfCode(),
                        m.getCyclomaticComplexity(), m.getCognitiveComplexity(), m.getMaxNestingDepth(),
                        m.getMaintainabilityIndex(), m.getComplexityScore(), m.getRiskLevel().name(),
                        m.getCodeSmellsFormatted()));
            }
        }
        return csvFile;
    }

    public static void exportAll(WorkspaceScanner.ScanResult scanResult, List<AlertManager.RefactorAlert> alerts, File outputDir) throws IOException {
        if (!outputDir.exists()) outputDir.mkdirs();
        exportHtmlReport(scanResult, alerts, outputDir);
        exportMarkdownReport(scanResult, alerts, outputDir);
        exportPullRequestTemplate(scanResult, alerts, outputDir);
        exportSarifReport(scanResult, alerts, outputDir);
        exportJsonMetrics(scanResult, outputDir);
        exportCsvMetrics(scanResult.getAllMethods(), outputDir);
    }
}
