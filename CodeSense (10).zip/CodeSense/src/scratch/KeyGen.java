package scratch;

import com.codesense.platform.license.LicensePayload;
import com.codesense.platform.models.PlanType;

import java.security.*;
import java.util.Base64;
import java.util.UUID;

public class KeyGen {
    public static void main(String[] args) throws Exception {
        // 1. Generate Key Pair
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        KeyPair kp = kpg.generateKeyPair();
        PrivateKey privateKey = kp.getPrivate();
        PublicKey publicKey = kp.getPublic();

        System.out.println("=== NEW PUBLIC KEY ===");
        System.out.println(Base64.getEncoder().encodeToString(publicKey.getEncoded()));
        System.out.println("======================\n");

        // 2. Generate signed payloads
        long issue = 1710000000000L;
        long expiry = 1910000000000L;
        
        PlanType[] plans = {PlanType.PRO, PlanType.TEAM, PlanType.ENTERPRISE, PlanType.EDUCATION};
        
        for (PlanType plan : plans) {
            for (int i = 0; i < 10; i++) {
                String serialCode = "CODESENSE-" + plan.name() + "-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
                
                // Create payload structure (matches LicensePayload.getRawPayloadForVerification())
                String rawPayload = serialCode + "|" + plan.name() + "|DemoCustomer|" + issue + "|" + expiry + "|5";
                
                // Sign
                Signature sig = Signature.getInstance("SHA256withRSA");
                sig.initSign(privateKey);
                sig.update(rawPayload.getBytes("UTF-8"));
                String signatureB64 = Base64.getEncoder().encodeToString(sig.sign());
                
                System.out.println("sampleLicenseDatabase.put(\"" + serialCode + "\", new LicensePayload(\"" + 
                    serialCode + "\", PlanType." + plan.name() + ", \"DemoCustomer\", " + issue + "L, " + expiry + "L, 5, \"" + signatureB64 + "\"));");
            }
        }
    }
}
