# CodeSense – A Smart Code Complexity Analyzer Using AVL Trees

## Description
CodeSense is a high-performance, precision-engineered desktop software tool for analyzing source code complexity. It parses abstract syntax tree (AST) hierarchies across multiple languages (Java, Python, JavaScript) and utilizes a custom-built, zero-dependency AVL Tree to efficiently index, organize, and query analyzed routines in `O(log n)` time. It provides a robust GUI and a headless CLI.

## Features
- **Source code scanning:** Rapid multi-language AST scanning (Java, Python, JS).
- **Complexity analysis:** Computes Cyclomatic Complexity (CC), Cognitive Complexity (Cog), Maximum Nesting Depth (MND), Maintainability Index (MI), and Risk Level.
- **Custom AVL Tree:** Fully bespoke, self-balancing AVL Tree collection engine. No native Java collections are used for core indexing.
- **AVL balancing:** Automatic LL, RR, LR, and RL rotations to maintain `O(log n)` height.
- **Maximum/minimum complexity queries:** Guaranteed `O(log n)` extraction of extreme values.
- **Exact search:** Direct extraction of matching complexity scores.
- **Range queries:** Logarithmic extraction of complexity boundaries (e.g. methods scoring between 50 and 100).
- **Threshold alerts:** Automated refactoring suggestions based on configurable danger thresholds.
- **GUI:** Immersive Swing-based graphical dashboard.
- **CLI:** Headless interactive shell and direct pipeline execution modes.
- **Reporting/exporting:** Trajectory summaries and JSON reporting functionality.

## How to Build
CodeSense includes a unified `make.bat` pipeline for clean, robust orchestration that completely separates test and production binaries.

```cmd
make.bat clean
make.bat compile
```

## How to Test
All JUnit 5 test classes execute automatically against the compiled binaries via the `make.bat` pipeline.

```cmd
make.bat test
```

## How to Package
To package the final standalone `codesense.jar`:

```cmd
make.bat package
```

## How to Run GUI
```cmd
java -jar codesense.jar
# OR
make.bat run
```

## How to Run CLI
```cmd
java -jar codesense.jar --cli
# OR
make.bat run --cli

# Direct headless analysis
java -jar codesense.jar --analyze samples
```

## How to Use Help
```cmd
java -jar codesense.jar --help
```

## Custom AVL Tree Architecture
CodeSense abandons `java.util.TreeMap` in favor of a strictly custom AVL Tree. This ensures continuous, real-time balancing through structural rotations (LL, RR, LR, RL) upon every insertion. As the analyzer discovers new methods, they are inserted into the AVL tree with their complexity score acting as the comparative key. This mathematical structure guarantees `O(log n)` execution bounds for all critical data operations, enabling the rapid execution of inclusive range queries (e.g., retrieving all routines scoring between a baseline and a critical threshold).

## Known Limitations
- The internal AST parser employs a highly-tuned regex and heuristics engine for multi-language flexibility and speed, meaning extremely unstructured inline formatting may result in slightly divergent boundary detection compared to a strictly typed, full abstract-syntax-tree compiler implementation.
- Trends and snapshots are session-based unless integrated with external database storage.
