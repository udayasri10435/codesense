@echo off
rem COMPATIBILITY WRAPPER
rem This script redirects to the official build system: make.bat
cmd.exe /c "make.bat run %*"
exit /b %ERRORLEVEL%
