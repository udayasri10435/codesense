@echo off
setlocal enabledelayedexpansion
echo Launching CodeSense Analytical Utility...

set JAVA_CMD=java
set JBR_PATH=C:\Program Files\JetBrains\IntelliJ IDEA 2026.2\jbr\bin\java.exe

if exist "!JBR_PATH!" (
    set JAVA_CMD="!JBR_PATH!"
)

!JAVA_CMD! -cp bin com.codesense.Main %*
