# ⚠️ CodeSense: Known System Limitations & Scope Bounds

> **Academic Honesty Statement**:  
> In accordance with academic integrity guidelines for HND Software Engineering coursework, this document honestly details the technical scope boundaries, architectural constraints, and known limitations of CodeSense 1.0.

---

## 1. Lightweight Lexical Parser Scope (Not a Full AST Compiler Front-End)

`CodeParser` is engineered as a lightweight, multi-language structural analyzer using regular expressions, brace matching stacks, and indentation levels rather than a complete compiler AST parser (such as ANTLR, JavaParser, or Roslyn).

* **Lambda & Anonymous Class Boundaries**: In Java code with complex nested lambdas (`items.forEach(x -> { ... })`) or anonymous inner classes, brace-counting heuristics may count inner lambda block braces towards the enclosing method's length and nesting depth.
* **Multi-Line Method Signatures**: Method signatures split across multiple lines before the opening brace `{` may fail to match single-line regex patterns, causing the method to be parsed from the brace line or skipped.
* **Brace / Keyword Characters in Strings**: While single-line string literals are stripped prior to parsing, multi-line block strings or comments containing `{` or `}` characters across line breaks can temporarily skew brace depth counts.
* **Python Indentation Heuristics**: Python method parsing relies on 4-space indentation conventions. Non-standard mixed tab/space indentation can cause inaccurate method boundary detection.

---

## 2. Single-File Analysis & Cross-File Type Resolution Bounds

* **Per-File Isolation**: CodeSense performs static analysis on individual source files independently.
* **No Inter-Procedural Dataflow**: Call graph construction and coupling matrices rely on lexical method invocation tokens rather than deep symbol table resolution. Cross-package interface implementations and dynamic polymorphism calls are not resolved at runtime.

---

## 3. Floating-Point AVL Tree Key Precision & Payload Merging

* **Epsilon Key Matching**: The custom `AVLTree` uses floating-point `double` keys (complexity scores). Nodes are matched using a small epsilon threshold (`|key1 - key2| < 0.0001`).
* **Duplicate Key Grouping**: Methods with complexity scores differing by less than `0.0001` are stored within a single AVL node's payload list (`node.getDataList()`). While this preserves $O(\log N)$ tree height, it groups near-identical scores together.

---

## 4. In-Memory Trend Snapshot Volatility

* **Session Scope**: The `SnapshotManager` maintains point-in-time codebase health snapshots in JVM heap memory during runtime execution.
* **Persistence Requirement**: Closing the application resets in-memory snapshot history unless the user explicitly exports the audit bundle to HTML, Markdown, or SARIF formats prior to shutdown.

---

## 5. Java Swing GUI Display Constraints

* **Fixed Min-Dimensions**: The desktop dashboard is designed for high-density developer displays with a minimum resolution of $1460 \times 840$.
* **High-DPI Scaling**: On certain operating systems with non-standard display scaling (>150%), custom Swing tab badges and graph canvas elements may require manual window resizing.
