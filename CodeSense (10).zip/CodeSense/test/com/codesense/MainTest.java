package com.codesense;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.awt.GraphicsEnvironment;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MainTest {

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final PrintStream originalErr = System.err;
    private final InputStream originalIn = System.in;

    @BeforeEach
    public void setUpStreams() {
        System.setOut(new PrintStream(outContent));
        System.setErr(new PrintStream(errContent));
    }

    @AfterEach
    public void restoreStreams() {
        System.setOut(originalOut);
        System.setErr(originalErr);
        System.setIn(originalIn);
    }

    @Test
    void testHelpArgument() {
        int exitCode = Main.processArgs(new String[]{"--help"});
        assertEquals(0, exitCode);
        assertTrue(outContent.toString().contains("Usage:"));
    }

    @Test
    void testHelpShortArgument() {
        int exitCode = Main.processArgs(new String[]{"-h"});
        assertEquals(0, exitCode);
        assertTrue(outContent.toString().contains("Usage:"));
    }

    @Test
    void testInvalidArgument() {
        int exitCode = Main.processArgs(new String[]{"--invalid-arg"});
        assertEquals(1, exitCode);
        assertTrue(errContent.toString().contains("Unknown argument"));
        assertTrue(outContent.toString().contains("Usage:"));
    }

    @Test
    void testAnalyzeMissingPath() {
        int exitCode = Main.processArgs(new String[]{"--analyze"});
        assertEquals(1, exitCode);
        assertTrue(errContent.toString().contains("requires a target path"));
    }

    @Test
    void testCliArgument() {
        // Mock input to automatically exit the CLI interactive shell
        ByteArrayInputStream in = new ByteArrayInputStream("exit\n".getBytes());
        System.setIn(in);
        
        int exitCode = Main.processArgs(new String[]{"--cli"});
        assertEquals(0, exitCode);
        assertTrue(outContent.toString().contains("CodeSense>"));
        assertTrue(outContent.toString().contains("Exiting CodeSense CLI"));
    }

    @Test
    void testNoArguments() {
        // If we are in a headless environment (like CI/CD), it should launch CLI automatically
        // If we are in a graphical environment, it should return -1 to indicate GUI launch
        
        // Let's provide a dummy exit command just in case it launches CLI
        ByteArrayInputStream in = new ByteArrayInputStream("exit\n".getBytes());
        System.setIn(in);
        
        int exitCode = Main.processArgs(new String[]{});
        
        if (GraphicsEnvironment.isHeadless()) {
            assertEquals(0, exitCode);
            assertTrue(errContent.toString().contains("No graphical display detected"));
        } else {
            assertEquals(-1, exitCode);
        }
    }
}
