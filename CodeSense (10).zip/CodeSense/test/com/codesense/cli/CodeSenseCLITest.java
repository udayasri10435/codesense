package com.codesense.cli;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CodeSenseCLITest {

    private CodeSenseCLI cli;

    @BeforeEach
    public void setUp() {
        com.codesense.platform.db.LocalDatabaseManager db = new com.codesense.platform.db.LocalDatabaseManager();
        com.codesense.platform.license.LicenseManager licenseManager = new com.codesense.platform.license.LicenseManager(db);
        cli = new CodeSenseCLI(licenseManager);
    }

    @Test
    @DisplayName("CLI handles non-numeric range inputs without crashing")
    public void testMalformedRangeCommand() {
        assertDoesNotThrow(() -> {
            boolean result = cli.processCommand("range invalid_min invalid_max");
            assertTrue(result, "Should remain active after malformed range input");
        });
    }

    @Test
    @DisplayName("CLI handles empty scan path without crashing")
    public void testEmptyScanPath() {
        assertDoesNotThrow(() -> {
            boolean result = cli.processCommand("scan  ");
            assertTrue(result, "Should remain active after empty scan command");
        });
    }

    @Test
    @DisplayName("CLI handles non-existent scan path cleanly")
    public void testNonExistentScanPath() {
        assertDoesNotThrow(() -> {
            boolean result = cli.processCommand("scan non_existent_folder_xyz_9999");
            assertTrue(result, "Should remain active after non-existent path input");
        });
    }

    @Test
    @DisplayName("CLI parses paths containing spaces cleanly")
    public void testScanPathWithSpaces() {
        assertDoesNotThrow(() -> {
            boolean result = cli.processCommand("scan samples");
            assertTrue(result, "Should process scan path cleanly");
        });
    }

    @Test
    @DisplayName("CLI handles unknown command strings without crashing")
    public void testUnknownCommand() {
        assertDoesNotThrow(() -> {
            boolean result = cli.processCommand("invalidcommand_123");
            assertTrue(result, "Should remain active after unknown command");
        });
    }

    @Test
    @DisplayName("CLI exit command returns false to signal shell termination")
    public void testExitCommand() {
        boolean result = cli.processCommand("exit");
        assertFalse(result, "Exit command should return false to terminate shell loop");
    }
}
