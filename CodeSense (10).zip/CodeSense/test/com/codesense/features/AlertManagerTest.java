package com.codesense.features;

import com.codesense.analyzer.MethodMetrics;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class AlertManagerTest {

    @Test
    @DisplayName("Evaluate metrics when score breaches threshold but sub-checks pass (bug fix verification)")
    public void testScoreBreachWithoutSubCheckBreach() {
        // High complexity score (23.3 >= 15.0) but low CC (2 < 9), MND (1 < 3), Cognitive (2 <= 10), and high MI (60.7 >= 55.0)
        MethodMetrics m = new MethodMetrics("calculateDiscount", "SampleService", "SampleService.java",
                1, 15, 2, 2, 1, 15, 20);

        AlertManager manager = new AlertManager();
        List<AlertManager.RefactorAlert> alerts = manager.evaluateMetrics(Collections.singletonList(m));

        assertEquals(1, alerts.size(), "Should trigger alert for high complexity score");
        AlertManager.RefactorAlert alert = alerts.get(0);

        assertNotNull(alert.getIssueSummary());
        assertFalse(alert.getIssueSummary().trim().isEmpty(), "Issue summary must NOT be blank when scoreBreach is true");
        assertTrue(alert.getIssueSummary().contains("Composite Complexity Score"),
                "Issue summary should contain fallback Composite Complexity Score description");

        assertNotNull(alert.getRefactoringRecommendation());
        assertFalse(alert.getRefactoringRecommendation().trim().isEmpty(), "Refactoring recommendation must NOT be blank");
    }

    @Test
    @DisplayName("Assert no RefactorAlert ever has a blank issueSummary or refactoringRecommendation")
    public void testNoAlertHasBlankSummary() {
        List<MethodMetrics> methods = new ArrayList<>();
        methods.add(new MethodMetrics("methodA", "ClassA", "ClassA.java", 1, 50, 12, 15, 5, 50, 4));
        methods.add(new MethodMetrics("methodB", "ClassB", "ClassB.java", 1, 30, 2, 2, 1, 30, 2));
        methods.add(new MethodMetrics("methodC", "ClassC", "ClassC.java", 1, 40, 1, 1, 4, 40, 1));
        methods.add(new MethodMetrics("methodD", "ClassD", "ClassD.java", 1, 10, 1, 1, 1, 10, 1)); // no breach

        AlertManager manager = new AlertManager();
        List<AlertManager.RefactorAlert> alerts = manager.evaluateMetrics(methods);

        assertFalse(alerts.isEmpty(), "Alerts should be generated for breaching metrics");
        for (AlertManager.RefactorAlert alert : alerts) {
            assertNotNull(alert.getIssueSummary(), "Issue summary cannot be null");
            assertFalse(alert.getIssueSummary().trim().isEmpty(), "Issue summary cannot be empty for any alert");
            assertNotNull(alert.getRefactoringRecommendation(), "Recommendation cannot be null");
            assertFalse(alert.getRefactoringRecommendation().trim().isEmpty(), "Recommendation cannot be empty for any alert");
            assertNotNull(alert.getSeverity(), "Severity must not be null");
        }
    }
}
