package com.codesense.analyzer;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ParserEdgeCaseTest {

    @Test
    @DisplayName("Parser degrades gracefully on tricky Java file with lambdas and braces in strings")
    public void testTrickyJavaParsing() {
        File file = new File("samples/TrickyJavaSample.java");
        assertTrue(file.exists(), "TrickyJavaSample.java must exist");

        assertDoesNotThrow(() -> {
            List<MethodMetrics> metrics = CodeParser.parseFile(file);
            assertNotNull(metrics);
            assertFalse(metrics.isEmpty(), "Should extract methods despite lambdas and braces in string literals");
        });
    }

    @Test
    @DisplayName("Parser degrades gracefully on tricky Python file with multiline docstrings containing def keyword")
    public void testTrickyPythonParsing() {
        File file = new File("samples/TrickyPythonSample.py");
        assertTrue(file.exists(), "TrickyPythonSample.py must exist");

        assertDoesNotThrow(() -> {
            List<MethodMetrics> metrics = CodeParser.parseFile(file);
            assertNotNull(metrics);
            assertFalse(metrics.isEmpty(), "Should extract methods despite def keywords in docstrings");
        });
    }

    @Test
    @DisplayName("Parser degrades gracefully on tricky JavaScript file with arrow functions and template literals")
    public void testTrickyJSParsing() {
        File file = new File("samples/TrickyJSSample.js");
        assertTrue(file.exists(), "TrickyJSSample.js must exist");

        assertDoesNotThrow(() -> {
            List<MethodMetrics> metrics = CodeParser.parseFile(file);
            assertNotNull(metrics);
            assertFalse(metrics.isEmpty(), "Should extract functions despite arrow functions and template literals");
        });
    }
}
