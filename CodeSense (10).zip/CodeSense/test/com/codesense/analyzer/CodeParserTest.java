package com.codesense.analyzer;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class CodeParserTest {

    @Test
    @DisplayName("Parse Java sample file and compute cyclomatic complexity and nesting depth")
    public void testJavaParsing() throws IOException {
        File sampleFile = new File("samples/SampleService.java");
        assertTrue(sampleFile.exists(), "SampleService.java must exist");

        List<MethodMetrics> metrics = CodeParser.parseFile(sampleFile);
        assertFalse(metrics.isEmpty(), "Should parse methods from Java sample file");

        MethodMetrics calcDiscount = metrics.stream()
                .filter(m -> m.getMethodName().equals("calculateDiscount"))
                .findFirst()
                .orElse(null);

        assertNotNull(calcDiscount, "calculateDiscount method should be parsed");
        assertTrue(calcDiscount.getCyclomaticComplexity() > 1, "Cyclomatic complexity should account for decision branches");
        assertTrue(calcDiscount.getMaxNestingDepth() >= 2, "Max nesting depth should reflect nested branches");
    }

    @Test
    @DisplayName("Parse Python sample file and compute metrics")
    public void testPythonParsing() throws IOException {
        File pyFile = new File("samples/algorithm.py");
        assertTrue(pyFile.exists(), "algorithm.py must exist");

        List<MethodMetrics> metrics = CodeParser.parseFile(pyFile);
        assertFalse(metrics.isEmpty(), "Should parse python functions");

        MethodMetrics analyzeMatrix = metrics.stream()
                .filter(m -> m.getMethodName().equals("analyze_data_matrix"))
                .findFirst()
                .orElse(null);

        assertNotNull(analyzeMatrix, "analyze_data_matrix function should be parsed");
        assertTrue(analyzeMatrix.getCyclomaticComplexity() >= 1);
    }

    @Test
    @DisplayName("Parse JavaScript sample file and compute metrics")
    public void testJSParsing() throws IOException {
        File jsFile = new File("samples/script.js");
        assertTrue(jsFile.exists(), "script.js must exist");

        List<MethodMetrics> metrics = CodeParser.parseFile(jsFile);
        assertFalse(metrics.isEmpty(), "Should parse JavaScript functions");

        MethodMetrics processUserData = metrics.stream()
                .filter(m -> m.getMethodName().equals("processUserData"))
                .findFirst()
                .orElse(null);

        assertNotNull(processUserData, "processUserData function should be parsed");
        assertTrue(processUserData.getCyclomaticComplexity() > 1);
    }
}
