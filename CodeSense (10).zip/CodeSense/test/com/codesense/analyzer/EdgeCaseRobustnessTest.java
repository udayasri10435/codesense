package com.codesense.analyzer;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class EdgeCaseRobustnessTest {

    @Test
    @DisplayName("Scanning empty directory returns clean result without exceptions")
    public void testEmptyDirectoryScan(@TempDir Path tempDir) {
        File emptyDir = tempDir.toFile();
        WorkspaceScanner.ScanResult result = assertDoesNotThrow(() -> WorkspaceScanner.scanWorkspace(emptyDir));

        assertNotNull(result);
        assertEquals(0, result.getScannedFilesCount());
        assertEquals(0, result.getTotalMethodsCount());
        assertEquals(0, result.getTotalLinesOfCode());
        assertNotNull(result.getAvlTree());
        assertNull(result.getAvlTree().getRoot());
    }

    @Test
    @DisplayName("Corrupt binary file with .java extension skips cleanly without crashing scan")
    public void testCorruptBinaryFileScan(@TempDir Path tempDir) throws IOException {
        File corruptFile = new File(tempDir.toFile(), "CorruptBinary.java");
        try (FileWriter fw = new FileWriter(corruptFile)) {
            // Write binary non-text garbage characters
            fw.write("\u0000\u0001\u0002\u0003\u00FF\u00FE\u00FD\u007F");
        }

        WorkspaceScanner.ScanResult result = assertDoesNotThrow(() -> WorkspaceScanner.scanWorkspace(tempDir.toFile()));
        assertNotNull(result);
    }

    @Test
    @DisplayName("Very large method (>500 LOC) parses cleanly without stack overflow or pathological looping")
    public void testLargeMethodParsing(@TempDir Path tempDir) throws IOException {
        File largeFile = new File(tempDir.toFile(), "MonolithicService.java");
        try (PrintWriter pw = new PrintWriter(new FileWriter(largeFile))) {
            pw.println("public class MonolithicService {");
            pw.println("    public void monolithicRoutine() {");
            pw.println("        int sum = 0;");
            for (int i = 0; i < 600; i++) {
                pw.println("        if (sum > " + i + ") { sum += " + i + "; }");
            }
            pw.println("    }");
            pw.println("}");
        }

        List<MethodMetrics> metrics = assertDoesNotThrow(() -> CodeParser.parseFile(largeFile));
        assertNotNull(metrics);
        assertFalse(metrics.isEmpty());

        MethodMetrics mono = metrics.get(0);
        assertEquals("monolithicRoutine", mono.getMethodName());
        assertTrue(mono.getLinesOfCode() >= 600, "Should handle methods with > 500 lines");
        assertTrue(mono.getCyclomaticComplexity() > 500, "CC should account for all decision branches");
    }
}
