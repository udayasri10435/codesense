package com.codesense.analyzer;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

public class PathSafetyTest {

    @Test
    @DisplayName("Scanner prevents symlink cycle infinite loops safely")
    public void testSymlinkCyclePrevention(@TempDir Path tempDir) throws IOException {
        Path subDir1 = tempDir.resolve("sub1");
        Path subDir2 = subDir1.resolve("sub2");
        Files.createDirectories(subDir2);

        // Create a test source file
        File file1 = subDir1.resolve("Sample.java").toFile();
        try (FileWriter fw = new FileWriter(file1)) {
            fw.write("public class Sample { public void test() {} }");
        }

        // Create symlink pointing back to parent directory if OS supports symlinks
        try {
            Path symlink = subDir2.resolve("loop_link");
            Files.createSymbolicLink(symlink, subDir1);
        } catch (UnsupportedOperationException | IOException ignored) {
            // OS / filesystem privileges may disallow symlink creation in test environment
        }

        WorkspaceScanner.ScanResult result = assertDoesNotThrow(() -> WorkspaceScanner.scanWorkspace(tempDir.toFile()));
        assertNotNull(result);
        assertTrue(result.getScannedFilesCount() >= 1);
    }
}
