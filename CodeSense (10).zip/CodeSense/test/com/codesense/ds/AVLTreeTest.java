package com.codesense.ds;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class AVLTreeTest {

    private AVLTree<String> tree;

    @BeforeEach
    public void setUp() {
        tree = new AVLTree<>();
    }

    @Test
    @DisplayName("Single Right (LL) Rotation on left-left sequence")
    public void testLLRotation() {
        tree.insert(30.0, "Node30");
        tree.insert(20.0, "Node20");
        tree.insert(10.0, "Node10");

        assertEquals(20.0, tree.getRoot().getKey(), 0.001);
        assertEquals(10.0, tree.getRoot().getLeft().getKey(), 0.001);
        assertEquals(30.0, tree.getRoot().getRight().getKey(), 0.001);
        assertTrue(tree.getTotalRotations() > 0);
        assertTrue(tree.getRotationLogs().stream().anyMatch(log -> log.contains("LL") || log.contains("Right")));
    }

    @Test
    @DisplayName("Single Left (RR) Rotation on right-right sequence")
    public void testRRRotation() {
        tree.insert(10.0, "Node10");
        tree.insert(20.0, "Node20");
        tree.insert(30.0, "Node30");

        assertEquals(20.0, tree.getRoot().getKey(), 0.001);
        assertEquals(10.0, tree.getRoot().getLeft().getKey(), 0.001);
        assertEquals(30.0, tree.getRoot().getRight().getKey(), 0.001);
        assertTrue(tree.getTotalRotations() > 0);
        assertTrue(tree.getRotationLogs().stream().anyMatch(log -> log.contains("RR") || log.contains("Left")));
    }

    @Test
    @DisplayName("LR Double Rotation on left-right sequence")
    public void testLRRotation() {
        tree.insert(30.0, "Node30");
        tree.insert(10.0, "Node10");
        tree.insert(20.0, "Node20");

        assertEquals(20.0, tree.getRoot().getKey(), 0.001);
        assertEquals(10.0, tree.getRoot().getLeft().getKey(), 0.001);
        assertEquals(30.0, tree.getRoot().getRight().getKey(), 0.001);
        assertTrue(tree.getRotationLogs().stream().anyMatch(log -> log.contains("LR")));
    }

    @Test
    @DisplayName("RL Double Rotation on right-left sequence")
    public void testRLRotation() {
        tree.insert(10.0, "Node10");
        tree.insert(30.0, "Node30");
        tree.insert(20.0, "Node20");

        assertEquals(20.0, tree.getRoot().getKey(), 0.001);
        assertEquals(10.0, tree.getRoot().getLeft().getKey(), 0.001);
        assertEquals(30.0, tree.getRoot().getRight().getKey(), 0.001);
        assertTrue(tree.getRotationLogs().stream().anyMatch(log -> log.contains("RL")));
    }

    @Test
    @DisplayName("getMinNode and getMaxNode on tree and empty tree")
    public void testMinMaxNode() {
        assertNull(tree.getMinNode());
        assertNull(tree.getMaxNode());

        tree.insert(15.0, "Node15");
        tree.insert(5.0, "Node5");
        tree.insert(25.0, "Node25");
        tree.insert(1.0, "Node1");

        assertNotNull(tree.getMinNode());
        assertEquals(1.0, tree.getMinNode().getKey(), 0.001);

        assertNotNull(tree.getMaxNode());
        assertEquals(25.0, tree.getMaxNode().getKey(), 0.001);
    }

    @Test
    @DisplayName("rangeSearch boundary inclusion and exclusion")
    public void testRangeSearch() {
        tree.insert(10.0, "Item10");
        tree.insert(20.0, "Item20");
        tree.insert(30.0, "Item30");
        tree.insert(40.0, "Item40");

        List<String> range = tree.rangeSearch(15.0, 35.0);
        assertEquals(2, range.size());
        assertTrue(range.contains("Item20"));
        assertTrue(range.contains("Item30"));
        assertFalse(range.contains("Item10"));
        assertFalse(range.contains("Item40"));

        List<String> exactBoundaries = tree.rangeSearch(10.0, 40.0);
        assertEquals(4, exactBoundaries.size());
    }

    @Test
    @DisplayName("Duplicate-key payload merging")
    public void testDuplicateKeyMerging() {
        tree.insert(15.0, "PayloadA");
        tree.insert(15.0, "PayloadB");

        AVLNode<String> node = tree.searchNode(15.0);
        assertNotNull(node);
        assertEquals(2, node.getDataList().size());
        assertTrue(node.getDataList().contains("PayloadA"));
        assertTrue(node.getDataList().contains("PayloadB"));
    }
}
