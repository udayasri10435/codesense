@echo off
setlocal enabledelayedexpansion

set CMD=%1
if "%CMD%"=="" set CMD=compile

set JAVA_HOME_BIN=C:\Program Files\JetBrains\IntelliJ IDEA 2026.2\jbr\bin
set JAVAC_CMD=javac
set JAVA_CMD=java
set JAR_CMD=jar

if exist "%JAVA_HOME_BIN%\javac.exe" (
    set JAVAC_CMD="%JAVA_HOME_BIN%\javac.exe"
    set JAVA_CMD="%JAVA_HOME_BIN%\java.exe"
    set JAR_CMD="%JAVA_HOME_BIN%\jar.exe"
)

if "%CMD%"=="clean" goto do_clean
if "%CMD%"=="compile" goto do_compile
if "%CMD%"=="test" goto do_test
if "%CMD%"=="package" goto do_package
if "%CMD%"=="run" goto do_run

echo Unknown command: %CMD%
echo Valid commands: clean, compile, test, package, run
exit /b 1

:do_clean
echo Cleaning project...
if exist build rmdir /s /q build
if exist bin rmdir /s /q bin
if exist codesense.jar del /q codesense.jar
if exist sources.txt del /q sources.txt
if exist test_sources.txt del /q test_sources.txt
echo Clean completed.
exit /b 0

:do_compile
echo ========================================================
echo Building CodeSense Analytical Utility (JDK 17 Target)
echo ========================================================
if not exist build\classes\main mkdir build\classes\main

echo Discovering production source files...
if exist sources.txt del sources.txt
powershell -Command "Get-ChildItem -Path src -Recurse -Include *.java | Where-Object { $_.FullName -notmatch '\\src\\scratch\\' } | Select-Object -ExpandProperty FullName | ForEach-Object { '\"' + ($_ -replace '\\', '/') + '\"' } | Set-Content sources.txt"

echo Compiling production Java source files...
!JAVAC_CMD! --release 17 -d build\classes\main -cp "lib/*" @sources.txt

if %ERRORLEVEL% EQU 0 (
    echo Production Compilation SUCCESSFUL!
    exit /b 0
) else (
    echo Production Compilation FAILED!
    exit /b 1
)

:do_test
echo ========================================================
echo Compiling and Running CodeSense JUnit 5 Test Suite
echo ========================================================

if not exist build\classes\test mkdir build\classes\test
echo Discovering test source files...
if exist test_sources.txt del test_sources.txt
powershell -Command "Get-ChildItem -Path test -Recurse -Include *.java | Select-Object -ExpandProperty FullName | ForEach-Object { '\"' + ($_ -replace '\\', '/') + '\"' } | Set-Content test_sources.txt"

echo Compiling test Java source files...
!JAVAC_CMD! --release 17 -d build\classes\test -cp "build\classes\main;lib/*" @test_sources.txt

if %ERRORLEVEL% NEQ 0 (
    echo Test Compilation FAILED!
    exit /b 1
)

!JAVA_CMD! -jar lib/junit-platform-console-standalone-1.10.2.jar --class-path "build\classes\main;build\classes\test" --scan-class-path

if %ERRORLEVEL% EQU 0 (
    echo Tests SUCCESSFUL!
    exit /b 0
) else (
    echo Tests FAILED!
    exit /b 1
)

:do_package
echo ========================================================
echo Packaging CodeSense Standalone Fat JAR (codesense.jar)
echo ========================================================

call %0 compile
if %ERRORLEVEL% NEQ 0 (
    echo Compilation failed. Aborting JAR packaging.
    exit /b 1
)

echo Packaging codesense.jar via Java JarPackager...
!JAVA_CMD! -cp build\classes\main com.codesense.tools.JarPackager build\classes\main

if %ERRORLEVEL% EQU 0 (
    echo Packaging SUCCESSFUL! Created standalone codesense.jar
    exit /b 0
) else (
    echo JAR packaging failed.
    exit /b 1
)

:do_run
echo Launching CodeSense Analytical Utility...
shift
set "ARGS="
:loop
if "%~1"=="" goto after_loop
set "ARGS=!ARGS! %~1"
shift
goto loop
:after_loop

!JAVA_CMD! -cp build\classes\main com.codesense.Main !ARGS!
exit /b %ERRORLEVEL%
