@echo off
rem COMPATIBILITY WRAPPER
rem This script redirects to the official build system: make.bat
cmd.exe /c "make.bat test"
exit /b %ERRORLEVEL%
