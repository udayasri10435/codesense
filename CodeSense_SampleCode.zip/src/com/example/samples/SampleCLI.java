/*
 * MIT License
 *
 * Copyright (c) 2026 udayasri10435, Yadushan2004, Vishnukaran
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package com.example.samples;

/**
 * Sample command-line entry point showing MIT-licensed CLI code style.
 */
public class SampleCLI {

    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: SampleCLI <word>");
            return;
        }

        String word = args[0];
        System.out.println("Original: " + word);
        System.out.println("Reversed: " + StringUtils.reverse(word));
        System.out.println("Blank?    " + StringUtils.isBlank(word));
    }
}
