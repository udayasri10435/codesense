@echo off
echo Building CodeSense Analytical Utility using JDK 25...

if not exist bin mkdir bin

"C:\Program Files\JetBrains\IntelliJ IDEA 2026.2\jbr\bin\javac.exe" -d bin -sourcepath src src\com\codesense\Main.java src\com\codesense\VerifyCodeSense.java src\com\codesense\exporter\*.java src\com\codesense\ui\*.java src\com\codesense\analyzer\*.java src\com\codesense\ds\*.java src\com\codesense\features\*.java src\com\codesense\cli\*.java samples\*.java

if %ERRORLEVEL% EQU 0 (
    echo.
    echo Compilation SUCCESSFUL! Binaries compiled into ./bin directory.
) else (
    echo.
    echo Compilation FAILED! Please check error output above.
)
