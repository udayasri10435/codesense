package com.codesense.features;

import com.codesense.analyzer.MethodMetrics;

import java.util.ArrayList;
import java.util.List;

/**
 * Enhanced Live Refactor Alerts Engine.
 * Isolates high-weight routines breaching design baselines with precise architectural recommendations.
 */
public class AlertManager {

    public static class RefactorAlert {
        private final MethodMetrics metrics;
        private final String issueSummary;
        private final String refactoringRecommendation;
        private final MethodMetrics.RiskLevel severity;

        public RefactorAlert(MethodMetrics metrics, String issueSummary, String refactoringRecommendation, MethodMetrics.RiskLevel severity) {
            this.metrics = metrics;
            this.issueSummary = issueSummary;
            this.refactoringRecommendation = refactoringRecommendation;
            this.severity = severity;
        }

        public MethodMetrics getMetrics() {
            return metrics;
        }

        public String getIssueSummary() {
            return issueSummary;
        }

        public String getRefactoringRecommendation() {
            return refactoringRecommendation;
        }

        public MethodMetrics.RiskLevel getSeverity() {
            return severity;
        }

        @Override
        public String toString() {
            return String.format("[%s] %s.%s() -> %s | Recommendation: %s",
                    severity.name(), metrics.getClassName(), metrics.getMethodName(), issueSummary, refactoringRecommendation);
        }
    }

    private double maxScoreThreshold = 15.0;
    private int maxCcThreshold = 9;
    private int maxMndThreshold = 3;

    public List<RefactorAlert> evaluateMetrics(List<MethodMetrics> methods) {
        List<RefactorAlert> alerts = new ArrayList<>();
        if (methods == null) return alerts;

        for (MethodMetrics m : methods) {
            boolean scoreBreach = m.getComplexityScore() >= maxScoreThreshold;
            boolean ccBreach = m.getCyclomaticComplexity() >= maxCcThreshold;
            boolean mndBreach = m.getMaxNestingDepth() >= maxMndThreshold;
            boolean miBreach = m.getMaintainabilityIndex() < 55.0;

            if (scoreBreach || ccBreach || mndBreach || miBreach) {
                StringBuilder issues = new StringBuilder();
                StringBuilder recs = new StringBuilder();

                if (ccBreach) {
                    issues.append(String.format("Cyclomatic Complexity (%d >= %d) ", m.getCyclomaticComplexity(), maxCcThreshold));
                    recs.append("Replace Conditional Logic with Polymorphism or Command Pattern. ");
                }
                if (mndBreach) {
                    issues.append(String.format("Max Nesting Depth (%d >= %d) ", m.getMaxNestingDepth(), maxMndThreshold));
                    recs.append("Flatten nested branches using Early Return Guard Clauses. ");
                }
                if (m.getCognitiveComplexity() > 10) {
                    issues.append(String.format("Cognitive Overload (%d) ", m.getCognitiveComplexity()));
                    recs.append("Extract helper routines to lower mental trace load. ");
                }
                if (miBreach) {
                    issues.append(String.format("Low Maintainability Index (%.1f/100) ", m.getMaintainabilityIndex()));
                    recs.append("Decompose monolithic routine into cohesive domain services. ");
                }

                alerts.add(new RefactorAlert(m, issues.toString().trim(), recs.toString().trim(), m.getRiskLevel()));
            }
        }

        return alerts;
    }
}
