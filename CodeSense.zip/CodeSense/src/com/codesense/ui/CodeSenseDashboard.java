package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.analyzer.WorkspaceScanner;
import com.codesense.ds.AVLTree;
import com.codesense.exporter.ReportExporter;
import com.codesense.features.AlertManager;
import com.codesense.features.SnapshotManager;
import com.codesense.features.TechnicalDebtEstimator;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Enhanced CodeSense Desktop Dashboard.
 * Integrates Health Gauge, Technical Debt Estimator, Real-Time Search Filter, Source Previewer,
 * Refactoring Assistant, Side-by-Side Diff, Executive Summary, Design Structure Matrix (DSM), Roadmap Timeline, Design Pattern Advisor, Security Matrix, Tech Debt ROI Calculator, What-If Simulator, Priority Matrix, Benchmark Profiler, Radar Chart, Milestones Tracker, Leaderboard, Code Smell Matrix, Terminal CLI Shell, AVL Simulator, Version Diff, Treemap Heatmap, Class Dependency Graph, CI/CD Quality Gate, and Multi-Format Exporters.
 */
public class CodeSenseDashboard extends JFrame {

    private JTextField pathField;
    private JTextField searchField;

    private JLabel healthScoreLabel;
    private JLabel debtLabel;
    private JLabel totalMethodsLabel;
    private JLabel maxCompLabel;
    private JLabel avgCompLabel;
    private JLabel treeHeightLabel;
    private JLabel totalRotationsLabel;
    private JLabel criticalAlertsLabel;

    private JTable methodsTable;
    private DefaultTableModel methodsTableModel;
    private JTable alertTable;
    private DefaultTableModel alertTableModel;
    private JTable rangeTable;
    private DefaultTableModel rangeTableModel;

    private JTextArea rotationLogArea;
    private AVLTreeCanvas treeCanvas;
    private TrendChartCanvas trendCanvas;
    private CodeViewerPanel codeViewerPanel;
    private RefactorAssistantPanel refactorAssistantPanel;
    private DiagnosticsPanel diagnosticsPanel;
    private AVLPlaygroundPanel avlPlaygroundPanel;
    private VersionDiffPanel versionDiffPanel;
    private HeatmapPanel heatmapPanel;
    private QualityGatePanel qualityGatePanel;
    private DependencyGraphPanel dependencyGraphPanel;
    private RadarChartPanel radarChartPanel;
    private MilestonesPanel milestonesPanel;
    private CodeSmellMatrixPanel codeSmellMatrixPanel;
    private CodeDiffViewerPanel codeDiffViewerPanel;
    private BenchmarkPanel benchmarkPanel;
    private WhatIfSimulatorPanel whatIfSimulatorPanel;
    private LeaderboardPanel leaderboardPanel;
    private CLIShellPanel cliShellPanel;
    private PriorityMatrixPanel priorityMatrixPanel;
    private DSMPanel dsmPanel;
    private ExecutiveSummaryPanel executiveSummaryPanel;
    private RoadmapTimelinePanel roadmapTimelinePanel;
    private DesignPatternAdvisorPanel patternAdvisorPanel;
    private ROICalculatorPanel roiCalculatorPanel;
    private SecurityMatrixPanel securityMatrixPanel;

    private JSpinner minRangeSpinner;
    private JSpinner maxRangeSpinner;

    private CardLayout cardLayout;
    private JPanel cardContainer;
    private List<CustomDarkButton> tabButtons;

    private WorkspaceScanner.ScanResult currentScanResult;
    private final AlertManager alertManager;
    private final SnapshotManager snapshotManager;

    public CodeSenseDashboard() {
        super("CodeSense - Smart Code Complexity Analyzer Using Custom AVL Trees");
        this.alertManager = new AlertManager();
        this.snapshotManager = new SnapshotManager();

        initUI();
    }

    private void initUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1880, 980);
        setMinimumSize(new Dimension(1460, 840));
        setLocationRelativeTo(null);

        getContentPane().setBackground(BG_OBSIDIAN);
        setLayout(new BorderLayout(0, 0));

        // 1. Top Header Banner
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PANEL_SLATE);
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK),
                BorderFactory.createEmptyBorder(12, 20, 12, 20)
        ));

        JPanel titleSubPanel = new JPanel(new GridLayout(2, 1, 0, 3));
        titleSubPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("⚡ CodeSense: Smart Code Complexity Analyzer");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(ACCENT_CYAN);

        JLabel subtitleLabel = new JLabel("PDSA Assignment Project | Multi-Language Routine Analyzer & Custom Native Self-Balancing AVL Tree Engine");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitleLabel.setForeground(TEXT_MUTED);

        titleSubPanel.add(titleLabel);
        titleSubPanel.add(subtitleLabel);

        JLabel teamLabel = new JLabel("<html><div style='text-align: right; color: #94a3b8; font-size: 10px;'>" +
                "<b style='color:#38bdf8;'>Dev Team:</b> S H U S M Premathilaka (COHNDSE252F-018) | S. Yadushan (COHNDSE252F-051)<br>" +
                "K. Vishnukaran (COHNDSE252F-062)</div></html>");

        headerPanel.add(titleSubPanel, BorderLayout.WEST);
        headerPanel.add(teamLabel, BorderLayout.EAST);

        // 2. Control Toolbar
        JPanel controlBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 10));
        controlBar.setBackground(PANEL_SLATE);
        controlBar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK));

        JLabel pathLbl = new JLabel("Target Workspace Path:");
        pathLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        pathLbl.setForeground(TEXT_BRIGHT);

        pathField = new JTextField(25);
        pathField.setFont(new Font("Consolas", Font.PLAIN, 12));
        pathField.setText(new File("samples").exists() ? new File("samples").getAbsolutePath() : new File(".").getAbsolutePath());
        pathField.setBackground(INPUT_DARK);
        pathField.setForeground(ACCENT_CYAN);
        pathField.setCaretColor(TEXT_BRIGHT);
        pathField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_DARK, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        CustomDarkButton browseBtn = new CustomDarkButton("📁 Browse...", CARD_NAVY, TEXT_BRIGHT);
        browseBtn.addActionListener(e -> chooseDirectory());

        CustomDarkButton scanBtn = new CustomDarkButton("⚡ Run Scan", ACCENT_BLUE, Color.WHITE);
        scanBtn.addActionListener(e -> runScan());

        CustomDarkButton snapshotBtn = new CustomDarkButton("📸 Snapshot", ACCENT_PURPLE, Color.WHITE);
        snapshotBtn.addActionListener(e -> captureSnapshot());

        CustomDarkButton exportHtmlBtn = new CustomDarkButton("🌐 HTML", ACCENT_EMERALD, Color.WHITE);
        exportHtmlBtn.addActionListener(e -> exportHtmlReport());

        CustomDarkButton exportMdBtn = new CustomDarkButton("📝 Markdown", ACCENT_CYAN, Color.WHITE);
        exportMdBtn.addActionListener(e -> exportMarkdownReport());

        CustomDarkButton exportBundleBtn = new CustomDarkButton("📦 Export All Bundle", ACCENT_AMBER, Color.WHITE);
        exportBundleBtn.addActionListener(e -> exportAllBundle());

        controlBar.add(pathLbl);
        controlBar.add(pathField);
        controlBar.add(browseBtn);
        controlBar.add(scanBtn);
        controlBar.add(snapshotBtn);
        controlBar.add(exportHtmlBtn);
        controlBar.add(exportMdBtn);
        controlBar.add(exportBundleBtn);

        // 3. Stats Summary Cards Grid (8 Cards)
        JPanel statsPanel = new JPanel(new GridLayout(1, 8, 8, 0));
        statsPanel.setOpaque(false);
        statsPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        healthScoreLabel = createStatCard(statsPanel, "Codebase Health", "100% (A+)", ACCENT_EMERALD);
        debtLabel = createStatCard(statsPanel, "Tech Debt", "0.0h ($0)", ACCENT_PURPLE);
        totalMethodsLabel = createStatCard(statsPanel, "Total Methods", "0", ACCENT_CYAN);
        maxCompLabel = createStatCard(statsPanel, "Max Complexity", "0.0", ACCENT_RED);
        avgCompLabel = createStatCard(statsPanel, "Avg Complexity", "0.0", ACCENT_AMBER);
        treeHeightLabel = createStatCard(statsPanel, "AVL Tree Height", "0", ACCENT_EMERALD);
        totalRotationsLabel = createStatCard(statsPanel, "AVL Rotations", "0", ACCENT_PURPLE);
        criticalAlertsLabel = createStatCard(statsPanel, "Critical Alerts", "0", ACCENT_RED);

        JPanel topContainer = new JPanel(new BorderLayout());
        topContainer.setOpaque(false);
        topContainer.add(headerPanel, BorderLayout.NORTH);
        topContainer.add(controlBar, BorderLayout.CENTER);
        topContainer.add(statsPanel, BorderLayout.SOUTH);

        add(topContainer, BorderLayout.NORTH);

        // 4. Custom Dark Navigation Tab Bar & Card Container
        JPanel navTabBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 8));
        navTabBar.setBackground(BG_OBSIDIAN);
        navTabBar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK));

        tabButtons = new ArrayList<>();
        cardLayout = new CardLayout();
        cardContainer = new JPanel(cardLayout);
        cardContainer.setBackground(PANEL_SLATE);

        // Register View Cards
        executiveSummaryPanel = new ExecutiveSummaryPanel();
        addNavTab(navTabBar, "👔 Executive Summary", "EXEC", executiveSummaryPanel, true);
        addNavTab(navTabBar, "📋 Methods Index", "METHODS", createMethodsTablePanel(), false);
        addNavTab(navTabBar, "🌳 AVL Visualizer", "TREE", createVisualizerPanel(), false);
        securityMatrixPanel = new SecurityMatrixPanel();
        addNavTab(navTabBar, "🛡️ Security", "SECURITY", securityMatrixPanel, false);
        roiCalculatorPanel = new ROICalculatorPanel();
        addNavTab(navTabBar, "💰 ROI Calculator", "ROI", roiCalculatorPanel, false);
        roadmapTimelinePanel = new RoadmapTimelinePanel();
        addNavTab(navTabBar, "📅 Roadmap", "ROADMAP", roadmapTimelinePanel, false);
        patternAdvisorPanel = new DesignPatternAdvisorPanel();
        addNavTab(navTabBar, "💡 Patterns", "PATTERNS", patternAdvisorPanel, false);
        priorityMatrixPanel = new PriorityMatrixPanel();
        addNavTab(navTabBar, "🎯 Priority Matrix", "PRIORITY", priorityMatrixPanel, false);
        dsmPanel = new DSMPanel();
        addNavTab(navTabBar, "📊 DSM Grid", "DSM", dsmPanel, false);
        radarChartPanel = new RadarChartPanel();
        addNavTab(navTabBar, "🕸️ Radar Footprint", "RADAR", radarChartPanel, false);
        heatmapPanel = new HeatmapPanel();
        addNavTab(navTabBar, "🗺️ Heatmap Matrix", "HEATMAP", heatmapPanel, false);
        dependencyGraphPanel = new DependencyGraphPanel();
        addNavTab(navTabBar, "🕸️ Coupling Graph", "GRAPH", dependencyGraphPanel, false);
        leaderboardPanel = new LeaderboardPanel();
        addNavTab(navTabBar, "🏅 Leaderboard", "LEADERBOARD", leaderboardPanel, false);
        codeSmellMatrixPanel = new CodeSmellMatrixPanel();
        addNavTab(navTabBar, "🦨 Code Smells", "SMELLS", codeSmellMatrixPanel, false);
        codeViewerPanel = new CodeViewerPanel();
        addNavTab(navTabBar, "📄 Source Viewer", "CODE", codeViewerPanel, false);
        refactorAssistantPanel = new RefactorAssistantPanel();
        addNavTab(navTabBar, "🛠️ Refactor Assistant", "REFACTOR", refactorAssistantPanel, false);
        codeDiffViewerPanel = new CodeDiffViewerPanel();
        addNavTab(navTabBar, "🔍 Refactor Diff", "DIFF_VIEW", codeDiffViewerPanel, false);
        whatIfSimulatorPanel = new WhatIfSimulatorPanel();
        addNavTab(navTabBar, "🔮 What-If Simulator", "SIMULATOR", whatIfSimulatorPanel, false);
        cliShellPanel = new CLIShellPanel();
        addNavTab(navTabBar, "💻 CLI Shell", "SHELL", cliShellPanel, false);
        benchmarkPanel = new BenchmarkPanel();
        addNavTab(navTabBar, "⚡ Benchmark", "BENCHMARK", benchmarkPanel, false);
        versionDiffPanel = new VersionDiffPanel();
        addNavTab(navTabBar, "🔀 Version Diff", "DIFF", versionDiffPanel, false);
        qualityGatePanel = new QualityGatePanel();
        addNavTab(navTabBar, "🛡️ Quality Gate", "GATE", qualityGatePanel, false);
        milestonesPanel = new MilestonesPanel();
        addNavTab(navTabBar, "🏆 Milestones", "MILESTONES", milestonesPanel, false);
        addNavTab(navTabBar, "🚨 Live Alerts", "ALERTS", createAlertsPanel(), false);
        addNavTab(navTabBar, "🔍 Range Queries", "RANGE", createRangeQueryPanel(), false);
        trendCanvas = new TrendChartCanvas();
        addNavTab(navTabBar, "📈 Trend Graphs", "TRENDS", trendCanvas, false);
        avlPlaygroundPanel = new AVLPlaygroundPanel();
        addNavTab(navTabBar, "🎲 AVL Simulator", "SIM", avlPlaygroundPanel, false);
        diagnosticsPanel = new DiagnosticsPanel();
        addNavTab(navTabBar, "📊 Diagnostics", "DIAG", diagnosticsPanel, false);
        addNavTab(navTabBar, "🔄 Balance Logs", "LOGS", createRotationLogPanel(), false);

        JPanel centerContainer = new JPanel(new BorderLayout());
        centerContainer.setOpaque(false);
        centerContainer.add(navTabBar, BorderLayout.NORTH);
        centerContainer.add(cardContainer, BorderLayout.CENTER);

        add(centerContainer, BorderLayout.CENTER);

        // Auto-run initial scan
        SwingUtilities.invokeLater(this::runScan);
    }

    private void addNavTab(JPanel tabBar, String title, String cardKey, JPanel viewPanel, boolean isDefault) {
        cardContainer.add(viewPanel, cardKey);

        Color initBg = isDefault ? ACCENT_BLUE : CARD_NAVY;
        CustomDarkButton btn = new CustomDarkButton(title, initBg, TEXT_BRIGHT);

        btn.addActionListener(e -> switchTab(cardKey, btn));

        tabButtons.add(btn);
        tabBar.add(btn);
    }

    private void switchTab(String cardKey, CustomDarkButton activeBtn) {
        cardLayout.show(cardContainer, cardKey);
        for (CustomDarkButton b : tabButtons) {
            if (b == activeBtn) {
                b.setBackground(ACCENT_BLUE);
            } else {
                b.setBackground(CARD_NAVY);
            }
        }
    }

    private JPanel createVisualizerPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(PANEL_SLATE);

        JPanel zoomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
        zoomBar.setBackground(PANEL_SLATE);
        zoomBar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK));

        treeCanvas = new AVLTreeCanvas();

        CustomDarkButton zoomInBtn = new CustomDarkButton("🔍 Zoom +", CARD_NAVY, TEXT_BRIGHT);
        zoomInBtn.addActionListener(e -> treeCanvas.zoomIn());

        CustomDarkButton zoomOutBtn = new CustomDarkButton("🔍 Zoom -", CARD_NAVY, TEXT_BRIGHT);
        zoomOutBtn.addActionListener(e -> treeCanvas.zoomOut());

        CustomDarkButton resetZoomBtn = new CustomDarkButton("↺ Reset Scale", CARD_NAVY, TEXT_BRIGHT);
        resetZoomBtn.addActionListener(e -> treeCanvas.resetZoom());

        zoomBar.add(zoomInBtn);
        zoomBar.add(zoomOutBtn);
        zoomBar.add(resetZoomBtn);

        panel.add(zoomBar, BorderLayout.NORTH);
        panel.add(treeCanvas, BorderLayout.CENTER);
        return panel;
    }

    private JLabel createStatCard(JPanel container, String title, String initialVal, Color accent) {
        JPanel card = new JPanel(new BorderLayout(5, 5));
        card.setBackground(PANEL_SLATE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(3, 0, 0, 0, accent),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_DARK, 1),
                        BorderFactory.createEmptyBorder(10, 10, 10, 10)
                )
        ));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 10));
        titleLbl.setForeground(TEXT_MUTED);

        JLabel valLbl = new JLabel(initialVal);
        valLbl.setFont(new Font("Segoe UI", Font.BOLD, 15));
        valLbl.setForeground(accent);

        card.add(titleLbl, BorderLayout.NORTH);
        card.add(valLbl, BorderLayout.CENTER);
        container.add(card);

        return valLbl;
    }

    private JPanel createMethodsTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(PANEL_SLATE);

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        searchBar.setBackground(PANEL_SLATE);
        searchBar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK));

        JLabel searchLbl = new JLabel("🔍 Filter Methods / Classes / Smells:");
        searchLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        searchLbl.setForeground(TEXT_BRIGHT);

        searchField = new JTextField(25);
        searchField.setBackground(INPUT_DARK);
        searchField.setForeground(ACCENT_CYAN);
        searchField.setCaretColor(TEXT_BRIGHT);
        searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_DARK, 1),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));

        searchField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filterTable(); }
            public void removeUpdate(DocumentEvent e) { filterTable(); }
            public void changedUpdate(DocumentEvent e) { filterTable(); }
        });

        searchBar.add(searchLbl);
        searchBar.add(searchField);

        String[] cols = {"Method Name", "Class / File", "LOC", "CC", "Cog", "Nesting", "MI (100)", "Score", "Risk Level", "Code Smells"};
        methodsTableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        methodsTable = new JTable(methodsTableModel);
        applyDarkTableStyle(methodsTable);

        methodsTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = methodsTable.getSelectedRow();
                if (row != -1 && currentScanResult != null) {
                    List<MethodMetrics> sorted = getFilteredOrAllMethods();
                    if (row < sorted.size()) {
                        MethodMetrics m = sorted.get(row);
                        codeViewerPanel.loadAndHighlightMethod(m);
                        refactorAssistantPanel.loadRecipe(m);
                        codeDiffViewerPanel.loadDiff(m);
                        if (e.getClickCount() == 2) {
                            switchTab("CODE", tabButtons.get(14));
                        }
                    }
                }
            }
        });

        JScrollPane sp = new JScrollPane(methodsTable);
        sp.getViewport().setBackground(PANEL_SLATE);
        sp.setBorder(BorderFactory.createEmptyBorder());

        panel.add(searchBar, BorderLayout.NORTH);
        panel.add(sp, BorderLayout.CENTER);
        return panel;
    }

    private List<MethodMetrics> getFilteredOrAllMethods() {
        if (currentScanResult == null) return new ArrayList<>();
        List<MethodMetrics> all = currentScanResult.getAvlTree().inOrderTraversal();
        String query = searchField.getText().trim().toLowerCase();
        if (query.isEmpty()) return all;

        List<MethodMetrics> filtered = new ArrayList<>();
        for (MethodMetrics m : all) {
            if (m.getMethodName().toLowerCase().contains(query) ||
                m.getClassName().toLowerCase().contains(query) ||
                m.getRiskLevel().getLabel().toLowerCase().contains(query) ||
                m.getCodeSmellsFormatted().toLowerCase().contains(query)) {
                filtered.add(m);
            }
        }
        return filtered;
    }

    private void filterTable() {
        if (currentScanResult == null) return;
        List<MethodMetrics> filtered = getFilteredOrAllMethods();
        methodsTableModel.setRowCount(0);
        for (MethodMetrics m : filtered) {
            methodsTableModel.addRow(new Object[]{
                    m.getMethodName(),
                    m.getClassName(),
                    m.getLinesOfCode(),
                    m.getCyclomaticComplexity(),
                    m.getCognitiveComplexity(),
                    m.getMaxNestingDepth(),
                    m.getMaintainabilityIndex() + " / 100",
                    String.format("%.2f", m.getComplexityScore()),
                    m.getRiskLevel().getLabel(),
                    m.getCodeSmellsFormatted()
            });
        }
    }

    private JPanel createAlertsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(PANEL_SLATE);

        String[] cols = {"Severity", "Target Routine", "Issue Summary", "Actionable Refactoring Recommendation"};
        alertTableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        alertTable = new JTable(alertTableModel);
        applyDarkTableStyle(alertTable);

        alertTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = alertTable.getSelectedRow();
                if (row != -1 && currentScanResult != null) {
                    List<AlertManager.RefactorAlert> alerts = alertManager.evaluateMetrics(currentScanResult.getAllMethods());
                    if (row < alerts.size()) {
                        MethodMetrics m = alerts.get(row).getMetrics();
                        codeViewerPanel.loadAndHighlightMethod(m);
                        refactorAssistantPanel.loadRecipe(m);
                        codeDiffViewerPanel.loadDiff(m);
                        if (e.getClickCount() == 2) {
                            switchTab("REFACTOR", tabButtons.get(15));
                        }
                    }
                }
            }
        });

        JScrollPane sp = new JScrollPane(alertTable);
        sp.getViewport().setBackground(PANEL_SLATE);
        sp.setBorder(BorderFactory.createEmptyBorder());

        panel.add(sp, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createRangeQueryPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(PANEL_SLATE);

        JPanel filterBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        filterBar.setBackground(PANEL_SLATE);
        filterBar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK));

        JLabel minLbl = new JLabel("Min Complexity (X):");
        minLbl.setForeground(TEXT_BRIGHT);
        minLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        minRangeSpinner = new JSpinner(new SpinnerNumberModel(5.0, 0.0, 100.0, 1.0));
        applyDarkSpinnerStyle(minRangeSpinner);

        JLabel maxLbl = new JLabel("Max Complexity (Y):");
        maxLbl.setForeground(TEXT_BRIGHT);
        maxLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        maxRangeSpinner = new JSpinner(new SpinnerNumberModel(25.0, 0.0, 100.0, 1.0));
        applyDarkSpinnerStyle(maxRangeSpinner);

        CustomDarkButton execQueryBtn = new CustomDarkButton("🔎 Sweep Sub-tree Range (X ≤ Complexity ≤ Y)", ACCENT_EMERALD, Color.WHITE);
        execQueryBtn.addActionListener(e -> executeRangeQuery());

        filterBar.add(minLbl);
        filterBar.add(minRangeSpinner);
        filterBar.add(maxLbl);
        filterBar.add(maxRangeSpinner);
        filterBar.add(execQueryBtn);

        String[] cols = {"Method Name", "Class", "CC", "Cognitive", "Nesting", "Maintainability Index", "Complexity Score", "Risk Category"};
        rangeTableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        rangeTable = new JTable(rangeTableModel);
        applyDarkTableStyle(rangeTable);

        JScrollPane sp = new JScrollPane(rangeTable);
        sp.getViewport().setBackground(PANEL_SLATE);
        sp.setBorder(BorderFactory.createEmptyBorder());

        panel.add(filterBar, BorderLayout.NORTH);
        panel.add(sp, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createRotationLogPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(PANEL_SLATE);

        rotationLogArea = new JTextArea();
        rotationLogArea.setEditable(false);
        rotationLogArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        rotationLogArea.setBackground(BG_OBSIDIAN);
        rotationLogArea.setForeground(ACCENT_EMERALD);
        rotationLogArea.setMargin(new Insets(12, 12, 12, 12));

        JScrollPane sp = new JScrollPane(rotationLogArea);
        sp.getViewport().setBackground(BG_OBSIDIAN);
        sp.setBorder(BorderFactory.createEmptyBorder());

        panel.add(sp, BorderLayout.CENTER);
        return panel;
    }

    private void chooseDirectory() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        int option = fileChooser.showOpenDialog(this);
        if (option == JFileChooser.APPROVE_OPTION) {
            pathField.setText(fileChooser.getSelectedFile().getAbsolutePath());
        }
    }

    private void runScan() {
        String target = pathField.getText().trim();
        File file = new File(target);
        if (!file.exists()) {
            JOptionPane.showMessageDialog(this, "Target path does not exist: " + target, "Scan Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        currentScanResult = WorkspaceScanner.scanWorkspace(file);
        AVLTree<MethodMetrics> avlTree = currentScanResult.getAvlTree();
        List<MethodMetrics> sortedMethods = avlTree.inOrderTraversal();

        totalMethodsLabel.setText(String.valueOf(currentScanResult.getTotalMethodsCount()));
        treeHeightLabel.setText(String.valueOf(avlTree.getHeight()));
        totalRotationsLabel.setText(String.valueOf(avlTree.getTotalRotations()));

        List<AlertManager.RefactorAlert> alerts = alertManager.evaluateMetrics(currentScanResult.getAllMethods());
        int criticalCount = 0;
        for (AlertManager.RefactorAlert a : alerts) {
            if (a.getSeverity() == MethodMetrics.RiskLevel.CRITICAL) criticalCount++;
        }
        criticalAlertsLabel.setText(String.valueOf(criticalCount));

        TechnicalDebtEstimator.TechnicalDebtSummary debt = TechnicalDebtEstimator.calculateTechnicalDebt(currentScanResult.getAllMethods());
        debtLabel.setText(String.format("%.1fh ($%.0f)", debt.getTotalPersonHours(), debt.getEstimatedCostDollars()));

        if (!sortedMethods.isEmpty()) {
            MethodMetrics maxM = avlTree.getMaxNode().getDataList().get(0);
            maxCompLabel.setText(String.format("%.2f (%s)", maxM.getComplexityScore(), maxM.getMethodName()));

            double sum = 0;
            for (MethodMetrics m : sortedMethods) sum += m.getComplexityScore();
            double avg = sum / sortedMethods.size();
            avgCompLabel.setText(String.format("%.2f", avg));

            double health = Math.max(10.0, 100.0 - (criticalCount * 22.0) - (alerts.size() * 6.0) - (avg * 1.2));
            String grade = "A+";
            if (health < 50) grade = "F";
            else if (health < 65) grade = "D";
            else if (health < 75) grade = "C";
            else if (health < 88) grade = "B";
            else if (health < 95) grade = "A";

            healthScoreLabel.setText(String.format("%.0f%% (%s)", health, grade));
        } else {
            maxCompLabel.setText("0.0");
            avgCompLabel.setText("0.0");
            healthScoreLabel.setText("100% (A+)");
        }

        filterTable();

        alertTableModel.setRowCount(0);
        for (AlertManager.RefactorAlert a : alerts) {
            alertTableModel.addRow(new Object[]{
                    a.getSeverity().name(),
                    a.getMetrics().getClassName() + "." + a.getMetrics().getMethodName() + "()",
                    a.getIssueSummary(),
                    a.getRefactoringRecommendation()
            });
        }

        treeCanvas.setTree(avlTree);
        executiveSummaryPanel.updateSummary(currentScanResult, alerts);
        securityMatrixPanel.setMethods(sortedMethods);
        roiCalculatorPanel.setMethods(sortedMethods);
        roadmapTimelinePanel.setMethods(sortedMethods);
        patternAdvisorPanel.setMethods(sortedMethods);
        priorityMatrixPanel.setMethods(sortedMethods);
        dsmPanel.setMethods(sortedMethods);
        radarChartPanel.setMethods(sortedMethods);
        heatmapPanel.setMethods(sortedMethods);
        dependencyGraphPanel.setMethods(sortedMethods);
        leaderboardPanel.updateLeaderboard(sortedMethods);
        codeSmellMatrixPanel.updateSmells(sortedMethods);
        cliShellPanel.updateData(currentScanResult);
        benchmarkPanel.setMethods(sortedMethods);
        whatIfSimulatorPanel.updateData(currentScanResult);
        diagnosticsPanel.updateDiagnostics(currentScanResult);
        qualityGatePanel.updateData(currentScanResult, alerts);
        milestonesPanel.updateMilestones(currentScanResult, alerts);

        StringBuilder logs = new StringBuilder();
        logs.append("=== CODESENSE NATIVE AVL TREE SELF-BALANCING ROTATION LOGS ===\n\n");
        for (String log : avlTree.getRotationLogs()) {
            logs.append("▸ ").append(log).append("\n");
        }
        if (avlTree.getRotationLogs().isEmpty()) {
            logs.append("No rotations required. Tree remained naturally balanced during insertion stream.\n");
        }
        rotationLogArea.setText(logs.toString());

        snapshotManager.captureSnapshot("Scan (" + file.getName() + ")", avlTree, currentScanResult.getAllMethods());
        trendCanvas.setHistory(snapshotManager.getHistory());

        executeRangeQuery();

        if (!sortedMethods.isEmpty()) {
            codeViewerPanel.loadAndHighlightMethod(sortedMethods.get(0));
            refactorAssistantPanel.loadRecipe(sortedMethods.get(0));
            codeDiffViewerPanel.loadDiff(sortedMethods.get(0));
        }
    }

    private void executeRangeQuery() {
        if (currentScanResult == null) return;
        double min = ((Number) minRangeSpinner.getValue()).doubleValue();
        double max = ((Number) maxRangeSpinner.getValue()).doubleValue();

        List<MethodMetrics> rangeResults = currentScanResult.getAvlTree().rangeSearch(min, max);
        rangeTableModel.setRowCount(0);

        for (MethodMetrics m : rangeResults) {
            rangeTableModel.addRow(new Object[]{
                    m.getMethodName(),
                    m.getClassName(),
                    m.getCyclomaticComplexity(),
                    m.getCognitiveComplexity(),
                    m.getMaxNestingDepth(),
                    m.getMaintainabilityIndex(),
                    String.format("%.2f", m.getComplexityScore()),
                    m.getRiskLevel().getLabel()
            });
        }
    }

    private void captureSnapshot() {
        if (currentScanResult == null) return;
        snapshotManager.captureSnapshot("Manual Revision Snapshot", currentScanResult.getAvlTree(), currentScanResult.getAllMethods());
        trendCanvas.setHistory(snapshotManager.getHistory());
        JOptionPane.showMessageDialog(this, "Structural Tree Snapshot captured successfully!\n" +
                snapshotManager.generateTrajectorySummary(), "Snapshot Saved", JOptionPane.INFORMATION_MESSAGE);
    }

    private void exportHtmlReport() {
        if (currentScanResult == null) return;
        try {
            File outDir = new File("reports");
            List<AlertManager.RefactorAlert> alerts = alertManager.evaluateMetrics(currentScanResult.getAllMethods());
            File htmlFile = ReportExporter.exportHtmlReport(currentScanResult, alerts, outDir);
            JOptionPane.showMessageDialog(this, "HTML Report generated: " + htmlFile.getAbsolutePath(), "Export Complete", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Export Error: " + e.getMessage(), "Export Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exportMarkdownReport() {
        if (currentScanResult == null) return;
        try {
            File outDir = new File("reports");
            List<AlertManager.RefactorAlert> alerts = alertManager.evaluateMetrics(currentScanResult.getAllMethods());
            File mdFile = ReportExporter.exportMarkdownReport(currentScanResult, alerts, outDir);
            JOptionPane.showMessageDialog(this, "Markdown Report generated: " + mdFile.getAbsolutePath(), "Export Complete", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Export Error: " + e.getMessage(), "Export Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exportAllBundle() {
        if (currentScanResult == null) return;
        try {
            File outDir = new File("reports");
            List<AlertManager.RefactorAlert> alerts = alertManager.evaluateMetrics(currentScanResult.getAllMethods());

            File htmlFile = ReportExporter.exportHtmlReport(currentScanResult, alerts, outDir);
            File mdFile = ReportExporter.exportMarkdownReport(currentScanResult, alerts, outDir);
            File prFile = ReportExporter.exportPullRequestTemplate(currentScanResult, alerts, outDir);
            File sarifFile = ReportExporter.exportSarifReport(currentScanResult, alerts, outDir);
            File csvFile = ReportExporter.exportCsvMetrics(currentScanResult.getAllMethods(), outDir);
            File jsonFile = ReportExporter.exportJsonMetrics(currentScanResult, outDir);

            JOptionPane.showMessageDialog(this,
                    "All 6 Multi-Format Reports Generated Successfully!\n\n" +
                            "🌐 HTML Report:  " + htmlFile.getName() + "\n" +
                            "📝 Markdown Doc:  " + mdFile.getName() + "\n" +
                            "🛠️ PR Template:   " + prFile.getName() + "\n" +
                            "🛡️ SARIF Report:  " + sarifFile.getName() + "\n" +
                            "📊 CSV Metrics:   " + csvFile.getName() + "\n" +
                            "📦 JSON Data:     " + jsonFile.getName() + "\n\n" +
                            "Saved in: " + outDir.getAbsolutePath(),
                    "Export Bundle Complete", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Export Error: " + e.getMessage(), "Export Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
