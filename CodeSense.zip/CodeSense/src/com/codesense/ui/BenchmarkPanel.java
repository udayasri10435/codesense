package com.codesense.ui;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.ds.AVLTree;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static com.codesense.ui.DarkThemeUtils.*;

/**
 * Empirical Benchmark & Algorithm Performance Profiler.
 * Tests $O(\log N)$ AVL tree operations vs linear search under high dataset loads.
 */
public class BenchmarkPanel extends JPanel {

    private final JTextArea resultsArea;
    private List<MethodMetrics> currentMethods;

    public BenchmarkPanel() {
        setLayout(new BorderLayout());
        setBackground(PANEL_SLATE);

        // Header
        JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        header.setBackground(CARD_NAVY);
        header.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_DARK),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));

        JLabel title = new JLabel("⚡ Empirical Algorithm Benchmark & Performance Profiler:");
        title.setFont(new Font("Segoe UI", Font.BOLD, 12));
        title.setForeground(ACCENT_CYAN);

        CustomDarkButton runBenchBtn = new CustomDarkButton("🚀 Run Live Speed Benchmark (100,000 Ops)", ACCENT_EMERALD, Color.WHITE);
        runBenchBtn.addActionListener(e -> runBenchmark());

        header.add(title);
        header.add(runBenchBtn);

        add(header, BorderLayout.NORTH);

        // Benchmark Log Area
        resultsArea = new JTextArea();
        resultsArea.setEditable(false);
        resultsArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        resultsArea.setBackground(BG_OBSIDIAN);
        resultsArea.setForeground(ACCENT_CYAN);
        resultsArea.setMargin(new Insets(14, 14, 14, 14));

        resultsArea.setText("=== CODESENSE EMPIRICAL BENCHMARK ENGINE ===\n\nClick 'Run Live Speed Benchmark' to evaluate O(log N) AVL Tree operations vs O(N) Linear Scans.\n");

        JScrollPane sp = new JScrollPane(resultsArea);
        sp.getViewport().setBackground(BG_OBSIDIAN);
        sp.setBorder(BorderFactory.createEmptyBorder());

        add(sp, BorderLayout.CENTER);
    }

    public void setMethods(List<MethodMetrics> methods) {
        this.currentMethods = methods;
    }

    private void runBenchmark() {
        StringBuilder sb = new StringBuilder();
        sb.append("=========================================================================\n");
        sb.append("  CODESENSE NATIVE AVL TREE VS LINEAR SEARCH PERFORMANCE BENCHMARK        \n");
        sb.append("=========================================================================\n\n");

        int N = 50000;
        sb.append("▸ Generating dataset with N = ").append(N).append(" synthetic routine metrics...\n");

        AVLTree<MethodMetrics> avlTree = new AVLTree<>();
        List<MethodMetrics> list = new ArrayList<>();

        long t0 = System.nanoTime();
        for (int i = 0; i < N; i++) {
            MethodMetrics m = new MethodMetrics("method_" + i, "BenchmarkClass", "path/File.java", 1, 20, 5, 2, 1, 20, 2);
            avlTree.insert(m.getComplexityScore(), m);
            list.add(m);
        }
        long t1 = System.nanoTime();
        double insertMs = (t1 - t0) / 1e6;

        sb.append("✓ AVL Tree Bulk Insertion Time (N=").append(N).append("): ").append(String.format("%.2f", insertMs)).append(" ms\n");
        sb.append("✓ Measured Tree Height: ").append(avlTree.getHeight()).append(" (Theoretical Optimal: ").append((int)Math.ceil(Math.log(N)/Math.log(2))).append(")\n\n");

        // Benchmark 1: Search Speed
        int lookups = 100000;
        sb.append("▸ Running ").append(lookups).append(" Key Lookups (O(log N) AVL Tree vs O(N) Unsorted List Search)...\n");

        t0 = System.nanoTime();
        for (int i = 0; i < lookups; i++) {
            double key = (i % 100) + 1.0;
            avlTree.searchNode(key);
        }
        t1 = System.nanoTime();
        double avlSearchMs = (t1 - t0) / 1e6;

        t0 = System.nanoTime();
        for (int i = 0; i < lookups; i++) {
            double key = (i % 100) + 1.0;
            for (MethodMetrics m : list) {
                if (Math.abs(m.getComplexityScore() - key) < 1e-4) break;
            }
        }
        t1 = System.nanoTime();
        double linearSearchMs = (t1 - t0) / 1e6;

        sb.append("  ⚡ AVL Tree O(log N) Search Time:   ").append(String.format("%.2f", avlSearchMs)).append(" ms\n");
        sb.append("  🐢 Linear Array O(N) Search Time:   ").append(String.format("%.2f", linearSearchMs)).append(" ms\n");
        sb.append("  🚀 SPEEDUP FACTOR: ").append(String.format("%.1fx FASTER", linearSearchMs / Math.max(0.1, avlSearchMs))).append("\n\n");

        // Benchmark 2: Sub-tree Range Sweep Speed
        sb.append("▸ Sweeping Sub-tree Range Queries [10.0 <= Score <= 30.0] (O(K + log N))...\n");
        t0 = System.nanoTime();
        for (int i = 0; i < 5000; i++) {
            avlTree.rangeSearch(10.0, 30.0);
        }
        t1 = System.nanoTime();
        double rangeMs = (t1 - t0) / 1e6;

        sb.append("  ⚡ 5,000 Range Sweep Queries Executed In: ").append(String.format("%.2f", rangeMs)).append(" ms\n\n");
        sb.append("=========================================================================\n");
        sb.append("  BENCHMARK COMPLETED: AVL TREE ENGINE CERTIFIED FOR ENTERPRISE DEPLOYMENT \n");
        sb.append("=========================================================================\n");

        resultsArea.setText(sb.toString());
    }
}
