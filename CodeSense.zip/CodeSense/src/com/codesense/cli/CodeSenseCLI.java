package com.codesense.cli;

import com.codesense.analyzer.MethodMetrics;
import com.codesense.analyzer.WorkspaceScanner;
import com.codesense.ds.AVLTree;
import com.codesense.features.AlertManager;
import com.codesense.features.SnapshotManager;

import java.io.File;
import java.util.List;
import java.util.Scanner;

/**
 * Optimized CLI Control Panel for CodeSense.
 * Provides interactive command-line access to AST scanning, AVL tree sweeps,
 * logarithmic range queries, live alerts, and benchmark evaluations.
 */
public class CodeSenseCLI {

    private WorkspaceScanner.ScanResult lastScan;
    private final AlertManager alertManager;
    private final SnapshotManager snapshotManager;

    public CodeSenseCLI() {
        this.alertManager = new AlertManager();
        this.snapshotManager = new SnapshotManager();
    }

    public void startInteractiveShell() {
        printBanner();
        Scanner scanner = new Scanner(System.in);

        File samples = new File("samples");
        if (samples.exists()) {
            executeScan(samples.getAbsolutePath());
        }

        while (true) {
            System.out.print("\nCodeSense> ");
            String input = scanner.nextLine().trim();
            if (input.isEmpty()) continue;

            String[] parts = input.split("\\s+");
            String cmd = parts[0].toLowerCase();

            switch (cmd) {
                case "scan":
                    if (parts.length < 2) {
                        System.out.println("Usage: scan <path-to-folder-or-file>");
                    } else {
                        executeScan(parts[1]);
                    }
                    break;
                case "list":
                    displayList();
                    break;
                case "range":
                    if (parts.length < 3) {
                        System.out.println("Usage: range <minScore> <maxScore>");
                    } else {
                        try {
                            double min = Double.parseDouble(parts[1]);
                            double max = Double.parseDouble(parts[2]);
                            executeRange(min, max);
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid numeric range format.");
                        }
                    }
                    break;
                case "alerts":
                    displayAlerts();
                    break;
                case "snapshot":
                    captureSnapshot();
                    break;
                case "benchmark":
                    runBenchmark();
                    break;
                case "help":
                    printHelp();
                    break;
                case "exit":
                case "quit":
                    System.out.println("Exiting CodeSense CLI. Goodbye!");
                    return;
                default:
                    System.out.println("Unknown command: '" + cmd + "'. Type 'help' for options.");
            }
        }
    }

    private void printBanner() {
        System.out.println("=========================================================================");
        System.out.println("   CodeSense - Smart Code Complexity Analyzer Using Custom AVL Trees     ");
        System.out.println("   PDSA Assignment Project | Zero 3rd-Party Tree Collection Engine       ");
        System.out.println("=========================================================================");
        System.out.println("Type 'help' to see all interactive developer control commands.");
    }

    private void printHelp() {
        System.out.println("\nAvailable Control Commands:");
        System.out.println("  scan <path>        - Run AST parser & build AVL Tree index for target path");
        System.out.println("  list               - Print sorted method complexity roadmap (In-order sweep)");
        System.out.println("  range <min> <max>  - Execute logarithmic AVL range query (X <= Complexity <= Y)");
        System.out.println("  alerts             - Generate Live Refactor Alerts for high-weight routines");
        System.out.println("  snapshot           - Record revision snapshot and display quality trajectory");
        System.out.println("  benchmark          - Compare AVL Tree O(log n) performance vs Linear Search");
        System.out.println("  help               - Print command menu");
        System.out.println("  exit               - Exit application");
    }

    private void executeScan(String pathStr) {
        File file = new File(pathStr);
        if (!file.exists()) {
            System.out.println("Error: Path does not exist -> " + pathStr);
            return;
        }

        System.out.println("Initiating AST Routine Sweep on: " + file.getAbsolutePath());
        lastScan = WorkspaceScanner.scanWorkspace(file);
        AVLTree<MethodMetrics> tree = lastScan.getAvlTree();

        System.out.printf("Scan Complete in %d ms!\n", lastScan.getElapsedTimeMs());
        System.out.printf(" - Scanned Files: %d\n", lastScan.getScannedFilesCount());
        System.out.printf(" - Total Methods Indexed: %d\n", lastScan.getTotalMethodsCount());
        System.out.printf(" - AVL Tree Height: %d (Rotations Performed: %d)\n", tree.getHeight(), tree.getTotalRotations());

        snapshotManager.captureSnapshot("CLI Scan (" + file.getName() + ")", tree, lastScan.getAllMethods());
    }

    private void displayList() {
        if (lastScan == null) {
            System.out.println("No active scan index found. Run 'scan <path>' first.");
            return;
        }

        List<MethodMetrics> sorted = lastScan.getAvlTree().inOrderTraversal();
        System.out.println("\n--- AVL In-Order Method Complexity Roadmap ---");
        System.out.printf("%-30s %-20s %-8s %-5s %-5s %-5s %-8s %-15s\n", "Method Target", "Class", "Score", "CC", "Cog", "MND", "MI", "Risk Level");
        System.out.println("--------------------------------------------------------------------------------------------------");

        for (MethodMetrics m : sorted) {
            System.out.printf("%-30s %-20s %-8.2f %-5d %-5d %-5d %-8.1f %-15s\n",
                    m.getMethodName() + "()",
                    m.getClassName(),
                    m.getComplexityScore(),
                    m.getCyclomaticComplexity(),
                    m.getCognitiveComplexity(),
                    m.getMaxNestingDepth(),
                    m.getMaintainabilityIndex(),
                    m.getRiskLevel().getLabel());
        }
    }

    private void executeRange(double min, double max) {
        if (lastScan == null) {
            System.out.println("No active scan index found. Run 'scan <path>' first.");
            return;
        }

        System.out.printf("\n--- Logarithmic AVL Sub-tree Range Query [%.1f <= Score <= %.1f] ---\n", min, max);
        long start = System.nanoTime();
        List<MethodMetrics> matches = lastScan.getAvlTree().rangeSearch(min, max);
        long elapsedNs = System.nanoTime() - start;

        System.out.printf("Query Executed in %d ns (%d matches found):\n", elapsedNs, matches.size());
        for (MethodMetrics m : matches) {
            System.out.printf(" -> %s.%s() | Score=%.2f | CC=%d | Cog=%d | MND=%d | MI=%.1f\n",
                    m.getClassName(), m.getMethodName(), m.getComplexityScore(),
                    m.getCyclomaticComplexity(), m.getCognitiveComplexity(),
                    m.getMaxNestingDepth(), m.getMaintainabilityIndex());
        }
    }

    private void displayAlerts() {
        if (lastScan == null) {
            System.out.println("No active scan index found. Run 'scan <path>' first.");
            return;
        }

        List<AlertManager.RefactorAlert> alerts = alertManager.evaluateMetrics(lastScan.getAllMethods());
        System.out.println("\n--- Live Refactor Alerts ---");
        if (alerts.isEmpty()) {
            System.out.println("All methods operate within design thresholds! No critical alerts.");
            return;
        }

        for (AlertManager.RefactorAlert a : alerts) {
            System.out.println(a);
        }
    }

    private void captureSnapshot() {
        if (lastScan == null) {
            System.out.println("No active scan index found. Run 'scan <path>' first.");
            return;
        }

        snapshotManager.captureSnapshot("Manual Snapshot", lastScan.getAvlTree(), lastScan.getAllMethods());
        System.out.println(snapshotManager.generateTrajectorySummary());
    }

    private void runBenchmark() {
        System.out.println("\n--- Benchmarking AVL Tree O(log n) vs Standard Linear Array Search ---");
        int numEntries = 50000;
        System.out.printf("Generating %d synthetic routine metric nodes...\n", numEntries);

        AVLTree<MethodMetrics> benchmarkTree = new AVLTree<>();
        java.util.List<MethodMetrics> linearList = new java.util.ArrayList<>();

        for (int i = 0; i < numEntries; i++) {
            double score = Math.random() * 100.0;
            MethodMetrics m = new MethodMetrics("routine" + i, "BenchmarkClass", "dummy.java", 1, 10, 5, 4, 2, 20, 1);
            benchmarkTree.insert(score, m);
            linearList.add(m);
        }

        double searchTarget = 42.5;

        long startAvl = System.nanoTime();
        List<MethodMetrics> avlResult = benchmarkTree.rangeSearch(searchTarget - 0.5, searchTarget + 0.5);
        long avlNs = System.nanoTime() - startAvl;

        long startLinear = System.nanoTime();
        List<MethodMetrics> linearResult = new java.util.ArrayList<>();
        for (MethodMetrics m : linearList) {
            if (m.getComplexityScore() >= (searchTarget - 0.5) && m.getComplexityScore() <= (searchTarget + 0.5)) {
                linearResult.add(m);
            }
        }
        long linearNs = System.nanoTime() - startLinear;

        System.out.printf("Result: AVL Range Query = %d ns | Linear Search = %d ns\n", avlNs, linearNs);
        System.out.printf("Speedup Factor: %.2fx faster lookup with native AVL Tree structure!\n", (double) linearNs / Math.max(1, avlNs));
    }
}
