package com.codesense.analyzer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Multi-Language AST & Routine Parser supporting Java, C/C++, JS/TS, and Python files.
 */
public class CodeParser {

    private static final Pattern JAVA_METHOD_PATTERN = Pattern.compile(
            "(?:public|protected|private|static|final|native|synchronized|abstract|default|\\s)+\\s+([\\w<>\\[\\]]+)\\s+([a-zA-Z_][a-zA-Z0-9_]*)\\s*\\(([^)]*)\\)\\s*(?:throws [^{]+)?\\{"
    );

    private static final Pattern JS_FUNCTION_PATTERN = Pattern.compile(
            "(?:function|const|let|var|async)\\s+([a-zA-Z_][a-zA-Z0-9_]*)\\s*=\\s*(?:async\\s*)?\\(([^)]*)\\)\\s*=>|function\\s+([a-zA-Z_][a-zA-Z0-9_]*)\\s*\\(([^)]*)\\)"
    );

    private static final Pattern PYTHON_DEF_PATTERN = Pattern.compile(
            "^\\s*def\\s+([a-zA-Z_][a-zA-Z0-9_]*)\\s*\\(([^)]*)\\)\\s*:"
    );

    private static final Pattern DECISION_PATTERN = Pattern.compile(
            "\\b(if|else\\s+if|elif|for|while|do|case|catch|except)\\b|&&|\\|\\||\\b(and|or)\\b|\\?"
    );

    private static final Pattern COGNITIVE_BREAK_PATTERN = Pattern.compile(
            "\\b(if|else\\s+if|elif|for|while|do|catch|except|switch|break|continue)\\b"
    );

    public static List<MethodMetrics> parseFile(File file) throws IOException {
        List<MethodMetrics> metricsList = new ArrayList<>();
        if (!file.exists() || !file.isFile()) {
            return metricsList;
        }

        String name = file.getName().toLowerCase();
        if (name.endsWith(".py")) {
            return parsePythonFile(file);
        } else if (name.endsWith(".java") || name.endsWith(".js") || name.endsWith(".ts") || name.endsWith(".c") || name.endsWith(".cpp") || name.endsWith(".h")) {
            return parseCStyleFile(file);
        }

        return metricsList;
    }

    private static List<MethodMetrics> parseCStyleFile(File file) throws IOException {
        List<MethodMetrics> metricsList = new ArrayList<>();
        List<String> lines = readLines(file);
        String className = file.getName().substring(0, file.getName().lastIndexOf('.'));

        for (int i = 0; i < lines.size(); i++) {
            String rawLine = lines.get(i);
            String trimmed = stripCommentsAndStrings(rawLine).trim();

            Matcher matcher = JAVA_METHOD_PATTERN.matcher(trimmed);
            String methodName = null;
            String paramsStr = null;

            if (matcher.find()) {
                methodName = matcher.group(2);
                paramsStr = matcher.group(3);
            } else {
                Matcher jsMatcher = JS_FUNCTION_PATTERN.matcher(trimmed);
                if (jsMatcher.find()) {
                    methodName = jsMatcher.group(1) != null ? jsMatcher.group(1) : jsMatcher.group(3);
                    paramsStr = jsMatcher.group(2) != null ? jsMatcher.group(2) : jsMatcher.group(4);
                }
            }

            if (methodName != null) {
                int startLine = i + 1;
                int paramCount = parseParamCount(paramsStr);

                MethodAnalysisResult result = analyzeCStyleBody(lines, i);
                int endLine = result.endLine;
                int loc = Math.max(1, endLine - startLine + 1);

                metricsList.add(new MethodMetrics(
                        methodName, className, file.getAbsolutePath(),
                        startLine, endLine, result.cyclomaticComplexity,
                        result.cognitiveComplexity, result.maxNestingDepth, loc, paramCount
                ));

                i = Math.max(i, endLine - 1);
            }
        }
        return metricsList;
    }

    private static List<MethodMetrics> parsePythonFile(File file) throws IOException {
        List<MethodMetrics> metricsList = new ArrayList<>();
        List<String> lines = readLines(file);
        String className = file.getName().replace(".py", "");

        for (int i = 0; i < lines.size(); i++) {
            String raw = lines.get(i);
            Matcher matcher = PYTHON_DEF_PATTERN.matcher(raw);
            if (matcher.find()) {
                String methodName = matcher.group(1);
                String paramsStr = matcher.group(2);
                int startLine = i + 1;
                int paramCount = parseParamCount(paramsStr);

                int defIndent = getIndentLevel(raw);
                int endLine = startLine;
                int decisionForks = 0;
                int cognitiveScore = 0;
                int maxNesting = 1;

                for (int j = i + 1; j < lines.size(); j++) {
                    String sub = lines.get(j);
                    if (sub.trim().isEmpty() || sub.trim().startsWith("#")) continue;

                    int subIndent = getIndentLevel(sub);
                    if (subIndent <= defIndent && !sub.trim().startsWith("def ")) {
                        endLine = j;
                        break;
                    }
                    endLine = j + 1;

                    int nesting = Math.max(1, (subIndent - defIndent) / 4);
                    if (nesting > maxNesting) maxNesting = nesting;

                    Matcher decM = DECISION_PATTERN.matcher(sub);
                    while (decM.find()) decisionForks++;

                    Matcher cogM = COGNITIVE_BREAK_PATTERN.matcher(sub);
                    while (cogM.find()) cognitiveScore += (1 + nesting);
                }

                int loc = Math.max(1, endLine - startLine + 1);
                int cc = 1 + decisionForks;
                int cog = Math.max(1, cognitiveScore);

                metricsList.add(new MethodMetrics(
                        methodName, className, file.getAbsolutePath(),
                        startLine, endLine, cc, cog, maxNesting, loc, paramCount
                ));

                i = Math.max(i, endLine - 1);
            }
        }
        return metricsList;
    }

    private static int getIndentLevel(String line) {
        int count = 0;
        for (char c : line.toCharArray()) {
            if (c == ' ') count++;
            else if (c == '\t') count += 4;
            else break;
        }
        return count;
    }

    private static List<String> readLines(File file) throws IOException {
        List<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) lines.add(line);
        }
        return lines;
    }

    private static int parseParamCount(String paramsStr) {
        if (paramsStr == null || paramsStr.trim().isEmpty()) return 0;
        return paramsStr.split(",").length;
    }

    private static class MethodAnalysisResult {
        int endLine;
        int cyclomaticComplexity;
        int cognitiveComplexity;
        int maxNestingDepth;

        MethodAnalysisResult(int endLine, int cyclomaticComplexity, int cognitiveComplexity, int maxNestingDepth) {
            this.endLine = endLine;
            this.cyclomaticComplexity = cyclomaticComplexity;
            this.cognitiveComplexity = cognitiveComplexity;
            this.maxNestingDepth = maxNestingDepth;
        }
    }

    private static MethodAnalysisResult analyzeCStyleBody(List<String> lines, int startLineIdx) {
        int braceDepth = 0;
        int maxDepth = 0;
        int decisionForks = 0;
        int cognitiveScore = 0;
        boolean started = false;
        int endLine = startLineIdx + 1;

        for (int i = startLineIdx; i < lines.size(); i++) {
            String line = stripCommentsAndStrings(lines.get(i));

            Matcher decMatcher = DECISION_PATTERN.matcher(line);
            while (decMatcher.find()) {
                decisionForks++;
            }

            Matcher cogMatcher = COGNITIVE_BREAK_PATTERN.matcher(line);
            while (cogMatcher.find()) {
                cognitiveScore += (1 + Math.max(0, braceDepth - 1));
            }

            for (char c : line.toCharArray()) {
                if (c == '{') {
                    braceDepth++;
                    started = true;
                    if (braceDepth > maxDepth) {
                        maxDepth = braceDepth;
                    }
                } else if (c == '}') {
                    braceDepth--;
                    if (started && braceDepth == 0) {
                        endLine = i + 1;
                        int cc = 1 + decisionForks;
                        int cog = Math.max(1, cognitiveScore);
                        int netNesting = Math.max(1, maxDepth - 1);
                        return new MethodAnalysisResult(endLine, cc, cog, netNesting);
                    }
                }
            }
        }

        int cc = 1 + decisionForks;
        int cog = Math.max(1, cognitiveScore);
        int netNesting = Math.max(1, maxDepth - 1);
        return new MethodAnalysisResult(lines.size(), cc, cog, netNesting);
    }

    private static String stripCommentsAndStrings(String code) {
        if (code == null) return "";
        int commentIdx = code.indexOf("//");
        if (commentIdx != -1) {
            code = code.substring(0, commentIdx);
        }
        return code.replaceAll("\"(\\\\\"|[^\"])*\"", "\"\"");
    }
}
