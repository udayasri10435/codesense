package com.codesense.analyzer;

import com.codesense.ds.AVLTree;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Workspace package scanner supporting Java, Python, JS/TS, and C/C++ source files.
 */
public class WorkspaceScanner {

    public static class ScanResult {
        private final AVLTree<MethodMetrics> avlTree;
        private final int scannedFilesCount;
        private final int totalMethodsCount;
        private final long totalLinesOfCode;
        private final long elapsedTimeMs;
        private final List<MethodMetrics> allMethods;

        public ScanResult(AVLTree<MethodMetrics> avlTree, int scannedFilesCount,
                          int totalMethodsCount, long totalLinesOfCode,
                          long elapsedTimeMs, List<MethodMetrics> allMethods) {
            this.avlTree = avlTree;
            this.scannedFilesCount = scannedFilesCount;
            this.totalMethodsCount = totalMethodsCount;
            this.totalLinesOfCode = totalLinesOfCode;
            this.elapsedTimeMs = elapsedTimeMs;
            this.allMethods = allMethods;
        }

        public AVLTree<MethodMetrics> getAvlTree() {
            return avlTree;
        }

        public int getScannedFilesCount() {
            return scannedFilesCount;
        }

        public int getTotalMethodsCount() {
            return totalMethodsCount;
        }

        public long getTotalLinesOfCode() {
            return totalLinesOfCode;
        }

        public long getElapsedTimeMs() {
            return elapsedTimeMs;
        }

        public List<MethodMetrics> getAllMethods() {
            return allMethods;
        }
    }

    public static ScanResult scanWorkspace(File targetPath) {
        long startTime = System.currentTimeMillis();
        AVLTree<MethodMetrics> tree = new AVLTree<>();
        List<File> sourceFiles = new ArrayList<>();
        List<MethodMetrics> allMethods = new ArrayList<>();

        collectSourceFiles(targetPath, sourceFiles);

        long totalLoc = 0;
        for (File file : sourceFiles) {
            try {
                List<MethodMetrics> methods = CodeParser.parseFile(file);
                for (MethodMetrics m : methods) {
                    tree.insert(m.getComplexityScore(), m);
                    allMethods.add(m);
                    totalLoc += m.getLinesOfCode();
                }
            } catch (IOException e) {
                System.err.println("Error parsing file " + file.getAbsolutePath() + ": " + e.getMessage());
            }
        }

        long elapsedTime = System.currentTimeMillis() - startTime;
        return new ScanResult(tree, sourceFiles.size(), allMethods.size(), totalLoc, elapsedTime, allMethods);
    }

    private static void collectSourceFiles(File file, List<File> accumulator) {
        if (file == null || !file.exists()) return;

        if (file.isFile()) {
            String name = file.getName().toLowerCase();
            if (name.endsWith(".java") || name.endsWith(".py") || name.endsWith(".js") ||
                name.endsWith(".ts") || name.endsWith(".c") || name.endsWith(".cpp") || name.endsWith(".h")) {
                accumulator.add(file);
            }
        } else if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    collectSourceFiles(child, accumulator);
                }
            }
        }
    }
}
