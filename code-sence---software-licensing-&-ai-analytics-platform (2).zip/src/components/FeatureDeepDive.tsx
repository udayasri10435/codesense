import React, { useState } from 'react';
import { Sparkles, GitBranch, Shield, GraduationCap, ArrowRight, CheckCircle2, Zap, Lock, Terminal, Cpu } from 'lucide-react';

interface FeatureDeepDiveProps {
  onOpenCheckout: (planId?: string) => void;
}

export const FeatureDeepDive: React.FC<FeatureDeepDiveProps> = ({ onOpenCheckout }) => {
  const [activeTab, setActiveTab] = useState<'pro' | 'team' | 'enterprise' | 'education'>('pro');

  return (
    <section id="features-deepdive" className="py-16 bg-white border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 space-y-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold uppercase tracking-wider">
            <Cpu className="w-3.5 h-3.5" />
            <span>Architecture & Feature Specifications</span>
          </div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            Engineered for Modern Engineering Workflows
          </h2>
          <p className="text-slate-600 text-sm max-w-2xl mx-auto">
            Explore the advanced architectural capabilities unlocked across each CodeSense serial license tier.
          </p>
        </div>

        {/* Feature Tab Navigation */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          <button
            onClick={() => setActiveTab('pro')}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'pro'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            <Sparkles className="w-4 h-4 text-indigo-200" />
            <span>PRO: Debt & Refactoring Simulator</span>
          </button>

          <button
            onClick={() => setActiveTab('team')}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'team'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            <GitBranch className="w-4 h-4 text-indigo-200" />
            <span>TEAM: CI/CD & Quality Policies</span>
          </button>

          <button
            onClick={() => setActiveTab('enterprise')}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'enterprise'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            <Shield className="w-4 h-4 text-indigo-200" />
            <span>ENTERPRISE: RBAC & Audit Trails</span>
          </button>

          <button
            onClick={() => setActiveTab('education')}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'education'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            <GraduationCap className="w-4 h-4 text-indigo-200" />
            <span>EDUCATION: Academic Hub & Grading</span>
          </button>
        </div>

        {/* Tab 1: Pro Details */}
        {activeTab === 'pro' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-slate-50 p-8 rounded-3xl border border-slate-200 shadow-sm">
            <div className="lg:col-span-6 space-y-4">
              <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">For Senior & Staff Engineers</span>
              <h3 className="text-2xl font-extrabold text-slate-900">Technical Debt Engine & Refactoring Simulator</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                CodeSense PRO calculates accurate technical debt metrics in engineer hours and financial remediation costs. The interactive Refactoring Simulator analyzes high-complexity methods and auto-generates decomposed Design Pattern rewrites.
              </p>
              <ul className="space-y-2 text-xs text-slate-700">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                  <span>Maximum 20 projects and 1,000 deep analyses / month</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                  <span>Full REST API and CLI machine licensing</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                  <span>Interactive before/after code diff generator</span>
                </li>
              </ul>
              <div className="pt-2">
                <button
                  onClick={() => onOpenCheckout('pro')}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-sm transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <span>Get Pro Serial Key ($29)</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-6 bg-slate-900 p-5 rounded-2xl border border-slate-800 font-mono text-xs text-slate-300 space-y-3 shadow-md">
              <div className="text-indigo-400 font-bold">// Refactoring Simulation Output:</div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                <div className="text-slate-400">Method: OrderProcessor.executeTransaction()</div>
                <div className="text-amber-400">Complexity: 24 (Critical) ➔ Strategy Pattern (Score 4)</div>
                <div className="text-emerald-400 font-bold">Estimated Debt Saved: 4.8 Hours</div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Team Details */}
        {activeTab === 'team' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-slate-50 p-8 rounded-3xl border border-slate-200 shadow-sm">
            <div className="lg:col-span-6 space-y-4">
              <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">For Agile Teams & Squads</span>
              <h3 className="text-2xl font-extrabold text-slate-900">Centralized Organization Hub & CI/CD Gates</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Connect your engineering team to synchronized quality policies. Automatically block Pull Requests that exceed technical debt ceilings or introduce untested architectural hotspots.
              </p>
              <ul className="space-y-2 text-xs text-slate-700">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Maximum 50 projects and 5,000 analyses / month</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>10 Team Member seats and CI/CD Runner tokens</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>GitHub Actions & GitLab CI quality policy blocker</span>
                </li>
              </ul>
              <div className="pt-2">
                <button
                  onClick={() => onOpenCheckout('team')}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-sm transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <span>Get Team Serial Key ($99)</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-6 bg-slate-900 p-5 rounded-2xl border border-slate-800 font-mono text-xs text-slate-300 space-y-3 shadow-md">
              <div className="text-emerald-400 font-bold">// GitHub Actions CI/CD Pipeline Gate:</div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                <div className="text-slate-400">PR #412: feat/checkout-redesign</div>
                <div className="text-emerald-400">✓ Security CWE Scan: 0 issues</div>
                <div className="text-emerald-400">✓ Duplication: 2.1% (&lt; 5% limit)</div>
                <div className="text-emerald-300 font-bold">STATUS: CI QUALITY GATE APPROVED</div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Enterprise Details */}
        {activeTab === 'enterprise' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-slate-50 p-8 rounded-3xl border border-slate-200 shadow-sm">
            <div className="lg:col-span-6 space-y-4">
              <span className="text-xs font-bold text-purple-600 uppercase tracking-wider">For Large Orgs & Compliance</span>
              <h3 className="text-2xl font-extrabold text-slate-900">Enterprise RBAC, SAML SSO & Audit Logs</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Unlimited scale with SOC2 & ISO compliant audit logs, customizable security policies, Okta/Azure AD SSO, air-gapped on-prem offline licensing keys, and 24/7 dedicated support.
              </p>
              <ul className="space-y-2 text-xs text-slate-700">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600" />
                  <span>Unlimited projects & unlimited monthly analyses</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600" />
                  <span>Granular Role-Based Access Control (RBAC) & Audit logs</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600" />
                  <span>Offline air-gapped serial certificates & dedicated SLA</span>
                </li>
              </ul>
              <div className="pt-2">
                <button
                  onClick={() => onOpenCheckout('enterprise')}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-sm transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <span>Get Enterprise Key ($299)</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-6 bg-slate-900 p-5 rounded-2xl border border-slate-800 font-mono text-xs text-slate-300 space-y-3 shadow-md">
              <div className="text-purple-400 font-bold">// Enterprise Governance & Audit Stream:</div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                <div className="text-slate-400">Auth: SAML 2.0 via Okta Directory (IDP_OKTA_09)</div>
                <div className="text-purple-300">Audit: Policy #92 deployed to 42 microservices</div>
                <div className="text-indigo-300 font-bold">Offline License Signature: SHA256_RSA_VALID</div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: Education Details */}
        {activeTab === 'education' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-slate-50 p-8 rounded-3xl border border-slate-200 shadow-sm">
            <div className="lg:col-span-6 space-y-4">
              <span className="text-xs font-bold text-amber-600 uppercase tracking-wider">For Universities & Bootcamps</span>
              <h3 className="text-2xl font-extrabold text-slate-900">Classroom Management & Student Code Grading</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Tailored for computer science departments and instructors. Supports course creation, batch student submissions, automated code style & cyclomatic grading, and plagiarism similarity detection.
              </p>
              <ul className="space-y-2 text-xs text-slate-700">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-600" />
                  <span>Maximum 100 projects and 10,000 analyses / month</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-600" />
                  <span>Supports Courses, Classes, and Student Batches</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-600" />
                  <span>Dedicated Lecturer Dashboard with assignment autograder</span>
                </li>
              </ul>
              <div className="pt-2">
                <button
                  onClick={() => onOpenCheckout('education')}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-sm transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <span>Get Academic License ($49)</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-6 bg-slate-900 p-5 rounded-2xl border border-slate-800 font-mono text-xs text-slate-300 space-y-3 shadow-md">
              <div className="text-amber-400 font-bold">// Academic Autograder & Plagiarism Scan:</div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                <div className="text-slate-400">Assignment: CS-204 BinarySearchTree.java</div>
                <div className="text-emerald-400">Class Submissions: 86 / 86 (Auto-graded)</div>
                <div className="text-indigo-300 font-bold">Similarity Index: 1.4% (Integrity Verified)</div>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
