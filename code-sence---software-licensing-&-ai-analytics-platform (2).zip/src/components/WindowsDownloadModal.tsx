import React, { useState, useEffect } from 'react';
import { 
  X, Download, Laptop, CheckCircle2, Zap, Sparkles, AlertCircle, 
  Copy, Check, ExternalLink, Play, FolderArchive, FileCode, RefreshCw,
  HardDrive, Activity, Globe, SlidersHorizontal
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { WindowsDownloadStats } from '../types';
import { LiveDownloadCounter } from './LiveDownloadCounter';
import { SetDownloadCountModal } from './SetDownloadCountModal';

export const GOOGLE_DRIVE_WINDOWS_URL = 'https://drive.google.com/file/d/10C5aBQRInoeCRzAMedUm9mBjhwBQiQ03/view?usp=sharing';

interface WindowsDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDownloadIncrement?: (stats?: WindowsDownloadStats) => void;
}

export const WindowsDownloadModal: React.FC<WindowsDownloadModalProps> = ({
  isOpen,
  onClose,
  onDownloadIncrement,
}) => {
  const [stats, setStats] = useState<WindowsDownloadStats | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [copiedSha, setCopiedSha] = useState(false);
  const [isCalibrateOpen, setIsCalibrateOpen] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const fetchLatest = () => {
        fetch('/api/downloads/stats')
          .then(res => res.json())
          .then(data => {
            if (data.success && data.stats) {
              setStats(data.stats);
              if (onDownloadIncrement) onDownloadIncrement(data.stats);
            }
          })
          .catch(err => console.warn(err));
      };

      fetchLatest();
      const interval = setInterval(fetchLatest, 4000);
      return () => clearInterval(interval);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleDownload = async () => {
    setIsDownloading(true);
    
    // Confetti celebration
    confetti({
      particleCount: 55,
      spread: 65,
      origin: { y: 0.5 }
    });

    try {
      const res = await fetch('/api/downloads/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ os: 'Windows 11/10 x64', country: 'Verified Developer' }),
      });
      const data = await res.json();
      if (data.success && data.stats) {
        setStats(data.stats);
        if (onDownloadIncrement) onDownloadIncrement(data.stats);
      }
    } catch (e) {
      console.error('Error tracking download:', e);
    } finally {
      setIsDownloading(false);
      window.open(GOOGLE_DRIVE_WINDOWS_URL, '_blank', 'noopener,noreferrer');
    }
  };

  const handleCopySha = () => {
    navigator.clipboard.writeText('d8f2a4198ec0028a49c951fa69e0018f29402ab8419ef2018a1a9e87189fa91b');
    setCopiedSha(true);
    setTimeout(() => setCopiedSha(false), 2000);
  };

  const totalDownloads = typeof stats?.totalDownloads === 'number' ? stats.totalDownloads : 0;
  const todayDownloads = typeof stats?.todayDownloads === 'number' ? stats.todayDownloads : 0;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden text-left animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with Dark Windows Accents */}
        <div className="bg-slate-900 text-white p-6 sm:p-7 relative overflow-hidden">
          <div className="absolute top-0 right-0 -mr-10 -mt-10 w-48 h-48 bg-indigo-600/30 rounded-full blur-2xl pointer-events-none" />
          
          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-600/40 border border-indigo-400/40 flex items-center justify-center">
                <Laptop className="w-5 h-5 text-indigo-300" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-xl font-bold text-white tracking-tight">Download CodeSense for Windows</h3>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Portable Tool
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-0.5">
                  Official desktop engine for Windows 10, 11 & Windows Server
                </p>
              </div>
            </div>

            <button
              id="btn-close-download-modal"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Real-time Ticker in Modal Header */}
          <div className="mt-4 pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
            <LiveDownloadCounter
              targetCount={totalDownloads}
              todayCount={todayDownloads}
              label="Present Live Downloads"
              size="md"
              onOpenCalibrate={() => setIsCalibrateOpen(true)}
            />

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsCalibrateOpen(true)}
                className="text-[11px] font-semibold text-slate-300 hover:text-emerald-300 bg-slate-800/80 hover:bg-slate-700 px-2 py-1 rounded-md border border-slate-700 transition-colors flex items-center gap-1 cursor-pointer"
              >
                <SlidersHorizontal className="w-3 h-3 text-emerald-400" />
                <span>Set Correct Amount</span>
              </button>

              <span className="text-amber-300 font-semibold bg-amber-950/60 px-2.5 py-1 rounded-lg border border-amber-800/40 text-xs flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>1,000 Free Pts</span>
              </span>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-7 space-y-6">
          
          {/* Important Notice & Steps */}
          <div className="p-4 rounded-2xl bg-indigo-50/80 border border-indigo-200/80 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-indigo-950">
              <Play className="w-4 h-4 text-indigo-600" />
              <span>How to Start: Double-Click `run.bat`</span>
            </div>
            <p className="text-xs text-indigo-900 leading-relaxed">
              After downloading the ZIP file, extract its contents to any directory and <strong>double-click the <code className="font-mono bg-indigo-200/80 px-1 py-0.5 rounded font-bold">run.bat</code> file</strong>. The tool will boot up directly in Windows Command Prompt and launch your local code intelligence server.
            </p>
          </div>

          {/* 1000 Points Highlight */}
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-950">
              <Zap className="w-4 h-4 text-emerald-600" />
              <span>Instant Free Mode + 1,000 Scan Points Included</span>
            </div>
            <p className="text-xs text-emerald-900 leading-relaxed">
              No serial key or subscription required to get started. All new Windows tool users receive 1,000 free scan points immediately to test cyclomatic audits and architectural debt scans.
            </p>
          </div>

          {/* Package Details */}
          <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <div>
              <span className="text-slate-500">File Type:</span>
              <p className="font-semibold text-slate-800">ZIP Archive (Portable)</p>
            </div>
            <div>
              <span className="text-slate-500">File Size:</span>
              <p className="font-semibold text-slate-800">~48.2 MB</p>
            </div>
            <div>
              <span className="text-slate-500">Execution Script:</span>
              <p className="font-mono font-bold text-indigo-600">run.bat</p>
            </div>
            <div>
              <span className="text-slate-500">Supported OS:</span>
              <p className="font-semibold text-slate-800">Windows 11 / 10 (64-bit)</p>
            </div>
          </div>

          {/* SHA-256 Hash */}
          <div className="p-3 rounded-xl bg-slate-100 border border-slate-200 text-xs flex items-center justify-between gap-3">
            <div className="min-w-0">
              <span className="text-slate-500 text-[11px] block">SHA-256 Checksum:</span>
              <code className="font-mono text-[10px] text-slate-700 truncate block">
                d8f2a4198ec0028a49c951fa69e0018f29402ab8419ef2018a1a9e87189fa91b
              </code>
            </div>
            <button
              onClick={handleCopySha}
              className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-slate-200 text-slate-700 border border-slate-300 text-xs font-semibold shrink-0 cursor-pointer flex items-center gap-1"
            >
              {copiedSha ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedSha ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          {/* Download Action CTA */}
          <div className="space-y-3 pt-2">
            <button
              id="btn-modal-confirm-download"
              onClick={handleDownload}
              disabled={isDownloading}
              className="w-full py-4 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all transform active:scale-98 cursor-pointer"
            >
              {isDownloading ? (
                <RefreshCw className="w-4 h-4 animate-spin text-white" />
              ) : (
                <Download className="w-4 h-4 text-white" />
              )}
              <span>Proceed to Download (Google Drive)</span>
              <ExternalLink className="w-4 h-4 text-indigo-200 ml-1" />
            </button>

            <p className="text-[11px] text-center text-slate-500">
              Direct download hosted securely via official Google Drive storage.
            </p>
          </div>

        </div>
      </div>

      {/* Set / Calibrate Exact Downloads Modal */}
      <SetDownloadCountModal
        isOpen={isCalibrateOpen}
        onClose={() => setIsCalibrateOpen(false)}
        currentTotal={totalDownloads}
        currentToday={todayDownloads}
        onCountUpdated={(newStats) => {
          setStats(newStats);
          if (onDownloadIncrement) onDownloadIncrement(newStats);
        }}
      />
    </div>
  );
};
