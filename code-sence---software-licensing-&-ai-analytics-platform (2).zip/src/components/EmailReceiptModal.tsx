import React from 'react';
import { X, Mail, CheckCircle2, Copy, Download, ExternalLink, Key, Clock, ShieldCheck } from 'lucide-react';

interface EmailReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  emailData: {
    to: string;
    subject: string;
    sentAt: string;
    previewHtml: string;
  } | null;
}

export const EmailReceiptModal: React.FC<EmailReceiptModalProps> = ({ isOpen, onClose, emailData }) => {
  if (!isOpen || !emailData) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6">
      <div className="relative w-full max-w-3xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden text-slate-800 flex flex-col max-h-[90vh]">
        
        {/* Email Client Top Bar */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600">
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-900 leading-tight">Automated Dispatch Email Preview</h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-semibold border border-emerald-200 flex items-center gap-1">
                  <CheckCircle2 className="w-2.5 h-2.5" />
                  Dispatched (200 OK)
                </span>
              </div>
              <p className="text-xs text-slate-500">Live rendering of the automated message sent to customer inbox</p>
            </div>
          </div>
          <button
            id="btn-close-email-modal"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Email Headers metadata */}
        <div className="px-6 py-3 bg-slate-50/70 border-b border-slate-200 text-xs space-y-1.5 font-mono">
          <div className="flex items-center gap-2">
            <span className="text-slate-400 w-16">From:</span>
            <span className="text-slate-700">CodeSense Automated Billing &lt;billing@codesense.dev&gt;</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-slate-400 w-16">To:</span>
            <span className="text-indigo-600 font-bold">{emailData.to}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-slate-400 w-16">Subject:</span>
            <span className="text-slate-900 font-semibold">{emailData.subject}</span>
          </div>
          <div className="flex items-center gap-2 text-slate-500 text-[11px]">
            <span className="text-slate-400 w-16">Sent At:</span>
            <span>{new Date(emailData.sentAt).toLocaleString()} via CodeSense Automated Mail Gateway</span>
          </div>
        </div>

        {/* Rendered Email Body in Frame/Container */}
        <div className="p-6 overflow-y-auto bg-slate-100/70 flex-1">
          <div 
            className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden max-w-xl mx-auto"
            dangerouslySetInnerHTML={{ __html: emailData.previewHtml }}
          />
        </div>

        {/* Footer controls */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-indigo-600" />
            <span>DKIM & SPF Signed • Cryptographic Serial Included</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold transition-colors cursor-pointer shadow-2xs"
          >
            Close Preview
          </button>
        </div>

      </div>
    </div>
  );
};
