import React, { useState } from 'react';
import { 
  ShieldCheck, AlertCircle, Key, CheckCircle2, Clock, Cpu, 
  Trash2, RefreshCw, Upload, Download, FileCode, Check, Copy, AlertTriangle
} from 'lucide-react';
import { SerialLicense } from '../types';

interface LicenseVerifierProps {
  onOpenCheckout: (planId?: string) => void;
  onOpenSandboxWithKey: (key: string) => void;
}

export const LicenseVerifier: React.FC<LicenseVerifierProps> = ({
  onOpenCheckout,
  onOpenSandboxWithKey,
}) => {
  const [inputKey, setInputKey] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [result, setResult] = useState<{
    valid: boolean;
    message: string;
    license?: SerialLicense;
    remainingDays?: number;
    tamperProofValid?: boolean;
  } | null>(null);

  const [copiedKey, setCopiedKey] = useState(false);
  const [deactivatingId, setDeactivatingId] = useState<string | null>(null);

  const handleVerify = async (keyToTest?: string) => {
    const key = (keyToTest || inputKey).trim().toUpperCase();
    if (!key) return;

    setIsVerifying(true);
    setResult(null);

    try {
      const res = await fetch('/api/licenses/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ licenseKey: key }),
      });

      const data = await res.json();
      setResult(data);
    } catch (err: any) {
      setResult({
        valid: false,
        message: err.message || 'Error connecting to validation authority server.',
      });
    } finally {
      setIsVerifying(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);
        if (parsed.serialKey) {
          setInputKey(parsed.serialKey);
          handleVerify(parsed.serialKey);
        } else {
          alert('Could not find serialKey property in the uploaded .lic file.');
        }
      } catch (err) {
        alert('Invalid .lic JSON file format.');
      }
    };
    reader.readAsText(file);
  };

  const handleDeactivateMachine = async (machineId: string) => {
    if (!result?.license) return;
    setDeactivatingId(machineId);

    try {
      const res = await fetch('/api/licenses/deactivate-machine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          licenseKey: result.license.licenseKey,
          machineId,
        }),
      });

      const data = await res.json();
      if (data.success && data.license) {
        setResult(prev => prev ? { ...prev, license: data.license } : null);
      } else {
        alert(data.message || 'Failed to deactivate machine slot.');
      }
    } catch (err) {
      alert('Error deactivating machine.');
    } finally {
      setDeactivatingId(null);
    }
  };

  return (
    <section id="license-verifier" className="py-16 bg-slate-50 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Section Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold uppercase tracking-wider">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Cryptographic Key Authenticity & Quota Inspector</span>
          </div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            CodeSense Serial Key Verifier
          </h2>
          <p className="text-slate-600 text-sm max-w-xl mx-auto">
            Inspect any CodeSense serial license key, test cryptographic checksums, check active workstation binds, and review expiration dates.
          </p>
        </div>

        {/* Verifier Input Box */}
        <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center justify-between">
            <span>Enter Serial Code or Upload .lic Certificate</span>
            <label className="text-indigo-600 hover:text-indigo-700 cursor-pointer flex items-center gap-1 normal-case text-xs font-medium">
              <Upload className="w-3.5 h-3.5" />
              <span>Upload .lic file</span>
              <input type="file" accept=".lic,.json" onChange={handleFileUpload} className="hidden" />
            </label>
          </label>

          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <input
                id="input-verifier-key"
                type="text"
                value={inputKey}
                onChange={(e) => setInputKey(e.target.value)}
                placeholder="e.g. CS-PRO-984A-B821-X550-7F2A"
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 focus:bg-white rounded-xl text-sm font-mono text-slate-900 focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 transition-all"
              />
              <Key className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            </div>

            <button
              id="btn-verify-key"
              onClick={() => handleVerify()}
              disabled={isVerifying || !inputKey.trim()}
              className="px-6 py-3 rounded-xl text-sm font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm flex items-center justify-center gap-2 disabled:opacity-50 transition-colors cursor-pointer"
            >
              {isVerifying ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
              <span>{isVerifying ? 'Checking...' : 'Verify Authenticity'}</span>
            </button>
          </div>

          {/* Secure Verification Guidance */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs text-slate-500">
            <span className="flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>SHA-256 Checksum & ECDSA Digital Signature Validation</span>
            </span>
            <button
              onClick={() => onOpenCheckout('pro')}
              className="text-indigo-600 font-semibold hover:text-indigo-700 hover:underline cursor-pointer"
            >
              Need a license key? Purchase here →
            </button>
          </div>
        </div>

        {/* Verification Result Card */}
        {result && (
          <div className={`p-6 sm:p-8 rounded-2xl border shadow-sm space-y-6 ${
            result.valid
              ? 'bg-white border-emerald-300 ring-1 ring-emerald-200'
              : 'bg-white border-red-300 ring-1 ring-red-200'
          }`}>
            
            {/* Header Badge */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div className="flex items-center gap-3">
                {result.valid ? (
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                ) : (
                  <div className="w-10 h-10 rounded-xl bg-red-50 border border-red-200 flex items-center justify-center text-red-600">
                    <AlertCircle className="w-6 h-6" />
                  </div>
                )}
                <div>
                  <h3 className="text-lg font-bold text-slate-900 leading-tight">
                    {result.valid ? `Authentic CodeSense ${result.license?.planName} License` : 'Invalid or Fake Serial Key'}
                  </h3>
                  <p className={`text-xs mt-0.5 ${result.valid ? 'text-emerald-700' : 'text-red-600'}`}>
                    {result.message}
                  </p>
                </div>
              </div>

              {result.valid && result.license && (
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-mono font-bold">
                    {result.license.status.toUpperCase()}
                  </span>
                  {result.remainingDays !== undefined && (
                    <span className="px-3 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-mono border border-slate-200">
                      {result.remainingDays} days remaining
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* License Detailed Specs if valid */}
            {result.valid && result.license && (
              <div className="space-y-6">
                {/* Meta Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Licensee Name</span>
                    <span className="font-bold text-slate-900 mt-0.5 block">{result.license.customerName}</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Customer Email</span>
                    <span className="font-bold text-indigo-600 mt-0.5 block">{result.license.customerEmail}</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Max Projects Quota</span>
                    <span className="font-bold text-slate-900 mt-0.5 block">{result.license.limits.maxProjects} Projects</span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Monthly Limit</span>
                    <span className="font-bold text-emerald-600 mt-0.5 block">{result.license.limits.maxAnalysesPerMonth.toLocaleString()} / mo</span>
                  </div>
                </div>

                {/* Bound Workstations */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                      <Cpu className="w-4 h-4 text-indigo-600" />
                      <span>Active Workstation Node Bindings ({result.license.activeMachines.length} / {result.license.maxMachineActivations} slots)</span>
                    </span>
                  </div>

                  <div className="space-y-2">
                    {result.license.activeMachines.map((machine) => (
                      <div key={machine.machineId} className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3 text-xs font-mono">
                        <div>
                          <span className="font-bold text-slate-900 block">{machine.hostname}</span>
                          <span className="text-slate-500 text-[11px]">ID: {machine.machineId} • {machine.os}</span>
                        </div>
                        <button
                          onClick={() => handleDeactivateMachine(machine.machineId)}
                          disabled={deactivatingId === machine.machineId}
                          className="px-2.5 py-1 rounded bg-red-50 hover:bg-red-100 text-red-700 text-[11px] border border-red-200 flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>{deactivatingId === machine.machineId ? 'Revoking...' : 'Unbind'}</span>
                        </button>
                      </div>
                    ))}
                    {result.license.activeMachines.length === 0 && (
                      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-500 text-center">
                        No developer machines bound yet. First workstation to run <code>codesense activate</code> will claim a slot automatically.
                      </div>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-2 flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => onOpenSandboxWithKey(result.license!.licenseKey)}
                    className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-sm transition-colors cursor-pointer"
                  >
                    Open in Software CLI Sandbox →
                  </button>
                </div>
              </div>
            )}

            {/* If Invalid */}
            {!result.valid && (
              <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 space-y-2">
                <p className="font-semibold">Possible causes:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Serial checksum mismatch or typographical mistake.</li>
                  <li>Key was modified or tampered with.</li>
                  <li>Subscription has expired or been cancelled.</li>
                </ul>
                <div className="pt-2">
                  <button
                    onClick={() => onOpenCheckout('pro')}
                    className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-semibold shadow-sm transition-colors cursor-pointer"
                  >
                    Purchase Valid CodeSense License Key →
                  </button>
                </div>
              </div>
            )}

          </div>
        )}

      </div>
    </section>
  );
};
