import React, { useState } from 'react';
import { 
  X, ShieldCheck, CheckCircle2, User, Mail, ExternalLink, 
  Sparkles, Key, AlertCircle, Copy, Check, ChevronDown, ChevronUp, Lock
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface GoogleLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const GoogleLoginModal: React.FC<GoogleLoginModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { 
    user, 
    loginWithGooglePopup, 
    loginWithDemoAccount, 
    logout, 
    clientIdConfigured,
    callbackUrl,
    isLoading 
  } = useAuth();

  const [customEmail, setCustomEmail] = useState('');
  const [customName, setCustomName] = useState('');
  const [showConfigGuide, setShowConfigGuide] = useState(false);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(id);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleGoogleClick = async () => {
    await loginWithGooglePopup();
    if (onSuccess) onSuccess();
  };

  const handleQuickLogin = async (email: string, name: string) => {
    await loginWithDemoAccount(email, name);
    if (onSuccess) onSuccess();
    onClose();
  };

  const handleCustomLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customEmail) return;
    await loginWithDemoAccount(customEmail, customName || customEmail.split('@')[0]);
    if (onSuccess) onSuccess();
    onClose();
  };

  const runtimeCallback = callbackUrl || (typeof window !== 'undefined' ? `${window.location.origin}/auth/callback` : 'https://ais-dev-jlczdl6vhmy6666tosrgp4-778461947647.asia-southeast1.run.app/auth/callback');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div 
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-6 pb-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-slate-50 to-indigo-50/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 shadow-xs flex items-center justify-center">
              {/* Google G Logo SVG */}
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 leading-tight">
                {user ? 'Google Account Connected' : 'Sign in with Google'}
              </h3>
              <p className="text-xs text-slate-500">
                CodeSense Single Sign-On & License Synchronization
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-700 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 overflow-y-auto">
          {user ? (
            /* Logged In State */
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-indigo-50/60 border border-indigo-100 flex items-center gap-4">
                <img
                  src={user.picture || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(user.name)}`}
                  alt={user.name}
                  className="w-14 h-14 rounded-full border-2 border-white shadow-sm"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-slate-900 truncate">{user.name}</h4>
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                      <CheckCircle2 className="w-3 h-3" />
                      Verified
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 truncate mt-0.5">{user.email}</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Connected via Google OAuth 2.0 • Ready for 1-Click Checkout
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    onClose();
                    if (onSuccess) onSuccess();
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-sm transition-colors cursor-pointer text-center"
                >
                  Continue to Workspace
                </button>
                <button
                  onClick={logout}
                  className="px-4 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-rose-600 border border-slate-200 font-semibold text-xs transition-colors cursor-pointer"
                >
                  Sign Out
                </button>
              </div>
            </div>
          ) : (
            /* Logged Out State */
            <div className="space-y-6">
              
              {/* Primary Google Login Button */}
              <button
                id="btn-google-oauth-primary"
                onClick={handleGoogleClick}
                disabled={isLoading}
                className="w-full py-3.5 px-4 rounded-2xl bg-white hover:bg-slate-50 border-2 border-slate-200 hover:border-slate-300 shadow-sm flex items-center justify-center gap-3 transition-all transform active:scale-98 cursor-pointer group"
              >
                <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span className="text-sm font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">
                  {isLoading ? 'Connecting to Google...' : 'Continue with Google'}
                </span>
              </button>

              {/* 1-Click Fast Sandbox Accounts */}
              <div className="space-y-2.5">
                <div className="flex items-center gap-2">
                  <div className="h-px bg-slate-200 flex-1" />
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Instant 1-Click Google Profiles
                  </span>
                  <div className="h-px bg-slate-200 flex-1" />
                </div>

                <div className="grid grid-cols-1 gap-2">
                  {/* Primary Profile: udayaprinter.gamini@gmail.com */}
                  <button
                    id="btn-quick-login-udaya"
                    onClick={() => handleQuickLogin('udayaprinter.gamini@gmail.com', 'Udaya Gamini')}
                    className="p-3 rounded-xl bg-slate-50 hover:bg-indigo-50/60 border border-slate-200 hover:border-indigo-300 transition-all flex items-center justify-between text-left cursor-pointer group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-indigo-600 text-white font-bold text-xs flex items-center justify-center shadow-xs">
                        UG
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-slate-900 group-hover:text-indigo-700">Udaya Gamini</span>
                          <span className="text-[9px] font-bold bg-indigo-100 text-indigo-700 px-1.5 py-0.2 rounded-full">Owner</span>
                        </div>
                        <p className="text-[11px] text-slate-500 font-mono">udayaprinter.gamini@gmail.com</p>
                      </div>
                    </div>
                    <span className="text-xs font-semibold text-indigo-600 group-hover:translate-x-0.5 transition-transform">
                      Sign In &rarr;
                    </span>
                  </button>

                  {/* Secondary Profile: Alex Vance */}
                  <button
                    onClick={() => handleQuickLogin('alex.vance@techcorp.io', 'Alex Vance')}
                    className="p-3 rounded-xl bg-slate-50 hover:bg-indigo-50/60 border border-slate-200 hover:border-indigo-300 transition-all flex items-center justify-between text-left cursor-pointer group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-sky-600 text-white font-bold text-xs flex items-center justify-center shadow-xs">
                        AV
                      </div>
                      <div>
                        <span className="text-xs font-bold text-slate-900 group-hover:text-indigo-700">Alex Vance</span>
                        <p className="text-[11px] text-slate-500 font-mono">alex.vance@techcorp.io</p>
                      </div>
                    </div>
                    <span className="text-xs font-semibold text-indigo-600 group-hover:translate-x-0.5 transition-transform">
                      Sign In &rarr;
                    </span>
                  </button>
                </div>
              </div>

              {/* Custom Google Email Form */}
              <form onSubmit={handleCustomLogin} className="space-y-3 pt-2">
                <div className="flex items-center gap-2">
                  <div className="h-px bg-slate-200 flex-1" />
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Or Enter Any Google Account
                  </span>
                  <div className="h-px bg-slate-200 flex-1" />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={customName}
                    onChange={(e) => setCustomName(e.target.value)}
                    placeholder="Your Name (e.g. John Doe)"
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:border-indigo-600"
                  />
                  <input
                    type="email"
                    required
                    value={customEmail}
                    onChange={(e) => setCustomEmail(e.target.value)}
                    placeholder="name@gmail.com"
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:border-indigo-600"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-black text-white font-semibold text-xs shadow-xs transition-colors cursor-pointer"
                >
                  Authenticate Account
                </button>
              </form>

              {/* Collapsible OAuth Setup Instructions */}
              <div className="border border-slate-200 rounded-2xl overflow-hidden bg-slate-50">
                <button
                  type="button"
                  onClick={() => setShowConfigGuide(!showConfigGuide)}
                  className="w-full p-3.5 flex items-center justify-between text-left text-xs font-semibold text-slate-700 hover:text-indigo-600 transition-colors cursor-pointer"
                >
                  <span className="flex items-center gap-2">
                    <Key className="w-3.5 h-3.5 text-indigo-600" />
                    Google Cloud Console OAuth Configuration
                  </span>
                  {showConfigGuide ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>

                {showConfigGuide && (
                  <div className="p-4 pt-0 space-y-3 text-xs border-t border-slate-200 bg-white">
                    <p className="text-slate-600 leading-relaxed">
                      To connect your own Google Cloud Client ID for live production sign-in:
                    </p>

                    <div className="space-y-2">
                      <div>
                        <span className="text-[10px] font-bold text-slate-400 uppercase">1. Authorized Redirect URI:</span>
                        <div className="mt-1 p-2 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between">
                          <code className="text-[11px] font-mono text-indigo-700 truncate select-all">{runtimeCallback}</code>
                          <button
                            type="button"
                            onClick={() => handleCopy(runtimeCallback, 'callback')}
                            className="p-1 text-slate-500 hover:text-slate-800 cursor-pointer"
                            title="Copy URI"
                          >
                            {copiedText === 'callback' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                          </button>
                        </div>
                      </div>

                      <div>
                        <span className="text-[10px] font-bold text-slate-400 uppercase">2. Environment Variables (.env.example):</span>
                        <ul className="mt-1 space-y-1 list-disc list-inside text-slate-600 font-mono text-[11px]">
                          <li><span className="text-slate-900 font-semibold">GOOGLE_CLIENT_ID</span></li>
                          <li><span className="text-slate-900 font-semibold">GOOGLE_CLIENT_SECRET</span></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                )}
              </div>

            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span className="flex items-center gap-1">
            <Lock className="w-3 h-3 text-slate-400" />
            256-bit encrypted authentication
          </span>
          <span className="text-[11px]">CodeSense Identity Protocol</span>
        </div>
      </div>
    </div>
  );
};
