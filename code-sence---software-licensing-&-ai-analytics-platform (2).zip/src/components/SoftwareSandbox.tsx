import React, { useState, useEffect } from 'react';
import { 
  Terminal, Key, CheckCircle2, AlertTriangle, ShieldCheck, Play, Sparkles, 
  ArrowRight, Copy, Check, RefreshCw, Cpu, FileCode2, GitBranch, Layers, 
  GraduationCap, Users, Shield, Zap, Lock
} from 'lucide-react';
import { SerialLicense, CodeAnalysisResult, PlanId } from '../types';

interface SoftwareSandboxProps {
  initialKey?: string;
  onOpenPricing: () => void;
  onOpenCheckout: (planId?: string) => void;
}

export const SoftwareSandbox: React.FC<SoftwareSandboxProps> = ({
  initialKey = '',
  onOpenPricing,
  onOpenCheckout,
}) => {
  const [activeKey, setActiveKey] = useState<string>(initialKey);
  const [activeLicense, setActiveLicense] = useState<SerialLicense | null>(null);
  const [isActivating, setIsActivating] = useState(false);
  const [activationMessage, setActivationMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Terminal & Sandbox state
  const [selectedRepo, setSelectedRepo] = useState<string>('ecommerce-microservice');
  const [activeViewTab, setActiveViewTab] = useState<'cli' | 'debt' | 'cicd' | 'edu'>('cli');
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    'CodeSense CLI Core v2.4.0-release initialized.',
    'System ready. Provide a valid serial license key to unlock advanced modules.',
    'Type "codesense status" or "codesense scan" to begin.',
  ]);
  const [isScanning, setIsScanning] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<CodeAnalysisResult | null>(null);
  const [commandInput, setCommandInput] = useState('');

  const handleActivateFreeMode = () => {
    setActiveKey('');
    const freeLicense: SerialLicense = {
      licenseKey: 'KEYLESS-FREE-MODE',
      planId: 'free',
      planName: 'Free (Keyless Mode)',
      customerName: 'Guest Developer',
      customerEmail: 'developer@codesense.dev',
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 365 * 86400000).toISOString(),
      status: 'active',
      billingInterval: 'yearly',
      amountPaid: 0,
      currency: 'USD',
      transactionId: 'TXN-FREE-KEYLESS',
      paymentMethod: 'none',
      invoiceNumber: 'INV-FREE-000',
      limits: {
        maxProjects: 3,
        maxAnalysesPerMonth: 100,
        seats: 1,
        apiRateLimit: 'Standard Web & CLI Scanner',
      },
      features: [
        'No Serial Key Required (100% Keyless Access)',
        'AST Code Complexity & SLOC Scan',
        'Cyclomatic Complexity & Maintainability Index',
        'Basic Refactoring Opportunities',
      ],
      activeMachines: [
        {
          machineId: 'MCH-FREE-LOCAL',
          hostname: 'local-dev-workstation',
          os: 'Web & Local CLI',
          activatedAt: new Date().toISOString(),
          lastPing: new Date().toISOString(),
        }
      ],
      maxMachineActivations: 1,
      digitalSignature: 'SIG_FREE_KEYLESS_MODE',
    };

    setActiveLicense(freeLicense);
    setActivationMessage({
      type: 'success',
      text: '✓ Free Mode Active — No serial key required! Enjoy 100 free monthly code scans.',
    });

    setTerminalLogs(prev => [
      ...prev,
      `> codesense mode --free`,
      `[SUCCESS] Running in Free Mode (No serial key required).`,
      `[QUOTA] Max Projects: 3 | Analyses/mo: 100 | Rate: Standard Scanner`,
      `[STATUS] Ready to execute code intelligence scan.`,
    ]);

    runAnalysis(selectedRepo, '');
  };

  // If initialKey is passed, auto-verify, otherwise boot in keyless Free Mode
  useEffect(() => {
    if (initialKey) {
      setActiveKey(initialKey);
      handleActivate(initialKey);
    } else if (!activeLicense) {
      handleActivateFreeMode();
    }
  }, [initialKey]);

  const handleActivate = async (keyToVerify?: string) => {
    const key = (keyToVerify || activeKey).trim();
    if (!key || key.toLowerCase() === 'free' || key.toLowerCase() === 'keyless') {
      handleActivateFreeMode();
      return;
    }

    setIsActivating(true);
    setActivationMessage({ type: 'info', text: 'Authenticating serial key and binding machine slot...' });

    try {
      // Step 1: Verify key
      const verifyRes = await fetch('/api/licenses/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ licenseKey: key }),
      });

      const verifyData = await verifyRes.json();
      if (!verifyRes.ok || !verifyData.valid) {
        throw new Error(verifyData.message || 'Invalid serial license key.');
      }

      // Step 2: Bind machine
      const bindRes = await fetch('/api/licenses/activate-machine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          licenseKey: key,
          hostname: 'local-dev-workstation',
          os: 'macOS Sonoma 14.5 / x86_64',
        }),
      });

      const bindData = await bindRes.json();
      const lic = bindData.license || verifyData.license;
      setActiveLicense(lic);

      setActivationMessage({
        type: 'success',
        text: `✓ Successfully authenticated as CodeSense ${lic.planName}! Quotas & modules unlocked.`,
      });

      setTerminalLogs(prev => [
        ...prev,
        `> codesense activate --key="${key}"`,
        `[SUCCESS] Key verified. Plan: ${lic.planName}.`,
        `[QUOTA] Max Projects: ${lic.limits.maxProjects} | Analyses/mo: ${lic.limits.maxAnalysesPerMonth.toLocaleString()}`,
        `[MODULES] ${lic.features.slice(0, 3).join(', ')}...`,
        `[STATUS] Ready to execute repository analysis.`,
      ]);

      // Automatically trigger a scan on sample repo
      runAnalysis(selectedRepo, key);
    } catch (err: any) {
      setActivationMessage({
        type: 'error',
        text: err.message || 'Failed to authenticate serial key.',
      });
      setTerminalLogs(prev => [
        ...prev,
        `> codesense activate --key="${key}"`,
        `[ERROR] ${err.message || 'Key authentication failed.'}`,
      ]);
    } finally {
      setIsActivating(false);
    }
  };

  const runAnalysis = async (repoId: string, overrideKey?: string) => {
    setIsScanning(true);
    const key = overrideKey || activeKey;
    
    setTerminalLogs(prev => [
      ...prev,
      `> codesense scan --target="./repos/${repoId}" --license="${key || 'UNLICENSED'}"`,
      `[SCAN] Parsing AST trees and calculating cyclomatic complexity...`,
      `[SCAN] Evaluating technical debt and architectural cohesion...`,
    ]);

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectId: repoId,
          licenseKey: key,
        }),
      });

      const data = await response.json();
      if (data.success) {
        setAnalysisResult(data.analysis);
        setTerminalLogs(prev => [
          ...prev,
          `[COMPLETED] Analyzed ${data.analysis.linesOfCode.toLocaleString()} LOC across ${data.analysis.filesScanned} files.`,
          `[METRICS] Quality Score: ${data.analysis.qualityScore}/100 (Rating ${data.analysis.maintainabilityRating})`,
          `[DEBT] Estimated Technical Debt: ${data.analysis.technicalDebtHours} hours`,
          `[SECURITY] Found ${data.analysis.securityVulnerabilities.length} potential security hotspots.`,
          `[SIMULATOR] ${data.analysis.refactoringOpportunities.length} automated refactoring models generated.`,
        ]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsScanning(false);
    }
  };

  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commandInput.trim()) return;

    const cmd = commandInput.trim().toLowerCase();
    setCommandInput('');

    if (cmd === 'clear') {
      setTerminalLogs(['CodeSense CLI ready.']);
      return;
    }

    if (cmd === 'help') {
      setTerminalLogs(prev => [
        ...prev,
        `> ${commandInput}`,
        'Available commands:',
        '  codesense status       - Display active license & quota limits',
        '  codesense scan         - Scan active repository and output metrics',
        '  codesense debt         - View detailed technical debt hours & costs',
        '  codesense refactor     - View Refactoring Simulator diffs',
        '  codesense ci-gate      - Execute CI/CD pull request gate rules',
        '  clear                  - Clear terminal log output',
      ]);
      return;
    }

    if (cmd.includes('status')) {
      if (activeLicense) {
        setTerminalLogs(prev => [
          ...prev,
          `> ${commandInput}`,
          `[LICENSE] Key: ${activeLicense.licenseKey}`,
          `[TIER] ${activeLicense.planName} (${activeLicense.status.toUpperCase()})`,
          `[QUOTA] Projects: ${activeLicense.limits.maxProjects} | Analyses/mo: ${activeLicense.limits.maxAnalysesPerMonth.toLocaleString()}`,
          `[SEATS] Active workstations: ${activeLicense.activeMachines.length}/${activeLicense.maxMachineActivations}`,
        ]);
      } else {
        setTerminalLogs(prev => [
          ...prev,
          `> ${commandInput}`,
          `[STATUS] No active serial license found. Running in restricted Evaluation mode.`,
          `Use "codesense activate --key=CS-PRO-..." to unlock features.`,
        ]);
      }
      return;
    }

    if (cmd.includes('scan') || cmd.includes('analyze')) {
      runAnalysis(selectedRepo);
      return;
    }

    if (cmd.includes('debt')) {
      setActiveViewTab('debt');
      setTerminalLogs(prev => [
        ...prev,
        `> ${commandInput}`,
        `Switched view to Technical Debt & Refactoring Simulator.`,
      ]);
      return;
    }

    if (cmd.includes('ci')) {
      setActiveViewTab('cicd');
      setTerminalLogs(prev => [
        ...prev,
        `> ${commandInput}`,
        `Switched view to CI/CD Quality Gates.`,
      ]);
      return;
    }

    setTerminalLogs(prev => [
      ...prev,
      `> ${commandInput}`,
      `Executing "${commandInput}"... (Type "help" for a list of valid CodeSense commands)`,
    ]);
  };

  return (
    <section id="software-sandbox" className="py-12 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Top Header & Context */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold uppercase tracking-wider mb-2">
              <Terminal className="w-3.5 h-3.5" />
              <span>Live Software Sandbox & CLI Runtime</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              CodeSense™ Software Tool & License Engine
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Test your newly purchased serial keys in real-time, authenticate developer workstations, and simulate automated code analysis.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onOpenCheckout('pro')}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Buy Pro / Team Key</span>
            </button>
            <button
              onClick={onOpenPricing}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 transition-colors cursor-pointer shadow-2xs"
            >
              Compare Plans
            </button>
          </div>
        </div>

        {/* Serial Key Activation Bar */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
              <Key className="w-4 h-4 text-indigo-600" />
              <span>Serial Key Activation & Workstation Binding</span>
            </label>
            {activeLicense && (
              <span className="text-xs font-bold px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Active Tier: {activeLicense.planName} ({activeLicense.limits.maxProjects} Projects / {activeLicense.limits.maxAnalysesPerMonth.toLocaleString()} Analyses)
              </span>
            )}
          </div>

          {/* Key Input & Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <input
                id="input-sandbox-serial-key"
                type="text"
                value={activeKey}
                onChange={(e) => setActiveKey(e.target.value)}
                placeholder="Enter Serial Code (Optional for Free Mode - e.g. CODESENSE-PRO-AAD8CB1F)"
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 focus:bg-white rounded-xl text-sm font-mono text-slate-900 focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 transition-all"
              />
              <Key className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            </div>

            <button
              id="btn-sandbox-free-mode"
              onClick={handleActivateFreeMode}
              className="px-5 py-3 rounded-xl text-sm font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Zap className="w-4 h-4 text-emerald-600" />
              <span>Use Free Mode (Keyless)</span>
            </button>

            <button
              id="btn-sandbox-activate"
              onClick={() => handleActivate()}
              disabled={isActivating}
              className="px-6 py-3 rounded-xl text-sm font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm flex items-center justify-center gap-2 disabled:opacity-50 transition-all cursor-pointer"
            >
              {isActivating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
              <span>{isActivating ? 'Authenticating...' : 'Activate Paid Key'}</span>
            </button>
          </div>

          {/* Status & Licensing Information */}
          <div className="pt-1 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-slate-500 font-medium">Mode:</span>
              <button
                onClick={handleActivateFreeMode}
                className="px-2.5 py-1 rounded-md bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-800 font-semibold text-[11px] transition-colors cursor-pointer flex items-center gap-1"
              >
                <Zap className="w-3 h-3 text-emerald-600" />
                <span>Free Mode (Active by Default)</span>
              </button>
            </div>

            <div className="flex items-center gap-2 text-slate-500">
              <Lock className="w-3.5 h-3.5 text-slate-400" />
              <span>Need a Pro, Team, or Enterprise Key?</span>
              <button
                onClick={() => onOpenCheckout('pro')}
                className="text-indigo-600 font-bold hover:text-indigo-700 hover:underline cursor-pointer flex items-center gap-0.5"
              >
                <span>Purchase License</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Activation Feedback */}
          {activationMessage && (
            <div className={`p-3.5 rounded-xl text-xs font-medium flex items-center gap-2 ${
              activationMessage.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                : activationMessage.type === 'error'
                ? 'bg-red-50 text-red-800 border border-red-200'
                : 'bg-indigo-50 text-indigo-800 border border-indigo-200'
            }`}>
              {activationMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              ) : (
                <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
              )}
              <span>{activationMessage.text}</span>
            </div>
          )}
        </div>

        {/* Repository Selector & View Switcher */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <label className="text-xs text-slate-600 font-semibold">Select Target Codebase:</label>
            <select
              id="select-sandbox-repo"
              value={selectedRepo}
              onChange={(e) => {
                setSelectedRepo(e.target.value);
                runAnalysis(e.target.value);
              }}
              className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-medium text-slate-700 focus:outline-none focus:border-indigo-600"
            >
              <option value="ecommerce-microservice">ecommerce-cart-service (TypeScript / Node.js - 14.8k LOC)</option>
              <option value="payment-gateway-sdk">pay-core-engine (Go / gRPC - 28.4k LOC)</option>
              <option value="ml-pipeline-orchestrator">data-flow-agent (Python 3.12 - 9.6k LOC)</option>
              <option value="academic-cs101-assignments">cs204-data-structures-lab (Java 21 - 4.2k LOC)</option>
            </select>
            <button
              onClick={() => runAnalysis(selectedRepo)}
              disabled={isScanning}
              className="px-3 py-1.5 rounded-lg bg-white hover:bg-slate-50 text-indigo-600 text-xs font-semibold border border-slate-200 flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
              <span>Rescan</span>
            </button>
          </div>

          {/* Module View Tabs */}
          <div className="bg-slate-200/70 p-1 rounded-xl flex items-center gap-1">
            <button
              onClick={() => setActiveViewTab('cli')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeViewTab === 'cli'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>CLI Terminal</span>
            </button>

            <button
              onClick={() => setActiveViewTab('debt')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeViewTab === 'debt'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Refactoring Simulator</span>
            </button>

            <button
              onClick={() => setActiveViewTab('cicd')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeViewTab === 'cicd'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <GitBranch className="w-3.5 h-3.5 text-emerald-600" />
              <span>CI/CD Quality Gates</span>
            </button>

            <button
              onClick={() => setActiveViewTab('edu')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeViewTab === 'edu'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
              <span>Education Hub</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Terminal & Interactive Shell */}
        {activeViewTab === 'cli' && (
          <div className="rounded-2xl bg-slate-900 border border-slate-800 shadow-lg overflow-hidden">
            {/* Terminal Top Window Bar */}
            <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500/80" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                <div className="w-3 h-3 rounded-full bg-green-500/80" />
                <span className="text-xs font-mono text-slate-400 ml-2">bash — codesense-cli@workstation-01</span>
              </div>
              <div className="text-[11px] font-mono text-slate-500">
                Type &quot;help&quot; for command reference
              </div>
            </div>

            {/* Terminal Stream */}
            <div className="p-5 font-mono text-xs text-slate-200 bg-slate-950/95 min-h-[320px] max-h-[480px] overflow-y-auto space-y-2">
              {terminalLogs.map((log, index) => {
                const isCommand = log.startsWith('>');
                const isSuccess = log.includes('[SUCCESS]') || log.includes('[COMPLETED]');
                const isError = log.includes('[ERROR]');
                const isQuota = log.includes('[QUOTA]') || log.includes('[LICENSE]');
                
                return (
                  <div
                    key={index}
                    className={`${
                      isCommand
                        ? 'text-cyan-400 font-bold pt-1'
                        : isSuccess
                        ? 'text-emerald-400'
                        : isError
                        ? 'text-red-400'
                        : isQuota
                        ? 'text-sky-300'
                        : 'text-slate-300'
                    }`}
                  >
                    {log}
                  </div>
                );
              })}
              {isScanning && (
                <div className="text-cyan-400 flex items-center gap-2 animate-pulse">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Scanning repository abstract syntax tree...</span>
                </div>
              )}
            </div>

            {/* Terminal Command Input Form */}
            <form onSubmit={handleCommandSubmit} className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
              <span className="text-emerald-400 font-mono text-xs font-bold pl-2">$</span>
              <input
                id="input-terminal-command"
                type="text"
                value={commandInput}
                onChange={(e) => setCommandInput(e.target.value)}
                placeholder="Type command: codesense scan, codesense debt, codesense status, clear"
                className="flex-1 bg-transparent border-none text-xs font-mono text-white focus:outline-none placeholder-slate-600"
              />
              <button
                type="submit"
                className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono transition-colors cursor-pointer"
              >
                Send ↵
              </button>
            </form>
          </div>
        )}

        {/* Tab 2: Technical Debt & Refactoring Simulator */}
        {activeViewTab === 'debt' && analysisResult && (
          <div className="space-y-6">
            {/* Metric Summary Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1">
                <span className="text-xs text-slate-500 font-medium">Estimated Technical Debt</span>
                <div className="text-2xl font-extrabold text-amber-600">
                  {analysisResult.technicalDebtHours > 0 ? `${analysisResult.technicalDebtHours} hours` : 'Locked in Free Plan'}
                </div>
                <p className="text-[11px] text-slate-400">~${(analysisResult.technicalDebtHours * 85).toLocaleString()} developer remediation cost</p>
              </div>

              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1">
                <span className="text-xs text-slate-500 font-medium">Code Quality Score</span>
                <div className="text-2xl font-extrabold text-emerald-600">
                  {analysisResult.qualityScore} / 100
                </div>
                <p className="text-[11px] text-slate-400">Maintainability Grade: {analysisResult.maintainabilityRating}</p>
              </div>

              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1">
                <span className="text-xs text-slate-500 font-medium">Lines of Code & Files</span>
                <div className="text-2xl font-extrabold text-slate-900">
                  {analysisResult.linesOfCode.toLocaleString()} LOC
                </div>
                <p className="text-[11px] text-slate-400">{analysisResult.filesScanned} source files scanned</p>
              </div>

              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1">
                <span className="text-xs text-slate-500 font-medium">Duplicated Code</span>
                <div className="text-2xl font-extrabold text-indigo-600">
                  {analysisResult.duplicatedLinesPercent}%
                </div>
                <p className="text-[11px] text-slate-400">Well below the 5% threshold</p>
              </div>
            </div>

            {/* Refactoring Opportunities Diff Viewer */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-indigo-600" />
                  <span>Interactive Refactoring Simulator (Pro / Team / Enterprise)</span>
                </h3>
                {(!activeLicense || activeLicense.planId === 'free') && (
                  <span className="text-xs text-amber-800 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
                    Showing Preview. Unlock Full Simulation with Pro Key.
                  </span>
                )}
              </div>

              {analysisResult.refactoringOpportunities.length > 0 ? (
                analysisResult.refactoringOpportunities.map((item, idx) => (
                  <div key={idx} className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">{item.title}</h4>
                        <p className="text-xs text-slate-500 mt-0.5">{item.description}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded bg-red-50 text-red-700 text-[10px] font-bold border border-red-200">
                          Impact: {item.impact}
                        </span>
                        <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-mono border border-slate-200">
                          Effort: {item.effort}
                        </span>
                      </div>
                    </div>

                    {/* Before vs After Diff Code Comparison */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                      {/* Before */}
                      <div className="space-y-1.5">
                        <div className="text-[11px] font-mono font-bold text-red-600 flex items-center gap-1">
                          <span>❌ Legacy Smelly Implementation:</span>
                        </div>
                        <pre className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-red-300 font-mono text-[11px] overflow-x-auto leading-relaxed">
                          {item.codeSnippetBefore}
                        </pre>
                      </div>

                      {/* After */}
                      <div className="space-y-1.5">
                        <div className="text-[11px] font-mono font-bold text-emerald-600 flex items-center gap-1">
                          <span>✓ CodeSense Optimized Refactoring:</span>
                        </div>
                        <pre className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-emerald-400 font-mono text-[11px] overflow-x-auto leading-relaxed">
                          {item.codeSnippetAfter}
                        </pre>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 rounded-2xl bg-white border border-slate-200 text-center space-y-3 shadow-sm">
                  <Lock className="w-8 h-8 text-amber-600 mx-auto" />
                  <h4 className="text-base font-bold text-slate-900">Refactoring Simulator is Locked in Free Tier</h4>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    Upgrade to CodeSense PRO ($29/mo) or TEAM ($99/mo) to unlock automated refactoring models and technical debt breakdowns.
                  </p>
                  <button
                    onClick={() => onOpenCheckout('pro')}
                    className="px-4 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm transition-colors cursor-pointer"
                  >
                    Upgrade to Pro Now →
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 3: CI/CD Quality Gates & RBAC */}
        {activeViewTab === 'cicd' && (
          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <GitBranch className="w-5 h-5 text-emerald-600" />
                  <span>CI/CD Pipeline Quality Gates & PR Blocker Rules</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1">Included in TEAM and ENTERPRISE plans for GitHub Actions, GitLab CI, and Jenkins.</p>
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-mono font-bold border border-emerald-200">
                Quality Gate Status: PASSED (3/3)
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">Technical Debt Threshold</span>
                  <span className="text-emerald-600 text-xs font-bold">✓ PASS</span>
                </div>
                <div className="text-xs text-slate-500">Rule: Max 50h debt on main branch</div>
                <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full w-[72%]" />
                </div>
                <span className="text-[10px] text-slate-400">Current: 36.5h (Passed)</span>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">Security Vulnerabilities</span>
                  <span className="text-emerald-600 text-xs font-bold">✓ PASS</span>
                </div>
                <div className="text-xs text-slate-500">Rule: 0 Critical CWE CVEs allowed</div>
                <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full w-[100%]" />
                </div>
                <span className="text-[10px] text-slate-400">0 Critical flaws detected</span>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">Duplicate Code Ratio</span>
                  <span className="text-emerald-600 text-xs font-bold">✓ PASS</span>
                </div>
                <div className="text-xs text-slate-500">Rule: Max 5% duplication limit</div>
                <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full w-[84%]" />
                </div>
                <span className="text-[10px] text-slate-400">Current: 4.2% (Passed)</span>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: Education & Classroom Hub */}
        {activeViewTab === 'edu' && (
          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <GraduationCap className="w-5 h-5 text-indigo-600" />
                  <span>Lecturer Dashboard & Academic Submissions</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1">Dedicated module for STEM professors, universities, and coding bootcamps.</p>
              </div>
              <span className="px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-mono font-bold border border-indigo-200">
                Course: CS-204 Data Structures & Algorithms
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-xs text-slate-500">Active Students Enrolled</span>
                <div className="text-2xl font-bold text-slate-900">86 / 100 Seats</div>
                <p className="text-[11px] text-slate-400">14 spare student license tokens</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-xs text-slate-500">Lab Assignments Graded</span>
                <div className="text-2xl font-bold text-indigo-600">344 Submissions</div>
                <p className="text-[11px] text-slate-400">Automated feedback generated</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-xs text-slate-500">Average Class Quality Grade</span>
                <div className="text-2xl font-bold text-emerald-600">88.4% (Grade A-)</div>
                <p className="text-[11px] text-slate-400">Similarity & plagiarism index &lt; 2%</p>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
