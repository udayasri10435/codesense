import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  BarChart3, 
  Zap, 
  Clock, 
  Server, 
  TrendingUp, 
  CheckCircle2, 
  AlertCircle, 
  Play, 
  RefreshCw, 
  Cpu, 
  Layers, 
  ShieldCheck,
  Radio,
  ArrowRight,
  Terminal,
  Check
} from 'lucide-react';
import { LicenseUsageStats, SerialLicense, PlanId } from '../types';

interface UsageStatisticsDashboardProps {
  initialLicenseKey?: string;
  availableLicenses?: SerialLicense[];
  onOpenSandboxWithKey?: (key: string) => void;
}

export const UsageStatisticsDashboard: React.FC<UsageStatisticsDashboardProps> = ({
  initialLicenseKey = 'CODESENSE-PRO-AAD8CB1F',
  availableLicenses = [],
  onOpenSandboxWithKey,
}) => {
  const [selectedKey, setSelectedKey] = useState<string>(initialLicenseKey);
  const [stats, setStats] = useState<LicenseUsageStats | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [liveStreaming, setLiveStreaming] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'endpoints' | 'machines' | 'logs'>('overview');
  const [selectedEndpointForPing, setSelectedEndpointForPing] = useState<string>('/api/analyze');
  const [lastPingResult, setLastPingResult] = useState<any | null>(null);

  // Sync if initial key changes
  useEffect(() => {
    if (initialLicenseKey && initialLicenseKey !== selectedKey) {
      setSelectedKey(initialLicenseKey);
    }
  }, [initialLicenseKey]);

  // Fetch usage stats whenever selected key changes
  const fetchUsageStats = async (keyToFetch?: string) => {
    const key = (keyToFetch || selectedKey || '').trim();
    if (!key) return;

    setIsLoading(true);
    try {
      const res = await fetch(`/api/licenses/usage-stats?licenseKey=${encodeURIComponent(key)}`);
      const data = await res.json();
      if (data.success && data.stats) {
        setStats(data.stats);
      }
    } catch (err) {
      console.error('Error fetching usage stats:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUsageStats(selectedKey);
  }, [selectedKey]);

  // Live streaming interval
  useEffect(() => {
    let timer: any = null;
    if (liveStreaming) {
      timer = setInterval(() => {
        fetchUsageStats(selectedKey);
      }, 4000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [liveStreaming, selectedKey]);

  // Send a live API ping to increment counter and see real-time updates
  const handleSendLivePing = async () => {
    if (!selectedKey) return;
    setIsSimulating(true);
    try {
      const res = await fetch('/api/licenses/record-call', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          licenseKey: selectedKey,
          endpoint: selectedEndpointForPing,
          method: 'POST',
          latencyMs: Math.floor(18 + Math.random() * 45),
          statusCode: 200,
          host: 'developer-workstation',
        }),
      });
      const data = await res.json();
      if (data.success) {
        setLastPingResult(data.recorded);
        if (data.stats) {
          setStats(data.stats);
        }
      }
    } catch (err) {
      console.error('Ping error:', err);
    } finally {
      setIsSimulating(false);
    }
  };

  // Compute maximum calls in timeline for height scaling
  const maxCallsInTimeline = stats?.timeline
    ? Math.max(...stats.timeline.map((t) => t.calls), 1)
    : 100;

  const getTierColor = (planId?: PlanId) => {
    switch (planId) {
      case 'free':
        return { bg: 'bg-emerald-50 text-emerald-700 border-emerald-200', bar: 'bg-emerald-500' };
      case 'pro':
        return { bg: 'bg-indigo-50 text-indigo-700 border-indigo-200', bar: 'bg-indigo-600' };
      case 'team':
        return { bg: 'bg-sky-50 text-sky-700 border-sky-200', bar: 'bg-sky-600' };
      case 'enterprise':
        return { bg: 'bg-purple-50 text-purple-700 border-purple-200', bar: 'bg-purple-600' };
      case 'education':
        return { bg: 'bg-amber-50 text-amber-700 border-amber-200', bar: 'bg-amber-600' };
      default:
        return { bg: 'bg-slate-50 text-slate-700 border-slate-200', bar: 'bg-slate-600' };
    }
  };

  const tierTheme = getTierColor(stats?.planId);

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden space-y-6">
      
      {/* Top Header Bar */}
      <div className="p-6 border-b border-slate-100 bg-slate-900 text-white flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-400">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                <span>Usage Statistics & Performance Metrics</span>
                {liveStreaming && (
                  <span className="flex items-center gap-1 text-[11px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 animate-pulse">
                    <Radio className="w-3 h-3" />
                    LIVE
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Real-time API invocation monitoring, throughput telemetry, and latency distributions.
              </p>
            </div>
          </div>
        </div>

        {/* License Key Selector & Live Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {availableLicenses.length > 1 && (
            <div className="relative">
              <select
                value={selectedKey}
                onChange={(e) => setSelectedKey(e.target.value)}
                className="bg-slate-800 border border-slate-700 text-white text-xs rounded-xl px-3 py-2 font-mono focus:outline-none focus:border-indigo-500 cursor-pointer"
              >
                {availableLicenses.map((lic) => (
                  <option key={lic.licenseKey} value={lic.licenseKey}>
                    {lic.planName} — {lic.licenseKey.substring(0, 18)}...
                  </option>
                ))}
              </select>
            </div>
          )}

          <button
            onClick={() => setLiveStreaming(!liveStreaming)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer border ${
              liveStreaming
                ? 'bg-emerald-600 text-white border-emerald-500 shadow-xs'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
          >
            <Radio className={`w-3.5 h-3.5 ${liveStreaming ? 'animate-pulse' : ''}`} />
            <span>{liveStreaming ? 'Live Polling Active' : 'Enable Live Feed'}</span>
          </button>

          <button
            onClick={() => fetchUsageStats()}
            disabled={isLoading}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs transition-colors cursor-pointer disabled:opacity-50"
            title="Refresh statistics"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      <div className="px-6 space-y-6">

        {/* Active Key Info Strip */}
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-slate-500 font-medium">Monitoring License:</span>
            <span className="font-mono font-bold text-slate-900 bg-white px-2.5 py-1 rounded-lg border border-slate-200 shadow-2xs">
              {stats?.licenseKey || selectedKey}
            </span>
            <span className={`px-2 py-0.5 rounded-full font-bold uppercase text-[10px] border ${tierTheme.bg}`}>
              {stats?.planName || 'Pro'}
            </span>
          </div>

          <div className="flex items-center gap-4 text-slate-600 font-mono text-[11px]">
            <div>
              <span className="text-slate-400">Billing Cycle:</span> Monthly
            </div>
            <div>
              <span className="text-slate-400">Quota Resets:</span> {stats?.cycleResetDate || 'Next Month'}
            </div>
          </div>
        </div>

        {/* KPI Metric Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Card 1: API Calls & Quota */}
          <div className="p-4 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-medium">Total API Invocations</span>
              <Activity className="w-4 h-4 text-indigo-600" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-slate-900 font-mono">
                {stats?.totalCallsCurrentMonth.toLocaleString() || '0'}
              </span>
              <span className="text-xs text-slate-400 font-mono">
                / {stats?.monthlyQuota === 'Unlimited' ? '∞' : stats?.monthlyQuota?.toLocaleString() || '50,000'}
              </span>
            </div>
            {/* Progress bar */}
            <div className="space-y-1 pt-1">
              <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                <div 
                  className={`h-full transition-all duration-500 ${tierTheme.bar}`} 
                  style={{ width: `${Math.min(100, stats?.percentageUsed || 0)}%` }} 
                />
              </div>
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>{stats?.percentageUsed || 0}% quota used</span>
                <span>{stats?.monthlyQuota === 'Unlimited' ? 'No Hard Cap' : 'Hard Cap Enforced'}</span>
              </div>
            </div>
          </div>

          {/* Card 2: Latency Performance */}
          <div className="p-4 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-medium">Avg API Latency</span>
              <Clock className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-slate-900 font-mono">
                {stats?.avgLatencyMs || 38}
                <span className="text-sm font-normal text-slate-500">ms</span>
              </span>
              <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                P50 Optimal
              </span>
            </div>
            <div className="pt-1 flex items-center justify-between text-[11px] text-slate-500 font-mono border-t border-slate-100">
              <span>P95: <strong>{stats?.p95LatencyMs || 76}ms</strong></span>
              <span>P99: <strong>{stats?.p99LatencyMs || 118}ms</strong></span>
            </div>
          </div>

          {/* Card 3: Throughput & Rate Limit */}
          <div className="p-4 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-medium">Current Throughput</span>
              <Zap className="w-4 h-4 text-amber-500" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-slate-900 font-mono">
                {stats?.currentQps || '0.82'}
                <span className="text-sm font-normal text-slate-500"> QPS</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                Peak: {stats?.peakThroughputRpm || 86} RPM
              </span>
            </div>
            <div className="pt-1 flex items-center justify-between text-[11px] text-slate-500 font-mono border-t border-slate-100">
              <span>Rate Limit:</span>
              <span className="font-bold text-slate-900">{stats?.rateLimitPerMinute || 120} req/min</span>
            </div>
          </div>

          {/* Card 4: Uptime & Reliability */}
          <div className="p-4 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-medium">Reliability & Cache</span>
              <CheckCircle2 className="w-4 h-4 text-indigo-600" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-emerald-600 font-mono">
                {stats?.uptimePercentage || 99.98}%
              </span>
              <span className="text-[11px] font-bold text-slate-500">Uptime</span>
            </div>
            <div className="pt-1 flex items-center justify-between text-[11px] text-slate-500 font-mono border-t border-slate-100">
              <span>AST Cache Hit:</span>
              <span className="font-bold text-indigo-600">{stats?.cacheHitRatio || 88.4}%</span>
            </div>
          </div>

        </div>

        {/* Live Traffic Simulator Bar */}
        <div className="p-4 rounded-xl bg-indigo-50/70 border border-indigo-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0">
              <Play className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-indigo-950">Test Live API Ping & Telemetry Trigger</h4>
              <p className="text-[11px] text-indigo-700">
                Simulate an authenticated API call with this key to observe live latency and increment metrics.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedEndpointForPing}
              onChange={(e) => setSelectedEndpointForPing(e.target.value)}
              className="bg-white border border-indigo-200 text-xs text-slate-800 rounded-lg px-2.5 py-1.5 font-mono focus:outline-none focus:border-indigo-600"
            >
              <option value="/api/analyze">POST /api/analyze (AST Code Scan)</option>
              <option value="/api/gemini/audit">POST /api/gemini/audit (Deep Thinking)</option>
              <option value="/api/licenses/verify">POST /api/licenses/verify (Signature Auth)</option>
              <option value="/api/refactor/simulate">POST /api/refactor/simulate (AST Engine)</option>
            </select>

            <button
              onClick={handleSendLivePing}
              disabled={isSimulating}
              className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer disabled:opacity-50 shadow-xs shrink-0"
            >
              <Zap className={`w-3.5 h-3.5 ${isSimulating ? 'animate-spin' : ''}`} />
              <span>{isSimulating ? 'Sending Ping...' : 'Send Live Ping'}</span>
            </button>
          </div>
        </div>

        {/* Last Ping Confirmation */}
        {lastPingResult && (
          <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center justify-between font-mono">
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>
                Ping recorded: <strong>{lastPingResult.endpoint}</strong> ({lastPingResult.method}) • Status: <strong>{lastPingResult.statusCode} OK</strong> • Latency: <strong>{lastPingResult.latencyMs}ms</strong>
              </span>
            </div>
            <span className="text-[10px] text-emerald-600">{new Date(lastPingResult.timestamp).toLocaleTimeString()}</span>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 gap-6 text-xs font-semibold">
          {[
            { id: 'overview', label: '24-Hour Traffic Curve', icon: BarChart3 },
            { id: 'endpoints', label: 'Endpoint Breakdown', icon: Layers },
            { id: 'machines', label: 'Workstation Nodes', icon: Cpu },
            { id: 'logs', label: 'Recent API Requests', icon: Terminal },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`pb-3 flex items-center gap-1.5 transition-colors cursor-pointer border-b-2 ${
                  activeTab === tab.id
                    ? 'border-indigo-600 text-indigo-600 font-bold'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab 1: 24-Hour Traffic Curve Chart */}
        {activeTab === 'overview' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs">
              <div>
                <h4 className="font-bold text-slate-900">24-Hour Invocations & Latency Profile</h4>
                <p className="text-slate-500 text-[11px]">Hourly query volume distribution across the last 24 hours.</p>
              </div>
              <div className="flex items-center gap-3 text-[11px] font-mono text-slate-500">
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded bg-indigo-600 inline-block" />
                  API Calls
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded bg-emerald-500 inline-block" />
                  Avg Latency
                </span>
              </div>
            </div>

            {/* Interactive Bar Chart Visualization */}
            <div className="p-4 rounded-xl bg-slate-900 text-white space-y-4">
              <div className="h-44 flex items-end gap-1 sm:gap-2 pt-6 pb-2 px-2 border-b border-slate-800">
                {stats?.timeline.map((point, idx) => {
                  const heightPercent = Math.min(100, Math.max(12, Math.round((point.calls / maxCallsInTimeline) * 100)));
                  return (
                    <div
                      key={idx}
                      className="flex-1 flex flex-col items-center gap-1.5 group relative cursor-pointer"
                    >
                      {/* Tooltip on hover */}
                      <div className="absolute -top-16 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-800 text-white text-[10px] p-1.5 rounded shadow-lg border border-slate-700 whitespace-nowrap z-20 pointer-events-none font-mono">
                        <div>Time: {point.time}</div>
                        <div className="text-indigo-400 font-bold">Calls: {point.calls}</div>
                        <div className="text-emerald-400">P95: {point.p95LatencyMs}ms</div>
                      </div>

                      {/* Bar */}
                      <div 
                        className="w-full rounded-t-sm bg-gradient-to-t from-indigo-600 to-indigo-400 group-hover:from-indigo-500 group-hover:to-indigo-300 transition-all"
                        style={{ height: `${heightPercent}%` }}
                      />
                    </div>
                  );
                })}
              </div>

              {/* X-axis labels */}
              <div className="flex justify-between text-[10px] text-slate-400 font-mono px-2">
                <span>{stats?.timeline[0]?.time || '24h ago'}</span>
                <span>{stats?.timeline[12]?.time || '12h ago'}</span>
                <span>{stats?.timeline[stats.timeline.length - 1]?.time || 'Now'}</span>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Endpoint Breakdown */}
        {activeTab === 'endpoints' && (
          <div className="space-y-4">
            <div className="text-xs text-slate-500">
              Distribution of requests, performance metrics, and success rates across API endpoints.
            </div>

            <div className="space-y-3">
              {stats?.endpoints.map((ep) => {
                const percentage = stats.totalCallsCurrentMonth > 0
                  ? Math.round((ep.count / stats.totalCallsCurrentMonth) * 100)
                  : 0;

                return (
                  <div key={ep.endpoint} className="p-4 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-2">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs">
                      <div>
                        <span className="font-mono font-bold text-indigo-700">{ep.endpoint}</span>
                        <span className="text-slate-500 ml-2">({ep.name})</span>
                      </div>
                      <div className="flex items-center gap-3 font-mono text-[11px] text-slate-600">
                        <span><strong>{ep.count.toLocaleString()}</strong> calls ({percentage}%)</span>
                        <span className="text-emerald-600">Avg {ep.avgLatencyMs}ms</span>
                        <span className="px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
                          {ep.successRate}% Success
                        </span>
                      </div>
                    </div>

                    <div className="w-full h-1.5 rounded-full bg-slate-100 overflow-hidden">
                      <div className="h-full bg-indigo-600 rounded-full" style={{ width: `${percentage}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 3: Machine & Node Attribution */}
        {activeTab === 'machines' && (
          <div className="space-y-4">
            <div className="text-xs text-slate-500">
              Traffic attribution per bound developer workstation and CI/CD node under this license.
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {stats?.machineAttribution.map((m) => (
                <div key={m.machineId} className="p-4 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center text-slate-700">
                        <Server className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <h5 className="font-bold text-slate-900">{m.hostname}</h5>
                        <span className="font-mono text-[10px] text-slate-400">{m.machineId}</span>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold">
                      Active
                    </span>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex justify-between text-xs text-slate-600 font-mono">
                    <span>Calls Generated: <strong>{m.callsCount.toLocaleString()}</strong></span>
                    <span>Last Ping: {new Date(m.lastActive).toLocaleTimeString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 4: Recent Logs */}
        {activeTab === 'logs' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>Streaming the 10 most recent authenticated API invocations.</span>
              <span className="font-mono text-[11px] text-emerald-600">● Live Feed</span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 text-[11px]">
                  <tr>
                    <th className="p-3">Request ID</th>
                    <th className="p-3">Timestamp</th>
                    <th className="p-3">Endpoint</th>
                    <th className="p-3">Method</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Latency</th>
                    <th className="p-3">Client Host</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {stats?.recentActivityLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-bold text-slate-900">{log.id}</td>
                      <td className="p-3 text-slate-500">{new Date(log.timestamp).toLocaleTimeString()}</td>
                      <td className="p-3 text-indigo-600 font-bold">{log.endpoint}</td>
                      <td className="p-3">
                        <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-bold">
                          {log.method}
                        </span>
                      </td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold">
                          {log.statusCode} OK
                        </span>
                      </td>
                      <td className="p-3 text-slate-700">{log.latencyMs}ms</td>
                      <td className="p-3 text-slate-400">{log.ipOrHost}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

      </div>

      {/* Footer Strip with CLI shortcut */}
      <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-slate-400" />
          <span>Monitor live telemetry via CodeSense CLI:</span>
          <code className="bg-white border border-slate-200 px-2 py-0.5 rounded font-mono text-slate-800 text-[11px]">
            codesense telemetry --key {stats?.licenseKey || selectedKey} --live
          </code>
        </div>

        {onOpenSandboxWithKey && (
          <button
            onClick={() => onOpenSandboxWithKey(stats?.licenseKey || selectedKey)}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
          >
            <span>Open in CLI Sandbox</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

    </div>
  );
};
