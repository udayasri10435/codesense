import React, { useState, useEffect } from 'react';
import { X, Check, Activity, Sparkles, TrendingUp, Save, Sliders, ShieldAlert, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';
import { WindowsDownloadStats } from '../types';

interface SetDownloadCountModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTotal: number;
  currentToday?: number;
  onCountUpdated: (newStats: WindowsDownloadStats) => void;
}

export const SetDownloadCountModal: React.FC<SetDownloadCountModalProps> = ({
  isOpen,
  onClose,
  currentTotal,
  currentToday = 0,
  onCountUpdated,
}) => {
  const [totalInput, setTotalInput] = useState<string>(currentTotal.toString());
  const [todayInput, setTodayInput] = useState<string>(currentToday.toString());
  const [isSaving, setIsSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setTotalInput(currentTotal.toString());
      setTodayInput(currentToday.toString());
      setSuccessMsg(null);
      setErrorMsg(null);
    }
  }, [isOpen, currentTotal, currentToday]);

  if (!isOpen) return null;

  const presets = [
    { label: '0 (Reset to Zero)', total: 0, today: 0 },
    { label: '100 Launch', total: 100, today: 15 },
    { label: '1,000 Early', total: 1000, today: 45 },
    { label: '5,000 Milestone', total: 5000, today: 175 },
    { label: '10,000 Verified', total: 10000, today: 340 },
    { label: '50,000 Enterprise', total: 50000, today: 1540 },
  ];

  const handleApplyPreset = (presetTotal: number, presetToday: number) => {
    setTotalInput(presetTotal.toString());
    setTodayInput(presetToday.toString());
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsedTotal = parseInt(totalInput.replace(/,/g, '').trim(), 10);
    const parsedToday = parseInt(todayInput.replace(/,/g, '').trim(), 10);

    if (isNaN(parsedTotal) || parsedTotal < 0) {
      setErrorMsg('Please enter a valid non-negative number for Total Downloads.');
      return;
    }

    setIsSaving(true);
    setErrorMsg(null);

    try {
      // Save locally to localStorage first for instant client persistence
      const localBackup = {
        totalDownloads: parsedTotal,
        todayDownloads: isNaN(parsedToday) ? 0 : parsedToday,
        lastUpdated: new Date().toISOString(),
      };
      localStorage.setItem('codesense_custom_downloads', JSON.stringify(localBackup));

      // Sync with server API endpoint
      const res = await fetch('/api/downloads/set-count', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          totalDownloads: parsedTotal,
          todayDownloads: isNaN(parsedToday) ? 0 : parsedToday,
        }),
      });

      const data = await res.json();

      if (data.success && data.stats) {
        onCountUpdated(data.stats);
      } else {
        // Fallback optimistic object
        const fallbackStats: WindowsDownloadStats = {
          totalDownloads: parsedTotal,
          todayDownloads: isNaN(parsedToday) ? 0 : parsedToday,
          version: '2.4.0-Release (Build #4892)',
          releaseName: 'Code Sence Windows Desktop & Local Engine',
          fileSize: '48.2 MB',
          freeStartingPoints: 1000,
          downloadUrl: 'https://drive.google.com/file/d/10C5aBQRInoeCRzAMedUm9mBjhwBQiQ03/view?usp=sharing',
          executionFile: 'run.bat',
          sha256Checksum: 'd8f2a4198ec0028a49c951fa69e0018f29402ab8419ef2018a1a9e87189fa91b',
          compatibility: ['Windows 11', 'Windows 10', 'Windows Server'],
          lastUpdated: new Date().toISOString(),
        };
        onCountUpdated(fallbackStats);
      }

      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 }
      });

      setSuccessMsg(`Download count calibrated to ${parsedTotal.toLocaleString()}!`);
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (err: any) {
      console.error('Error saving download count:', err);
      // Still apply locally
      const fallbackStats: WindowsDownloadStats = {
        totalDownloads: parsedTotal,
        todayDownloads: isNaN(parsedToday) ? 0 : parsedToday,
        version: '2.4.0-Release (Build #4892)',
        releaseName: 'Code Sence Windows Desktop & Local Engine',
        fileSize: '48.2 MB',
        freeStartingPoints: 1000,
        downloadUrl: 'https://drive.google.com/file/d/10C5aBQRInoeCRzAMedUm9mBjhwBQiQ03/view?usp=sharing',
        executionFile: 'run.bat',
        sha256Checksum: 'd8f2a4198ec0028a49c951fa69e0018f29402ab8419ef2018a1a9e87189fa91b',
        compatibility: ['Windows 11', 'Windows 10', 'Windows Server'],
        lastUpdated: new Date().toISOString(),
      };
      onCountUpdated(fallbackStats);
      setSuccessMsg(`Download count updated to ${parsedTotal.toLocaleString()} locally.`);
      setTimeout(() => {
        onClose();
      }, 1200);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div 
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden text-left animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-slate-900 text-white p-6 relative overflow-hidden">
          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center">
                <Sliders className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Set Correct Amount of Downloads</h3>
                <p className="text-xs text-slate-400">
                  Calibrate the real-time download telemetry counter
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body */}
        <form onSubmit={handleSave} className="p-6 space-y-5">
          {successMsg && (
            <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Quick Presets */}
          <div>
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
              Quick Calibration Presets
            </label>
            <div className="flex flex-wrap gap-2">
              {presets.map((p, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleApplyPreset(p.total, p.today)}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 hover:border-indigo-200 border border-slate-200 text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Input Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-emerald-600" />
                <span>Total Downloads</span>
              </label>
              <input
                type="number"
                min="0"
                step="1"
                value={totalInput}
                onChange={(e) => setTotalInput(e.target.value)}
                placeholder="e.g. 4892"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-sm font-mono font-bold text-slate-900"
                required
              />
              <p className="text-[11px] text-slate-500">Live baseline count</p>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-indigo-600" />
                <span>Today's Downloads</span>
              </label>
              <input
                type="number"
                min="0"
                step="1"
                value={todayInput}
                onChange={(e) => setTodayInput(e.target.value)}
                placeholder="e.g. 148"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-sm font-mono font-bold text-slate-900"
              />
              <p className="text-[11px] text-slate-500">Today's velocity</p>
            </div>
          </div>

          {/* Real-time Preview Pill */}
          <div className="p-3.5 rounded-2xl bg-slate-900 text-white flex items-center justify-between text-xs">
            <span className="text-slate-400">Live Preview:</span>
            <div className="flex items-center gap-2 font-mono font-bold text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>{parseInt(totalInput.replace(/,/g, '') || '0', 10).toLocaleString()} Verified Downloads</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-2 transition-all shadow-md cursor-pointer disabled:opacity-50"
            >
              {isSaving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              <span>{isSaving ? 'Saving...' : 'Apply & Save Count'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
