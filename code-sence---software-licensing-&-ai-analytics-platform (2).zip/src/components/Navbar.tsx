import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, KeyRound, Terminal, CreditCard, Sparkles, Search, 
  Layers, Key, LogIn, LogOut, User, ChevronDown, CheckCircle2, BrainCircuit, Activity,
  Download, Laptop
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { LiveDownloadCounter } from './LiveDownloadCounter';

import { SerialLicense } from '../types';

interface NavbarProps {
  activeTab: 'home' | 'pricing' | 'download' | 'sandbox' | 'verifier' | 'portal' | 'features' | 'ai-audit';
  setActiveTab: (tab: 'home' | 'pricing' | 'download' | 'sandbox' | 'verifier' | 'portal' | 'features' | 'ai-audit') => void;
  onOpenCheckout: (planId?: any) => void;
  onOpenDownloadModal?: () => void;
  downloadCount?: number;
  activeLicense?: SerialLicense | null;
  onOpenSerialModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  activeTab, 
  setActiveTab, 
  onOpenCheckout,
  onOpenDownloadModal,
  downloadCount = 0,
  activeLicense,
  onOpenSerialModal
}) => {
  const { user, openLoginModal, logout } = useAuth();
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const displayDownloads = (typeof downloadCount === 'number' && !isNaN(downloadCount)) 
    ? downloadCount.toLocaleString() 
    : '0';

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        <div className="flex items-center justify-between h-18">
          {/* Brand Logo */}
          <div 
            id="nav-brand-logo"
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl overflow-hidden shadow-sm flex items-center justify-center bg-indigo-600 group-hover:scale-105 transition-transform">
              <img 
                src="/favicon.svg" 
                alt="Code Sence Logo" 
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold tracking-tight text-slate-900">Code Sence</span>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                  v2.4
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium hidden sm:block">AI Intelligence &amp; Software Engine</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center gap-4 lg:gap-6 text-sm font-medium text-slate-600">
            <button
              id="nav-tab-home"
              onClick={() => setActiveTab('home')}
              className={`transition-colors py-1 ${
                activeTab === 'home' 
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600' 
                  : 'hover:text-indigo-600'
              }`}
            >
              Overview
            </button>

            {/* Windows Tool Download Tab */}
            <button
              id="nav-tab-download"
              onClick={() => setActiveTab('download')}
              className={`transition-colors py-1 flex items-center gap-1.5 ${
                activeTab === 'download' 
                  ? 'text-emerald-600 font-bold border-b-2 border-emerald-600' 
                  : 'text-emerald-700 hover:text-emerald-800'
              }`}
            >
              <Laptop className="w-4 h-4 text-emerald-600" />
              <span>Windows Tool</span>
              <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded-full font-bold">
                run.bat
              </span>
            </button>

            <button
              id="nav-tab-pricing"
              onClick={() => setActiveTab('pricing')}
              className={`transition-colors py-1 flex items-center gap-1.5 ${
                activeTab === 'pricing' 
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600' 
                  : 'hover:text-indigo-600'
              }`}
            >
              <CreditCard className="w-4 h-4 text-slate-400" />
              <span>Pricing</span>
            </button>

            <button
              id="nav-tab-sandbox"
              onClick={() => setActiveTab('sandbox')}
              className={`transition-colors py-1 flex items-center gap-1.5 ${
                activeTab === 'sandbox' 
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600' 
                  : 'hover:text-indigo-600'
              }`}
            >
              <Terminal className="w-4 h-4 text-slate-400" />
              <span>Sandbox</span>
            </button>
            <button
              id="nav-tab-verifier"
              onClick={() => setActiveTab('verifier')}
              className={`transition-colors py-1 flex items-center gap-1.5 ${
                activeTab === 'verifier' 
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600' 
                  : 'hover:text-indigo-600'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-slate-400" />
              <span>Verify</span>
            </button>
            <button
              id="nav-tab-features"
              onClick={() => setActiveTab('features')}
              className={`transition-colors py-1 flex items-center gap-1.5 ${
                activeTab === 'features' 
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600' 
                  : 'hover:text-indigo-600'
              }`}
            >
              <Layers className="w-4 h-4 text-slate-400" />
              <span>Specs</span>
            </button>
            <button
              id="nav-tab-portal"
              onClick={() => setActiveTab('portal')}
              className={`transition-colors py-1 flex items-center gap-1.5 ${
                activeTab === 'portal' 
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600' 
                  : 'hover:text-indigo-600'
              }`}
            >
              <Search className="w-4 h-4 text-slate-400" />
              <span>Portal</span>
            </button>
            <button
              id="nav-tab-ai-audit"
              onClick={() => setActiveTab('ai-audit')}
              className={`transition-colors py-1 flex items-center gap-1.5 ${
                activeTab === 'ai-audit' 
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600' 
                  : 'hover:text-indigo-600'
              }`}
            >
              <BrainCircuit className="w-4 h-4 text-indigo-500" />
              <span className="font-bold text-indigo-600">Deep AI</span>
            </button>
          </nav>

          {/* Action Buttons & Auth */}
          <div className="flex items-center gap-2.5">
            {/* Active Purchased Serial Code Badge & Quick-View */}
            {activeLicense && (
              <button
                id="nav-btn-my-serial-code"
                onClick={onOpenSerialModal}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-indigo-900 to-slate-900 hover:from-indigo-800 hover:to-slate-800 text-white border border-indigo-500/50 text-xs font-bold shadow-sm transition-all cursor-pointer animate-pulse hover:animate-none"
                title="Click to view and copy your purchased serial code"
              >
                <Key className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline text-indigo-200">Serial:</span>
                <span className="font-mono text-emerald-300 text-[11px]">
                  {activeLicense.licenseKey.slice(0, 10)}...
                </span>
              </button>
            )}

            {/* Direct Windows Download Header Button */}
            <button
              id="nav-btn-download-quick"
              onClick={() => {
                if (onOpenDownloadModal) onOpenDownloadModal();
                else setActiveTab('download');
              }}
              className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 text-xs font-bold transition-all cursor-pointer shadow-2xs"
            >
              <Download className="w-3.5 h-3.5 text-emerald-600" />
              <span>Windows Tool</span>
              <span className="flex items-center gap-1 bg-emerald-200/80 text-emerald-950 px-2 py-0.5 rounded-full font-mono text-[11px]">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-ping" />
                <span>{downloadCount.toLocaleString()}</span>
              </span>
            </button>

            {/* Google Authentication Control */}
            {user ? (
              <div className="relative">
                <button
                  id="btn-user-profile-menu"
                  onClick={() => setIsProfileDropdownOpen(!isProfileDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 pr-2.5 rounded-full bg-slate-100 hover:bg-slate-200 border border-slate-200 transition-colors cursor-pointer"
                >
                  <img
                    src={user.picture || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(user.name)}`}
                    alt={user.name}
                    className="w-7 h-7 rounded-full border border-white shadow-2xs"
                    referrerPolicy="no-referrer"
                  />
                  <span className="text-xs font-semibold text-slate-800 max-w-[90px] sm:max-w-[120px] truncate">
                    {user.name.split(' ')[0]}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                </button>

                {/* Dropdown Menu */}
                {isProfileDropdownOpen && (
                  <>
                    <div 
                      className="fixed inset-0 z-30" 
                      onClick={() => setIsProfileDropdownOpen(false)} 
                    />
                    <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-white border border-slate-200 shadow-xl z-40 p-3 space-y-2 animate-in fade-in zoom-in-95 duration-100">
                      <div className="p-2 bg-slate-50 rounded-xl border border-slate-100 flex items-center gap-2.5">
                        <img
                          src={user.picture || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(user.name)}`}
                          alt={user.name}
                          className="w-9 h-9 rounded-full border border-white"
                          referrerPolicy="no-referrer"
                        />
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-bold text-slate-900 truncate">{user.name}</p>
                          <p className="text-[10px] text-slate-500 truncate font-mono">{user.email}</p>
                          <div className="flex items-center gap-1 mt-0.5">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span className="text-[9px] font-semibold text-emerald-700">Google Account Verified</span>
                          </div>
                        </div>
                      </div>

                      <div className="pt-1 space-y-1">
                        <button
                          onClick={() => {
                            setActiveTab('download');
                            setIsProfileDropdownOpen(false);
                          }}
                          className="w-full px-3 py-2 text-left text-xs font-medium text-emerald-800 hover:bg-emerald-50 rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Download Windows Tool (run.bat)</span>
                        </button>
                        <button
                          onClick={() => {
                            setActiveTab('portal');
                            setIsProfileDropdownOpen(false);
                          }}
                          className="w-full px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
                        >
                          <Search className="w-3.5 h-3.5 text-slate-400" />
                          <span>My Registered Licenses</span>
                        </button>
                        <button
                          onClick={() => {
                            setActiveTab('portal');
                            setIsProfileDropdownOpen(false);
                          }}
                          className="w-full px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
                        >
                          <Activity className="w-3.5 h-3.5 text-indigo-500" />
                          <span>Usage Statistics & Telemetry</span>
                        </button>
                        <button
                          onClick={() => {
                            setActiveTab('sandbox');
                            setIsProfileDropdownOpen(false);
                          }}
                          className="w-full px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
                        >
                          <Terminal className="w-3.5 h-3.5 text-slate-400" />
                          <span>Launch Developer CLI</span>
                        </button>
                      </div>

                      <div className="border-t border-slate-100 pt-1">
                        <button
                          onClick={() => {
                            logout();
                            setIsProfileDropdownOpen(false);
                          }}
                          className="w-full px-3 py-2 text-left text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
                        >
                          <LogOut className="w-3.5 h-3.5" />
                          <span>Sign Out</span>
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <button
                id="nav-btn-google-login"
                onClick={openLoginModal}
                className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 text-xs font-bold shadow-2xs hover:border-slate-400 transition-all cursor-pointer transform active:scale-95"
              >
                {/* Google G SVG */}
                <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Google Sign In</span>
              </button>
            )}

            <button
              id="nav-action-get-license"
              onClick={() => onOpenCheckout('pro')}
              className="px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-indigo-600 rounded-full shadow-sm hover:bg-indigo-700 flex items-center gap-1.5 transition-all transform active:scale-95 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Get License</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

