import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Key, 
  Download, 
  Copy, 
  Check, 
  ShieldCheck, 
  Mail, 
  RefreshCw, 
  AlertCircle, 
  FileText, 
  CheckCircle2, 
  LogIn, 
  Activity, 
  BarChart3, 
  ArrowUpRight 
} from 'lucide-react';
import { SerialLicense } from '../types';
import { useAuth } from '../context/AuthContext';
import { UsageStatisticsDashboard } from './UsageStatisticsDashboard';

interface LicenseManagerProps {
  onOpenSandboxWithKey: (key: string) => void;
  onOpenCheckout: (planId?: string) => void;
  onViewEmailReceipt: (emailData: any) => void;
}

export const LicenseManager: React.FC<LicenseManagerProps> = ({
  onOpenSandboxWithKey,
  onOpenCheckout,
  onViewEmailReceipt,
}) => {
  const { user, openLoginModal } = useAuth();
  const [activeView, setActiveView] = useState<'licenses' | 'usage'>('licenses');
  const [selectedKeyForUsage, setSelectedKeyForUsage] = useState<string>('');
  const [emailInput, setEmailInput] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [licenses, setLicenses] = useState<SerialLicense[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Auto-load purchased licenses from local storage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem('codesense_my_licenses');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setLicenses(parsed);
          setHasSearched(true);
          setSelectedKeyForUsage(parsed[0].licenseKey);
        }
      } else {
        const lastLic = localStorage.getItem('codesense_last_license');
        if (lastLic) {
          const parsed = JSON.parse(lastLic);
          if (parsed && parsed.licenseKey) {
            setLicenses([parsed]);
            setHasSearched(true);
            setSelectedKeyForUsage(parsed.licenseKey);
          }
        }
      }
    } catch (e) {}
  }, []);

  // Auto-search for authenticated Google user's licenses
  useEffect(() => {
    if (user?.email) {
      setEmailInput(user.email);
      handleSearch(user.email);
    }
  }, [user]);

  const handleSearch = async (emailToSearch?: string) => {
    const email = (emailToSearch || emailInput).trim();
    if (!email) return;

    setIsSearching(true);
    try {
      const res = await fetch(`/api/licenses/lookup?email=${encodeURIComponent(email)}`);
      const data = await res.json();
      const loadedLicenses = data.licenses || [];
      setLicenses(loadedLicenses);
      setHasSearched(true);
      if (loadedLicenses.length > 0) {
        setSelectedKeyForUsage(loadedLicenses[0].licenseKey);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearching(false);
    }
  };

  const handleCopy = (key: string) => {
    navigator.clipboard.writeText(key);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleInspectUsageForKey = (key: string) => {
    setSelectedKeyForUsage(key);
    setActiveView('usage');
  };

  const downloadLicenseFile = (lic: SerialLicense) => {
    const licContent = JSON.stringify({
      product: 'Code Sence Software Intelligence',
      serialKey: lic.licenseKey,
      plan: lic.planName,
      customer: lic.customerName,
      email: lic.customerEmail,
      limits: lic.limits,
      issuedAt: lic.createdAt,
      expiresAt: lic.expiresAt,
      signature: lic.digitalSignature,
    }, null, 2);

    const blob = new Blob([licContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `codesence-${lic.planId}-license.lic`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <section id="license-manager" className="py-16 bg-slate-50 min-h-screen">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold uppercase tracking-wider">
            <Search className="w-3.5 h-3.5" />
            <span>Customer Portal & Telemetry Hub</span>
          </div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            License Management & Usage Statistics
          </h2>
          <p className="text-slate-600 text-sm max-w-xl mx-auto">
            Retrieve your serial license keys, inspect real-time API call metrics, download activation certificates, and manage workstation quotas.
          </p>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex justify-center">
          <div className="inline-flex p-1.5 rounded-2xl bg-white border border-slate-200 shadow-2xs gap-1">
            <button
              onClick={() => setActiveView('licenses')}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                activeView === 'licenses'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Key className="w-4 h-4" />
              <span>My Licenses & Invoices ({licenses.length})</span>
            </button>

            <button
              onClick={() => setActiveView('usage')}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 ${
                activeView === 'usage'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Activity className="w-4 h-4" />
              <span>Usage Statistics & Performance Metrics</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Licenses & Invoices View */}
        {activeView === 'licenses' && (
          <div className="space-y-8">
            {/* Google Status Banner if logged in */}
            {user ? (
              <div className="p-4 rounded-2xl bg-indigo-50 border border-indigo-200 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={user.picture || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(user.name)}`}
                    alt={user.name}
                    className="w-10 h-10 rounded-full border border-white shadow-xs"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">{user.name}</span>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        Google Verified
                      </span>
                    </div>
                    <p className="text-xs text-indigo-700 font-mono">{user.email}</p>
                  </div>
                </div>
                <button
                  onClick={() => handleSearch(user.email)}
                  className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSearching ? 'animate-spin' : ''}`} />
                  <span>Sync Licenses</span>
                </button>
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-3 text-xs text-slate-700">
                  <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>Sign in with Google to automatically link and sync your CodeSense license keys and invoices.</span>
                </div>
                <button
                  onClick={openLoginModal}
                  className="px-3.5 py-1.5 rounded-full bg-white hover:bg-slate-50 border border-slate-300 text-xs font-bold text-slate-800 shrink-0 cursor-pointer shadow-2xs"
                >
                  Sign In with Google
                </button>
              </div>
            )}

            {/* Search Box */}
            <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Lookup Subscriptions by Customer Email
              </label>

              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <input
                    id="input-lookup-email"
                    type="email"
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder="e.g. alex.vance@techcorp.io"
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 focus:bg-white rounded-xl text-sm text-slate-900 focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 transition-all"
                  />
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                </div>

                <button
                  id="btn-search-licenses"
                  onClick={() => handleSearch()}
                  disabled={isSearching || !emailInput.trim()}
                  className="px-6 py-3 rounded-xl text-sm font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm flex items-center justify-center gap-2 disabled:opacity-50 transition-colors cursor-pointer"
                >
                  {isSearching ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                  <span>{isSearching ? 'Retrieving...' : 'Find My Keys'}</span>
                </button>
              </div>

              {/* Account Quick Fill if user has session or hint */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs text-slate-500">
                {user ? (
                  <button
                    onClick={() => {
                      setEmailInput(user.email);
                      handleSearch(user.email);
                    }}
                    className="px-2.5 py-1 rounded-md bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-[11px] font-semibold cursor-pointer flex items-center gap-1"
                  >
                    <Key className="w-3 h-3 text-indigo-600" />
                    <span>Search for {user.email}</span>
                  </button>
                ) : (
                  <span>Enter the customer email address used during Stripe or PayPal checkout.</span>
                )}
                
                <button
                  onClick={() => onOpenCheckout('pro')}
                  className="text-indigo-600 font-semibold hover:text-indigo-700 hover:underline cursor-pointer"
                >
                  Need to purchase a new key? Buy Plan →
                </button>
              </div>
            </div>

            {/* Results List */}
            {hasSearched && (
              <div className="space-y-4">
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>Found {licenses.length} active license key(s) for <strong>{emailInput}</strong></span>
                </div>

                {licenses.length > 0 ? (
                  licenses.map((lic) => (
                    <div
                      key={lic.licenseKey}
                      className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4 hover:border-slate-300 transition-colors"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
                            <Key className="w-5 h-5" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-base font-bold text-slate-900">CodeSense {lic.planName}</h4>
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                                {lic.status.toUpperCase()}
                              </span>
                            </div>
                            <p className="text-xs text-slate-500">
                              Invoice {lic.invoiceNumber} • Billed ${lic.amountPaid} USD ({lic.billingInterval})
                            </p>
                          </div>
                        </div>

                        <div className="text-right text-xs text-slate-500">
                          <div>Issued: {new Date(lic.createdAt).toLocaleDateString()}</div>
                          <div className="text-slate-400">Expires: {new Date(lic.expiresAt).toLocaleDateString()}</div>
                        </div>
                      </div>

                      {/* Key Display & Quick Actions */}
                      <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="font-mono text-sm sm:text-base font-bold text-indigo-700 tracking-wider">
                          {lic.licenseKey}
                        </div>

                        <div className="flex flex-wrap items-center gap-2">
                          <button
                            onClick={() => handleCopy(lic.licenseKey)}
                            className="px-3 py-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                          >
                            {copiedKey === lic.licenseKey ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-slate-500" />}
                            <span>{copiedKey === lic.licenseKey ? 'Copied' : 'Copy'}</span>
                          </button>

                          <button
                            onClick={() => handleInspectUsageForKey(lic.licenseKey)}
                            className="px-3 py-1.5 rounded-lg bg-indigo-50 border border-indigo-200 hover:bg-indigo-100 text-xs font-semibold text-indigo-700 flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                          >
                            <Activity className="w-3.5 h-3.5 text-indigo-600" />
                            <span>Usage Stats</span>
                          </button>

                          <button
                            onClick={() => downloadLicenseFile(lic)}
                            className="px-3 py-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                          >
                            <Download className="w-3.5 h-3.5 text-indigo-600" />
                            <span>Download .lic</span>
                          </button>

                          <button
                            onClick={() => onOpenSandboxWithKey(lic.licenseKey)}
                            className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-xs font-semibold text-white transition-colors cursor-pointer shadow-xs"
                          >
                            Launch in CLI →
                          </button>
                        </div>
                      </div>

                      {/* Quotas */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs text-slate-600 font-mono">
                        <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                          <span className="text-[10px] text-slate-400 block uppercase font-bold">Projects Quota</span>
                          <span className="text-slate-900 font-bold mt-0.5 block">{lic.limits.maxProjects}</span>
                        </div>
                        <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                          <span className="text-[10px] text-slate-400 block uppercase font-bold">Analyses / Mo</span>
                          <span className="text-slate-900 font-bold mt-0.5 block">{lic.limits.maxAnalysesPerMonth.toLocaleString()}</span>
                        </div>
                        <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                          <span className="text-[10px] text-slate-400 block uppercase font-bold">Seats</span>
                          <span className="text-slate-900 font-bold mt-0.5 block">{lic.limits.seats}</span>
                        </div>
                        <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                          <span className="text-[10px] text-slate-400 block uppercase font-bold">Bound Nodes</span>
                          <span className="text-emerald-600 font-bold mt-0.5 block">{lic.activeMachines.length} / {lic.maxMachineActivations}</span>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-12 rounded-2xl bg-white border border-slate-200 text-center space-y-3 shadow-sm">
                    <AlertCircle className="w-8 h-8 text-slate-400 mx-auto" />
                    <h4 className="text-base font-bold text-slate-900">No licenses found for this email address</h4>
                    <p className="text-xs text-slate-500 max-w-md mx-auto">
                      Ensure you entered the exact email used during checkout, or generate a new serial key.
                    </p>
                    <button
                      onClick={() => onOpenCheckout('pro')}
                      className="px-4 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white transition-colors cursor-pointer shadow-xs"
                    >
                      Buy New License Key →
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Real-Time Usage Statistics Dashboard */}
        {activeView === 'usage' && (
          <UsageStatisticsDashboard
            initialLicenseKey={selectedKeyForUsage}
            availableLicenses={licenses}
            onOpenSandboxWithKey={onOpenSandboxWithKey}
          />
        )}

      </div>
    </section>
  );
};
