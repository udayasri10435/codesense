import React, { useEffect, useState, useRef } from 'react';
import { Activity, Download, Sparkles, TrendingUp, Zap, SlidersHorizontal } from 'lucide-react';

interface LiveDownloadCounterProps {
  targetCount: number;
  todayCount?: number;
  label?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showTrend?: boolean;
  className?: string;
  onOpenCalibrate?: () => void;
}

export const LiveDownloadCounter: React.FC<LiveDownloadCounterProps> = ({
  targetCount,
  todayCount,
  label = 'Present Time Downloads',
  size = 'lg',
  showTrend = true,
  className = '',
  onOpenCalibrate,
}) => {
  const [currentCount, setCurrentCount] = useState<number>(
    typeof targetCount === 'number' && !isNaN(targetCount) ? targetCount : 0
  );
  const [recentIncrements, setRecentIncrements] = useState<{ id: number; text: string }[]>([]);
  const prevCountRef = useRef<number>(targetCount);

  // Smooth one-by-one step calculation animation
  useEffect(() => {
    if (typeof targetCount !== 'number' || isNaN(targetCount)) return;
    if (targetCount === currentCount) return;

    // If difference is small, increment 1 by 1 smoothly
    const diff = targetCount - currentCount;
    if (diff > 0 && diff < 500) {
      const stepTime = Math.max(25, Math.min(300, Math.floor(1000 / diff)));
      const timer = setTimeout(() => {
        setCurrentCount(prev => {
          const next = prev + 1;
          // Trigger floating +1 animation
          const incId = Date.now() + Math.random();
          setRecentIncrements(inc => [...inc.slice(-3), { id: incId, text: '+1' }]);
          setTimeout(() => {
            setRecentIncrements(inc => inc.filter(item => item.id !== incId));
          }, 1600);
          return next;
        });
      }, stepTime);

      return () => clearTimeout(timer);
    } else {
      setCurrentCount(targetCount);
    }
  }, [targetCount, currentCount]);

  // Digits array for visual digital odometer style
  const safeCount = typeof currentCount === 'number' && !isNaN(currentCount) ? currentCount : 0;
  const digits = safeCount.toLocaleString().split('');

  if (size === 'sm') {
    return (
      <div className={`inline-flex items-center gap-1.5 font-mono font-bold text-emerald-400 ${className}`}>
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
        </span>
        <span className="tabular-nums transition-all duration-300">
          {safeCount.toLocaleString()}
        </span>
        <span className="text-[10px] font-sans text-emerald-300 font-normal uppercase tracking-wider">Live</span>
      </div>
    );
  }

  if (size === 'md') {
    return (
      <div className={`relative inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-emerald-500/30 text-white ${className}`}>
        <span className="relative flex h-2.5 w-2.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
        </span>
        <div className="flex items-baseline gap-1.5 font-mono">
          <span className="text-emerald-400 font-bold text-base tracking-tight tabular-nums">
            {safeCount.toLocaleString()}
          </span>
          <span className="text-slate-400 text-xs font-sans">downloads</span>
        </div>
        {recentIncrements.map(inc => (
          <span 
            key={inc.id}
            className="absolute -top-3 right-1 text-xs font-extrabold text-emerald-400 bg-emerald-950/90 border border-emerald-500/60 px-1.5 py-0.2 rounded-full animate-bounce shadow-md pointer-events-none"
          >
            {inc.text}
          </span>
        ))}
        {onOpenCalibrate && (
          <button
            type="button"
            onClick={onOpenCalibrate}
            title="Set exact amount of downloads"
            className="ml-1 p-1 rounded-md text-slate-400 hover:text-emerald-300 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    );
  }

  // Large & XL Digital Ticker Counter Display
  return (
    <div className={`relative rounded-2xl bg-slate-950/90 border border-emerald-500/30 p-4 sm:p-5 text-white shadow-2xl ${className}`}>
      {/* Floating +1 increment badges */}
      <div className="absolute -top-3 right-4 flex gap-1 z-20 pointer-events-none">
        {recentIncrements.map(inc => (
          <span
            key={inc.id}
            className="text-xs font-mono font-black text-emerald-300 bg-emerald-900 border border-emerald-400 px-2 py-0.5 rounded-full shadow-lg animate-bounce"
          >
            {inc.text} Downloaded!
          </span>
        ))}
      </div>

      {/* Header telemetry badge */}
      <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-800/80">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <span className="text-xs font-bold text-slate-300 tracking-wider uppercase flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
            <span>{label}</span>
          </span>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 text-[11px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-500/20">
            <span className="text-[10px]">●</span>
            <span>CALCULATING 1-BY-1</span>
          </div>

          {onOpenCalibrate && (
            <button
              type="button"
              onClick={onOpenCalibrate}
              title="Set correct amount of downloads"
              className="p-1 rounded bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-emerald-300 border border-slate-700 transition-colors text-xs flex items-center gap-1 px-2 cursor-pointer"
            >
              <SlidersHorizontal className="w-3 h-3 text-emerald-400" />
              <span className="text-[10px] font-semibold">Set Count</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Digital Digit Tiles */}
      <div className="pt-4 pb-2 flex flex-wrap items-center justify-center sm:justify-start gap-1.5 sm:gap-2">
        {digits.map((char, idx) => (
          char === ',' ? (
            <span key={idx} className="text-2xl sm:text-3xl lg:text-4xl font-mono text-emerald-500 font-bold px-0.5 self-end mb-1">
              ,
            </span>
          ) : (
            <div 
              key={idx}
              className="relative w-9 sm:w-11 lg:w-13 h-12 sm:h-14 lg:h-16 rounded-xl bg-gradient-to-b from-slate-800 to-slate-900 border border-slate-700/80 flex items-center justify-center shadow-inner overflow-hidden"
            >
              {/* Digit separator line */}
              <div className="absolute inset-x-0 top-1/2 h-[1px] bg-slate-950/80 pointer-events-none z-10" />
              
              <span className="text-2xl sm:text-3xl lg:text-4xl font-mono font-black text-emerald-400 tracking-tight tabular-nums transition-all duration-300 drop-shadow-[0_0_8px_rgba(52,211,153,0.3)]">
                {char}
              </span>
            </div>
          )
        ))}

        <div className="ml-2 pl-2 border-l border-slate-800 text-left">
          <div className="text-xs font-extrabold text-white uppercase tracking-wider">
            Verified
          </div>
          <div className="text-[11px] text-slate-400">
            Downloads
          </div>
        </div>
      </div>

      {/* Bottom Metadata & Today's velocity */}
      {showTrend && (
        <div className="pt-3 mt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-2">
          <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+{todayCount ? todayCount.toLocaleString() : '148'} downloaded today</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono">
            Avg ~1 download every 24s
          </div>
        </div>
      )}
    </div>
  );
};

