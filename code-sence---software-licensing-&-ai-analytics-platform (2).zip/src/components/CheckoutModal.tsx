import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  X, CheckCircle2, ShieldCheck, Lock, CreditCard, Copy, Check, Download, 
  Terminal, Mail, Sparkles, AlertCircle, ArrowRight, Loader2, RefreshCw, Key,
  LogIn, Zap
} from 'lucide-react';
import { SubscriptionPlan, BillingInterval, CheckoutRequest, SerialLicense } from '../types';
import { useAuth } from '../context/AuthContext';
import { saveLicenseToFirestore } from '../lib/firestoreService';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  plan: SubscriptionPlan;
  initialInterval?: BillingInterval;
  onSuccess: (license: SerialLicense, emailDispatched: any) => void;
  onOpenSandboxWithKey: (key: string) => void;
  onViewEmail: (emailData: any) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  plan,
  initialInterval = 'yearly',
  onSuccess,
  onOpenSandboxWithKey,
  onViewEmail,
}) => {
  const { user, openLoginModal } = useAuth();
  const [billingInterval, setBillingInterval] = useState<BillingInterval>(initialInterval);
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [company, setCompany] = useState('');
  const [country, setCountry] = useState('United States');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal' | 'apple_pay' | 'crypto'>('card');
  
  // Card details state
  const [cardNumber, setCardNumber] = useState('4242 •••• •••• 4242');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvc, setCardCvc] = useState('888');
  const [cardHolder, setCardHolder] = useState('');

  // Auto-populate when user is signed in with Google
  useEffect(() => {
    if (user && isOpen) {
      if (!customerName) setCustomerName(user.name);
      if (!customerEmail) setCustomerEmail(user.email);
      if (!cardHolder) setCardHolder(user.name.toUpperCase());
    }
  }, [user, isOpen]);

  // Processing & result state
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [processingStep, setProcessingStep] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [generatedLicense, setGeneratedLicense] = useState<SerialLicense | null>(null);
  const [dispatchedEmail, setDispatchedEmail] = useState<any>(null);
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedEnv, setCopiedEnv] = useState(false);

  if (!isOpen) return null;

  const isFree = plan.id === 'free';
  const price = isFree ? 0 : billingInterval === 'yearly' ? plan.yearlyPrice : plan.monthlyPrice;

  // Preset demo fillers
  const fillPreset = (type: 'dev' | 'team' | 'edu') => {
    if (type === 'dev') {
      setCustomerName('Alex Rivera');
      setCustomerEmail('alex.rivera@devhub.io');
      setCompany('Rivera Software Labs');
      setCardHolder('ALEX RIVERA');
    } else if (type === 'team') {
      setCustomerName('Sarah Jenkins');
      setCustomerEmail('sarah.jenkins@acmecorp.com');
      setCompany('Acme Engineering Inc.');
      setCardHolder('SARAH JENKINS');
    } else {
      setCustomerName('Dr. Alan Turing');
      setCustomerEmail('a.turing@cambridge.edu');
      setCompany('Department of Computer Science');
      setCardHolder('ALAN TURING');
    }
  };

  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerEmail.trim()) {
      setErrorMessage('Please fill in your full name and email address.');
      return;
    }

    setStatus('processing');
    setErrorMessage('');

    // Simulated step-by-step cryptographic and billing progression
    setProcessingStep('1/4: Encrypting credentials & contacting payment gateway...');
    await new Promise(r => setTimeout(r, 600));

    setProcessingStep('2/4: Payment authorized. Minting cryptographic serial code...');
    await new Promise(r => setTimeout(r, 600));

    setProcessingStep('3/4: Provisioning quotas & signing SHA-256 digital certificate...');
    await new Promise(r => setTimeout(r, 500));

    setProcessingStep('4/4: Dispatching automated serial key & receipt to email...');

    try {
      const checkoutPayload: CheckoutRequest = {
        planId: plan.id,
        billingInterval,
        customerName,
        customerEmail,
        company,
        country,
        paymentMethod,
        cardDetails: paymentMethod === 'card' ? {
          cardNumber,
          expiry: cardExpiry,
          cvc: cardCvc,
          cardHolder: cardHolder || customerName,
        } : undefined,
      };

      const response = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(checkoutPayload),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || 'Failed to process automated billing.');
      }

      setGeneratedLicense(data.license);
      setDispatchedEmail(data.emailDispatched);
      setStatus('success');
      onSuccess(data.license, data.emailDispatched);

      // Persist to Cloud Firestore
      try {
        saveLicenseToFirestore(data.license);
      } catch (e) {
        console.warn('Firestore persist notice:', e);
      }

      // Trigger celebratory confetti
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#06b6d4', '#3b82f6', '#10b981', '#a855f7'],
      });
    } catch (err: any) {
      console.error(err);
      setStatus('error');
      setErrorMessage(err.message || 'An unexpected error occurred during automated billing.');
    }
  };

  const copyToClipboard = (text: string, type: 'key' | 'env') => {
    navigator.clipboard.writeText(text);
    if (type === 'key') {
      setCopiedKey(true);
      setTimeout(() => setCopiedKey(false), 2000);
    } else {
      setCopiedEnv(true);
      setTimeout(() => setCopiedEnv(false), 2000);
    }
  };

  const downloadLicenseFile = () => {
    if (!generatedLicense) return;
    const licContent = JSON.stringify({
      product: 'CodeSense Software Intelligence',
      serialKey: generatedLicense.licenseKey,
      plan: generatedLicense.planName,
      customer: generatedLicense.customerName,
      email: generatedLicense.customerEmail,
      limits: generatedLicense.limits,
      issuedAt: generatedLicense.createdAt,
      expiresAt: generatedLicense.expiresAt,
      signature: generatedLicense.digitalSignature,
    }, null, 2);

    const blob = new Blob([licContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `codesense-${generatedLicense.planId}-license.lic`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6">
      <div className="relative w-full max-w-2xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden text-slate-800">
        
        {/* Modal Top Bar */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-tight">
                {status === 'success' ? 'Serial Key Generated & Dispatched!' : `CodeSense ${plan.name} Subscription`}
              </h3>
              <p className="text-xs text-slate-500">Automated 256-bit Secure Checkout & License Minting</p>
            </div>
          </div>
          <button
            id="btn-close-checkout-modal"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status: Processing View */}
        {status === 'processing' && (
          <div className="p-12 text-center space-y-6">
            <div className="relative w-20 h-20 mx-auto">
              <div className="absolute inset-0 rounded-full border-4 border-indigo-200 animate-ping" />
              <div className="w-20 h-20 rounded-full border-4 border-indigo-600 border-t-transparent animate-spin flex items-center justify-center">
                <Key className="w-8 h-8 text-indigo-600" />
              </div>
            </div>
            <div className="space-y-2">
              <h4 className="text-lg font-bold text-slate-900">Processing Automated Payment</h4>
              <p className="text-sm font-mono text-indigo-700 bg-indigo-50 py-2 px-4 rounded-xl border border-indigo-200 inline-block">
                {processingStep}
              </p>
              <p className="text-xs text-slate-500 pt-2">Please do not refresh. Your serial key is being provisioned.</p>
            </div>
          </div>
        )}

        {/* Status: Success Screen (Serial Code Display & Instant Activation) */}
        {status === 'success' && generatedLicense && (
          <div className="p-6 sm:p-8 space-y-6">
            {/* Top Success Banner */}
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold text-emerald-950">
                  Payment Verified • Code Sence {generatedLicense.planName} Activated!
                </h4>
                <p className="text-xs text-emerald-700 mt-0.5">
                  Your payment was completed successfully. Your official serial license code is ready below and an invoice copy was emailed to <strong>{generatedLicense.customerEmail}</strong>.
                </p>
              </div>
            </div>

            {/* Prominent Serial License Key Box */}
            <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900 to-indigo-950 text-white border-2 border-indigo-500/40 shadow-xl space-y-4 relative overflow-hidden">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5 text-[11px]">
                  <Key className="w-4 h-4" />
                  Your Official Serial License Code:
                </span>
                <span className="bg-indigo-500/30 text-indigo-200 px-2.5 py-0.5 rounded-full text-[10px] font-mono border border-indigo-400/30">
                  256-BIT SIGNED &amp; ACTIVE
                </span>
              </div>

              {/* The Key */}
              <div className="p-4 rounded-xl bg-black/70 border border-indigo-500/50 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-inner">
                <span className="font-mono text-lg sm:text-2xl font-black text-emerald-400 tracking-wider select-all text-center sm:text-left break-all">
                  {generatedLicense.licenseKey}
                </span>
                <button
                  id="btn-copy-serial-key"
                  onClick={() => copyToClipboard(generatedLicense.licenseKey, 'key')}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-lg hover:shadow-emerald-500/30 cursor-pointer shrink-0"
                >
                  {copiedKey ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedKey ? 'Serial Code Copied!' : 'Copy Serial Code'}</span>
                </button>
              </div>

              {/* License Details Pill Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-[11px] font-mono">
                <div className="bg-white/5 border border-white/10 p-2.5 rounded-xl">
                  <span className="text-slate-400 block text-[10px] uppercase font-sans font-semibold">Tier</span>
                  <span className="font-bold text-white mt-0.5 block">{generatedLicense.planName}</span>
                </div>
                <div className="bg-white/5 border border-white/10 p-2.5 rounded-xl">
                  <span className="text-slate-400 block text-[10px] uppercase font-sans font-semibold">Projects Quota</span>
                  <span className="font-bold text-indigo-300 mt-0.5 block">{generatedLicense.limits.maxProjects}</span>
                </div>
                <div className="bg-white/5 border border-white/10 p-2.5 rounded-xl">
                  <span className="text-slate-400 block text-[10px] uppercase font-sans font-semibold">Analyses / Mo</span>
                  <span className="font-bold text-indigo-300 mt-0.5 block">{generatedLicense.limits.maxAnalysesPerMonth.toLocaleString()}</span>
                </div>
                <div className="bg-white/5 border border-white/10 p-2.5 rounded-xl">
                  <span className="text-slate-400 block text-[10px] uppercase font-sans font-semibold">Workstations</span>
                  <span className="font-bold text-emerald-400 mt-0.5 block">{generatedLicense.maxMachineActivations} slots</span>
                </div>
              </div>
            </div>

            {/* Quick Actions for Developer */}
            <div className="space-y-3">
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Activation &amp; Export Options:
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <button
                  id="btn-download-lic-file"
                  onClick={downloadLicenseFile}
                  className="p-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4 text-indigo-600" />
                  <span>Download .lic File</span>
                </button>

                <button
                  id="btn-copy-env-var"
                  onClick={() => copyToClipboard(`export CODESENSE_LICENSE_KEY="${generatedLicense.licenseKey}"`, 'env')}
                  className="p-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  {copiedEnv ? <Check className="w-4 h-4 text-emerald-600" /> : <Terminal className="w-4 h-4 text-indigo-600" />}
                  <span>{copiedEnv ? 'Export Copied!' : 'Copy CLI Env'}</span>
                </button>

                <button
                  id="btn-view-email-receipt"
                  onClick={() => {
                    if (dispatchedEmail) onViewEmail(dispatchedEmail);
                  }}
                  className="p-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Mail className="w-4 h-4 text-emerald-600" />
                  <span>View Email Receipt</span>
                </button>
              </div>
            </div>

            {/* Next Step CTA: Launch in Sandbox */}
            <div className="pt-2">
              <button
                id="btn-sandbox-activate-now"
                onClick={() => {
                  onClose();
                  onOpenSandboxWithKey(generatedLicense.licenseKey);
                }}
                className="w-full py-3.5 px-4 rounded-xl text-sm font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Terminal className="w-4 h-4" />
                <span>Test Serial Key in Live Code Sence Software Sandbox</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Status: Form Input View */}
        {(status === 'idle' || status === 'error') && (
          <form onSubmit={handleCheckoutSubmit} className="p-6 space-y-6">
            
            {/* Google Autofill Badge or Sign-in Prompt */}
            {user ? (
              <div className="p-3 rounded-xl bg-indigo-50/80 border border-indigo-200 flex items-center justify-between">
                <div className="flex items-center gap-2.5 min-w-0">
                  <img
                    src={user.picture || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(user.name)}`}
                    alt={user.name}
                    className="w-6 h-6 rounded-full border border-indigo-300"
                    referrerPolicy="no-referrer"
                  />
                  <div className="text-xs truncate">
                    <span className="font-bold text-indigo-950">Signed in as {user.name}</span>
                    <span className="text-indigo-600 font-mono ml-1.5 hidden sm:inline">({user.email})</span>
                  </div>
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  Auto-filled
                </span>
              </div>
            ) : (
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs text-slate-600">
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>Have a Google Account? Sign in for 1-click auto-fill.</span>
                </div>
                <button
                  type="button"
                  onClick={openLoginModal}
                  className="px-2.5 py-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                >
                  Sign in with Google &rarr;
                </button>
              </div>
            )}

            {/* Quick Demo Pre-fill helper */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs text-slate-600 flex items-center gap-1.5 font-medium">
                <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                <span>Quick Test Fill:</span>
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => fillPreset('dev')}
                  className="px-2.5 py-1 rounded-md text-[11px] font-medium bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition-colors cursor-pointer shadow-2xs"
                >
                  Pro Dev
                </button>
                <button
                  type="button"
                  onClick={() => fillPreset('team')}
                  className="px-2.5 py-1 rounded-md text-[11px] font-medium bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition-colors cursor-pointer shadow-2xs"
                >
                  Team Lead
                </button>
                <button
                  type="button"
                  onClick={() => fillPreset('edu')}
                  className="px-2.5 py-1 rounded-md text-[11px] font-medium bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition-colors cursor-pointer shadow-2xs"
                >
                  Academic Lab
                </button>
              </div>
            </div>

            {/* Error Message if any */}
            {errorMessage && (
              <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Plan Summary Card */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-bold text-slate-900">CodeSense {plan.name}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-semibold border border-indigo-200">
                    {billingInterval === 'yearly' ? 'Annual Plan' : 'Monthly Plan'}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  {plan.limits.maxProjects} Projects • {plan.limits.maxAnalysesPerMonth.toLocaleString()} Analyses/mo
                </p>
              </div>
              <div className="text-right">
                <div className="text-xl font-extrabold text-slate-900">
                  ${price}
                  <span className="text-xs font-normal text-slate-500">/{billingInterval === 'yearly' ? 'yr' : 'mo'}</span>
                </div>
                {billingInterval === 'yearly' && !isFree && (
                  <span className="text-[10px] text-emerald-600 font-semibold">Includes 2 months free</span>
                )}
              </div>
            </div>

            {/* Section 1: Customer Details */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                1. Customer & Licensee Details
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Full Name *</label>
                  <input
                    id="input-customer-name"
                    type="text"
                    required
                    placeholder="e.g. Linus Torvalds"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white rounded-xl text-sm text-slate-900 focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Email (License dispatched here) *</label>
                  <input
                    id="input-customer-email"
                    type="email"
                    required
                    placeholder="developer@company.com"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white rounded-xl text-sm text-slate-900 focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Company / Organization (Optional)</label>
                  <input
                    id="input-customer-company"
                    type="text"
                    placeholder="e.g. Acme Tech"
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white rounded-xl text-sm text-slate-900 focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">Country</label>
                  <select
                    id="select-customer-country"
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 focus:bg-white rounded-xl text-sm text-slate-900 focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 transition-colors"
                  >
                    <option value="United States">United States</option>
                    <option value="United Kingdom">United Kingdom</option>
                    <option value="Germany">Germany</option>
                    <option value="Canada">Canada</option>
                    <option value="Australia">Australia</option>
                    <option value="Japan">Japan</option>
                    <option value="Singapore">Singapore</option>
                    <option value="India">India</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Section 2: Payment Gateway Selection (if not free) */}
            {!isFree ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    2. Payment Gateway & Method
                  </h4>
                  <span className="text-[11px] text-slate-500 flex items-center gap-1">
                    <Lock className="w-3 h-3 text-emerald-600" />
                    256-Bit SSL Encrypted
                  </span>
                </div>

                {/* Gateway Tabs */}
                <div className="grid grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('card')}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                      paymentMethod === 'card'
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700 shadow-2xs'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 text-indigo-600" />
                    <span>Credit Card</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('paypal')}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                      paymentMethod === 'paypal'
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700 shadow-2xs'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="font-extrabold text-blue-600 text-sm">PayPal</span>
                    <span>Express</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('apple_pay')}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                      paymentMethod === 'apple_pay'
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700 shadow-2xs'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="font-bold text-sm text-slate-900"> Pay</span>
                    <span>1-Click</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('crypto')}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                      paymentMethod === 'crypto'
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700 shadow-2xs'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="text-amber-600 font-bold text-xs">USDT / BTC</span>
                    <span>Web3</span>
                  </button>
                </div>

                {/* Card Fields if Card Selected */}
                {paymentMethod === 'card' && (
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">Card Number</label>
                      <input
                        id="input-card-number"
                        type="text"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        className="w-full px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-mono text-slate-900 focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-slate-600 mb-1">Expiration (MM/YY)</label>
                        <input
                          id="input-card-expiry"
                          type="text"
                          value={cardExpiry}
                          onChange={(e) => setCardExpiry(e.target.value)}
                          className="w-full px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-mono text-slate-900 focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-600 mb-1">CVC / Security Code</label>
                        <input
                          id="input-card-cvc"
                          type="text"
                          value={cardCvc}
                          onChange={(e) => setCardCvc(e.target.value)}
                          className="w-full px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-mono text-slate-900 focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-900">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Free Mode — 100% Keyless Access (No Serial Key Required)</span>
                </div>
                <p className="text-xs text-emerald-700 leading-relaxed">
                  You do not need a serial key, payment method, or credit card to use CodeSense in Free Mode. You can immediately run code quality, AST complexity, and maintainability scans with up to 100 free analyses per month.
                </p>
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenSandboxWithKey('');
                    }}
                    className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>Launch Free Sandbox (Keyless) →</span>
                  </button>
                </div>
              </div>
            )}

            {/* Submit Button */}
            <div className="pt-2">
              {isFree ? (
                <button
                  id="btn-submit-order-free"
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenSandboxWithKey('');
                  }}
                  className="w-full py-3.5 px-6 rounded-xl text-base font-semibold text-white shadow-sm flex items-center justify-center gap-2 transition-all cursor-pointer bg-slate-900 hover:bg-slate-800"
                >
                  <Zap className="w-4 h-4 text-emerald-400" />
                  <span>Start Free Mode Instantly (No Key Needed)</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  id="btn-submit-order"
                  type="submit"
                  className="w-full py-3.5 px-6 rounded-xl text-base font-semibold text-white shadow-sm flex items-center justify-center gap-2 transition-all cursor-pointer bg-indigo-600 hover:bg-indigo-700"
                >
                  <Key className="w-4 h-4" />
                  <span>Authorize ${price}.00 & Generate Serial Key</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
              <p className="text-[11px] text-center text-slate-500 mt-2.5">
                {isFree 
                  ? 'Keyless instant access. No serial key or credit card needed.'
                  : 'Serial key generated instantaneously and emailed to your address. 30-day money-back guarantee.'}
              </p>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
