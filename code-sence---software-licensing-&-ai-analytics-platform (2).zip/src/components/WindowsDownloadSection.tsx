import React, { useState, useEffect } from 'react';
import { 
  Download, Terminal, CheckCircle2, ShieldCheck, Zap, Sparkles, 
  Copy, Check, AlertCircle, Laptop, ArrowRight, RefreshCw, FileCode,
  FolderArchive, Play, ExternalLink, HelpCircle, HardDrive, Cpu, Activity,
  TrendingUp, Globe, PlusCircle, CheckCircle, SlidersHorizontal
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { WindowsDownloadStats } from '../types';
import { LiveDownloadCounter } from './LiveDownloadCounter';
import { SetDownloadCountModal } from './SetDownloadCountModal';

export const GOOGLE_DRIVE_WINDOWS_URL = 'https://drive.google.com/file/d/10C5aBQRInoeCRzAMedUm9mBjhwBQiQ03/view?usp=sharing';

interface WindowsDownloadSectionProps {
  onOpenSandbox?: () => void;
  onOpenPricing?: () => void;
  onDownloadIncrement?: (stats?: WindowsDownloadStats) => void;
}

export const WindowsDownloadSection: React.FC<WindowsDownloadSectionProps> = ({ 
  onOpenSandbox,
  onOpenPricing,
  onDownloadIncrement,
}) => {
  const [stats, setStats] = useState<WindowsDownloadStats | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [copiedBatch, setCopiedBatch] = useState(false);
  const [copiedSha, setCopiedSha] = useState(false);
  const [activeStep, setActiveStep] = useState(1);
  const [justCountedNotice, setJustCountedNotice] = useState(false);
  const [isCalibrateOpen, setIsCalibrateOpen] = useState(false);

  // Fetch download stats with real-time polling
  const fetchStats = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/downloads/stats');
      const data = await res.json();
      if (data.success && data.stats) {
        setStats(data.stats);
        if (onDownloadIncrement) {
          onDownloadIncrement(data.stats);
        }
      }
    } catch (e) {
      console.warn('Failed to fetch download stats:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
    // Auto-poll for live present-time calculation every 4 seconds
    const interval = setInterval(fetchStats, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleDownload = async () => {
    setIsDownloading(true);
    
    // Confetti burst
    confetti({
      particleCount: 65,
      spread: 75,
      origin: { y: 0.6 }
    });

    try {
      // Track on server
      const res = await fetch('/api/downloads/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ os: 'Windows 11/10 x64', country: 'Verified Developer' }),
      });
      const data = await res.json();
      if (data.success && data.stats) {
        setStats(data.stats);
        if (onDownloadIncrement) {
          onDownloadIncrement(data.stats);
        }
      }

      setJustCountedNotice(true);
      setTimeout(() => setJustCountedNotice(false), 3500);
    } catch (e) {
      console.error('Error tracking download:', e);
    } finally {
      setIsDownloading(false);
      // Open Google Drive link in new window
      window.open(GOOGLE_DRIVE_WINDOWS_URL, '_blank', 'noopener,noreferrer');
    }
  };

  // Instant simulate +1 test to verify calculate one-by-one
  const handleSimulatePlusOne = async () => {
    try {
      const res = await fetch('/api/downloads/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ os: 'Windows 11 Test Station', country: 'Real-Time Tester' }),
      });
      const data = await res.json();
      if (data.success && data.stats) {
        setStats(data.stats);
        if (onDownloadIncrement) onDownloadIncrement(data.stats);
      }
      setJustCountedNotice(true);
      setTimeout(() => setJustCountedNotice(false), 3000);
    } catch (e) {
      console.error('Simulation error:', e);
    }
  };

  const handleCopyText = (text: string, type: 'batch' | 'sha') => {
    navigator.clipboard.writeText(text);
    if (type === 'batch') {
      setCopiedBatch(true);
      setTimeout(() => setCopiedBatch(false), 2000);
    } else {
      setCopiedSha(true);
      setTimeout(() => setCopiedSha(false), 2000);
    }
  };

  const totalDownloads = typeof stats?.totalDownloads === 'number' ? stats.totalDownloads : 0;
  const todayDownloads = typeof stats?.todayDownloads === 'number' ? stats.todayDownloads : 0;
  const freePoints = stats?.freeStartingPoints || 1000;

  return (
    <div className="py-12 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 space-y-12">
        
        {/* Top Header & Download Hero Banner */}
        <div className="rounded-3xl bg-slate-900 border border-slate-800 text-white p-6 sm:p-10 lg:p-12 relative overflow-hidden shadow-2xl">
          {/* Ambient Glows */}
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-emerald-600/15 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6">
              <div className="flex flex-wrap items-center gap-3">
                <span className="px-3.5 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold flex items-center gap-1.5">
                  <Laptop className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Official Windows Software Tool</span>
                </span>
                
                {/* Live Download Counter Badge */}
                <div className="px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-bold flex items-center gap-1.5">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                  <span>{totalDownloads.toLocaleString()} Downloads in Present Time</span>
                </div>

                <span className="px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400/30 text-amber-300 text-xs font-semibold flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>{freePoints} Free Mode Points Included</span>
                </span>
              </div>

              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight">
                Download CodeSense for <span className="text-indigo-400">Windows</span>
              </h2>

              <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                Experience high-speed local code intelligence, AST cyclomatic complexity metrics, and technical debt analysis directly on your Windows PC. Packaged as a portable engine — simply extract and double-click <code className="bg-slate-800 text-indigo-300 px-2 py-0.5 rounded font-mono font-bold">run.bat</code>.
              </p>

              {/* Free Mode 1000 Points Highlight Card */}
              <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0 border border-emerald-500/30">
                  <Zap className="w-5 h-5 text-emerald-400" />
                </div>
                <div className="text-xs space-y-1">
                  <h4 className="font-bold text-emerald-200 text-sm flex items-center gap-2">
                    <span>First-Time Users: Instant Free Mode + 1,000 Points</span>
                    <span className="text-[10px] uppercase px-2 py-0.5 rounded bg-emerald-500/30 text-emerald-300 font-extrabold">
                      Zero Setup
                    </span>
                  </h4>
                  <p className="text-slate-300 leading-relaxed">
                    Upon launching <strong className="text-white font-mono">run.bat</strong>, first-time users immediately receive <strong className="text-emerald-300 font-bold">1,000 Free Scan Points</strong>. No serial license key, registration, or credit card is required to begin scanning code repositories.
                  </p>
                </div>
              </div>

              {/* Main Download Button & Actions */}
              <div className="space-y-3 pt-2">
                <div className="flex flex-wrap items-center gap-4">
                  <button
                    id="btn-download-windows-tool"
                    onClick={handleDownload}
                    disabled={isDownloading}
                    className="px-8 py-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-base shadow-xl shadow-indigo-600/30 flex items-center gap-3 transition-all transform active:scale-95 cursor-pointer"
                  >
                    {isDownloading ? (
                      <RefreshCw className="w-5 h-5 animate-spin text-white" />
                    ) : (
                      <Download className="w-5 h-5 text-white" />
                    )}
                    <span>Download for Windows (Google Drive)</span>
                    <ExternalLink className="w-4 h-4 text-indigo-200 ml-1" />
                  </button>

                  <button
                    id="btn-refresh-stats"
                    onClick={fetchStats}
                    title="Refresh download statistics"
                    className="p-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors cursor-pointer"
                  >
                    <RefreshCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
                  </button>
                </div>

                {justCountedNotice && (
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/20 border border-emerald-400 text-emerald-300 text-xs font-semibold animate-in fade-in slide-in-from-top-1">
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                    <span>Download Counted! +1 Added to Global Telemetry</span>
                  </div>
                )}

                {/* Specs Subtitle */}
                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-1">
                  <span className="flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Windows 11 / 10 (64-bit)</span>
                  </span>
                  <span>•</span>
                  <span>Version 2.4.0 (Build #4892)</span>
                  <span>•</span>
                  <span>Size: ~48.2 MB</span>
                  <span>•</span>
                  <span className="text-emerald-300 font-medium">100% Virus & Malware Free</span>
                </div>
              </div>
            </div>

            {/* Right Column: Real-Time Digital Calculation Counter Widget */}
            <div className="lg:col-span-5 space-y-4">
              <LiveDownloadCounter
                targetCount={totalDownloads}
                todayCount={todayDownloads}
                label="Present Time Live Downloads"
                size="lg"
                onOpenCalibrate={() => setIsCalibrateOpen(true)}
              />

              {/* Interactive Test / +1 Trigger Box & Set Correct Count Trigger */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-slate-300">
                <div className="space-y-0.5">
                  <div className="font-semibold text-white flex items-center gap-1.5">
                    <Activity className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Real-Time Calculation Engine</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Live telemetry tracks every Windows tool download worldwide.
                  </p>
                </div>
                
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => setIsCalibrateOpen(true)}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1"
                    title="Enter custom exact amount of downloads"
                  >
                    <SlidersHorizontal className="w-3 h-3 text-emerald-400" />
                    <span>Set Count</span>
                  </button>

                  <button
                    onClick={handleSimulatePlusOne}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/50 border border-emerald-500/50 text-emerald-300 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <PlusCircle className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Test +1</span>
                  </button>
                </div>
              </div>

              {/* Recent Live Downloads Stream */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 text-xs space-y-2">
                <div className="flex items-center justify-between text-slate-400 text-[11px] font-bold uppercase tracking-wider">
                  <span className="flex items-center gap-1.5 text-slate-300">
                    <Globe className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Recent Live Downloads Feed</span>
                  </span>
                  <span className="text-emerald-400">Live Active</span>
                </div>

                <div className="space-y-1.5">
                  {(stats?.recentDownloads || []).slice(0, 3).map((dl, i) => (
                    <div key={dl.id || i} className="flex items-center justify-between p-2 rounded-lg bg-slate-900/90 border border-slate-800/80 text-[11px]">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                        <span className="font-mono text-slate-300">{dl.id}</span>
                        <span className="text-slate-400 font-sans">• {dl.country}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-slate-500 font-mono">{dl.os.split(' ')[0]}</span>
                        <span className="font-bold text-emerald-400 bg-emerald-950/80 px-1.5 py-0.2 rounded border border-emerald-500/30">
                          +1,000 Pts
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* 3-Step Setup Instructions: Extract & Double-Click run.bat */}
        <div className="space-y-6">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Quick 30-Second Setup</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              How to Run CodeSense on Windows
            </h3>
            <p className="text-slate-600 text-xs sm:text-sm">
              No installers, no admin privileges required. Simply download the ZIP, extract it, and execute <code className="font-mono bg-slate-100 text-indigo-700 px-1.5 py-0.5 rounded font-bold">run.bat</code>.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Step 1 */}
            <div 
              onClick={() => setActiveStep(1)}
              className={`p-6 rounded-2xl bg-white border transition-all cursor-pointer ${
                activeStep === 1 
                  ? 'border-indigo-600 shadow-md ring-2 ring-indigo-600/10' 
                  : 'border-slate-200 hover:border-slate-300 shadow-xs'
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 font-extrabold text-lg mb-4">
                1
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-2 flex items-center gap-2">
                <FolderArchive className="w-4 h-4 text-indigo-600" />
                <span>Extract the ZIP Archive</span>
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Download the official archive from Google Drive and extract it to any convenient directory on your PC (e.g. <code className="bg-slate-100 px-1 rounded font-mono">C:\CodeSense</code> or your Desktop).
              </p>
            </div>

            {/* Step 2 */}
            <div 
              onClick={() => setActiveStep(2)}
              className={`p-6 rounded-2xl bg-white border transition-all cursor-pointer ${
                activeStep === 2 
                  ? 'border-emerald-600 shadow-md ring-2 ring-emerald-600/10' 
                  : 'border-slate-200 hover:border-slate-300 shadow-xs'
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600 font-extrabold text-lg mb-4">
                2
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-2 flex items-center gap-2">
                <Play className="w-4 h-4 text-emerald-600" />
                <span>Double-Click `run.bat`</span>
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Locate the primary <code className="bg-emerald-50 text-emerald-800 px-1 rounded font-mono font-bold">run.bat</code> batch script in the extracted folder and double-click it. It automatically initializes the engine runtime.
              </p>
            </div>

            {/* Step 3 */}
            <div 
              onClick={() => setActiveStep(3)}
              className={`p-6 rounded-2xl bg-white border transition-all cursor-pointer ${
                activeStep === 3 
                  ? 'border-purple-600 shadow-md ring-2 ring-purple-600/10' 
                  : 'border-slate-200 hover:border-slate-300 shadow-xs'
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-purple-50 border border-purple-100 flex items-center justify-center text-purple-600 font-extrabold text-lg mb-4">
                3
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-2 flex items-center gap-2">
                <Zap className="w-4 h-4 text-purple-600" />
                <span>Enjoy 1,000 Free Scan Points</span>
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                First-time users instantly get 1,000 Scan Points in Free Mode. Select any project directory to perform instant cyclomatic debt audits and security scans immediately.
              </p>
            </div>

          </div>
        </div>

        {/* Technical Specs & Details Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left: Built-In Windows Features */}
          <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Cpu className="w-5 h-5 text-indigo-600" />
              <span>What&apos;s Included in the Windows Engine</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>AST Cyclomatic Analyzer</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Parses TypeScript, JavaScript, Python, Go, Rust, Java, and C# source code files with zero network latency.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Local Technical Debt Metric</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Computes exact refactoring hours, architectural risk scores, maintainability indexes, and test debt.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Security Vulnerability Scan</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Detects hardcoded secrets, SQL injection risks, unsafe regular expressions, and XSS attack vectors.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Refactoring Snippet Simulator</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Provides before-and-after diff comparisons for high-complexity loops and branch conditions.
                </p>
              </div>
            </div>

            {/* SmartScreen Note */}
            <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-3">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="font-bold">Windows SmartScreen Note:</span>
                <p className="text-amber-800 leading-relaxed">
                  Because this is a freshly compiled batch & portable engine, Windows SmartScreen may display a blue warning box on first launch. Simply click <strong className="font-semibold">&quot;More info&quot;</strong> and select <strong className="font-semibold">&quot;Run anyway&quot;</strong> to launch <code className="font-mono bg-amber-100 px-1 rounded">run.bat</code>.
                </p>
              </div>
            </div>
          </div>

          {/* Right: Technical Specs & Download Telemetry */}
          <div className="lg:col-span-5 bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-5">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <HardDrive className="w-5 h-5 text-indigo-600" />
              <span>Technical Package Specifications</span>
            </h3>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500">Package Type:</span>
                <span className="font-semibold text-slate-800">Windows Portable Executable + Batch CLI</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500">Primary Startup File:</span>
                <span className="font-mono font-bold text-indigo-600">run.bat</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500">Download Size:</span>
                <span className="font-semibold text-slate-800">48.2 MB (Compressed ZIP)</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500">Architecture:</span>
                <span className="font-semibold text-slate-800">x64 (64-bit) & ARM64 Emulation</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500">Free Mode Quota:</span>
                <span className="font-bold text-emerald-600">1,000 Points (Keyless)</span>
              </div>
            </div>

            {/* SHA-256 Checksum Box */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-medium">SHA-256 Verification Hash:</span>
                <button
                  onClick={() => handleCopyText('d8f2a4198ec0028a49c951fa69e0018f29402ab8419ef2018a1a9e87189fa91b', 'sha')}
                  className="text-[11px] text-indigo-600 hover:text-indigo-700 font-semibold flex items-center gap-1 cursor-pointer"
                >
                  {copiedSha ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-indigo-600" />}
                  <span>{copiedSha ? 'Copied' : 'Copy Hash'}</span>
                </button>
              </div>
              <p className="font-mono text-[10px] text-slate-700 break-all bg-white p-2 rounded border border-slate-200">
                d8f2a4198ec0028a49c951fa69e0018f29402ab8419ef2018a1a9e87189fa91b
              </p>
            </div>

            {/* Bottom Direct CTA */}
            <div className="pt-2">
              <button
                onClick={handleDownload}
                className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-xs transition-all"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                <span>Download CodeSense for Windows (Free)</span>
              </button>
            </div>

          </div>

        </div>

      </div>

      {/* Set / Calibrate Exact Downloads Modal */}
      <SetDownloadCountModal
        isOpen={isCalibrateOpen}
        onClose={() => setIsCalibrateOpen(false)}
        currentTotal={totalDownloads}
        currentToday={todayDownloads}
        onCountUpdated={(newStats) => {
          setStats(newStats);
          if (onDownloadIncrement) {
            onDownloadIncrement(newStats);
          }
        }}
      />
    </div>
  );
};
