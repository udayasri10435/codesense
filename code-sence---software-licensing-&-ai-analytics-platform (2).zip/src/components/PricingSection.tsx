import React, { useState } from 'react';
import { Check, Zap, Sparkles, Building2, GraduationCap, Users, Shield, ArrowRight, Key } from 'lucide-react';
import { SubscriptionPlan, BillingInterval } from '../types';
import { SUBSCRIPTION_PLANS } from '../data/plans';

interface PricingSectionProps {
  onSelectPlan: (plan: SubscriptionPlan, interval: BillingInterval) => void;
  onOpenVerifier: () => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onSelectPlan, onOpenVerifier }) => {
  const [billingInterval, setBillingInterval] = useState<BillingInterval>('yearly');

  const getPlanIcon = (id: string) => {
    switch (id) {
      case 'free':
        return <Zap className="w-5 h-5 text-slate-400" />;
      case 'pro':
        return <Sparkles className="w-5 h-5 text-blue-400" />;
      case 'team':
        return <Users className="w-5 h-5 text-emerald-400" />;
      case 'enterprise':
        return <Building2 className="w-5 h-5 text-purple-400" />;
      case 'education':
        return <GraduationCap className="w-5 h-5 text-amber-400" />;
      default:
        return <Key className="w-5 h-5 text-cyan-400" />;
    }
  };

  return (
    <section id="pricing-section" className="py-16 bg-slate-50 border-b border-slate-200 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold uppercase tracking-wider">
            <Key className="w-3.5 h-3.5" />
            <span>Automated Subscription & Serial Key Engine</span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Transparent Plans for Every Codebase
          </h2>
          
          <p className="text-slate-600 text-base max-w-2xl mx-auto">
            Select a plan to immediately trigger automated billing and receive your cryptographically signed serial license key via on-screen display & email certificate.
          </p>

          {/* Billing Interval Toggle */}
          <div className="pt-4 flex items-center justify-center">
            <div className="bg-slate-200/80 p-1 rounded-xl inline-flex items-center gap-1 shadow-inner">
              <button
                id="billing-toggle-monthly"
                onClick={() => setBillingInterval('monthly')}
                className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  billingInterval === 'monthly'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Monthly Billing
              </button>
              <button
                id="billing-toggle-yearly"
                onClick={() => setBillingInterval('yearly')}
                className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                  billingInterval === 'yearly'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>Annual Billing</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                  Save 20%
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-stretch">
          {SUBSCRIPTION_PLANS.map((plan) => {
            const price = billingInterval === 'yearly' ? plan.yearlyPrice : plan.monthlyPrice;
            const isFree = plan.id === 'free';
            const isTeam = plan.id === 'team';
            const isEnterprise = plan.id === 'enterprise';
            const isEducation = plan.id === 'education';

            return (
              <div
                key={plan.id}
                id={`pricing-card-${plan.id}`}
                className={`rounded-2xl flex flex-col justify-between transition-all duration-200 relative overflow-hidden ${
                  isTeam
                    ? 'bg-white border-2 border-indigo-500 shadow-xl lg:-translate-y-2 z-10'
                    : isEnterprise
                    ? 'bg-slate-900 border border-slate-800 text-white shadow-md'
                    : 'bg-white border border-slate-200 hover:border-slate-300 shadow-sm'
                }`}
              >
                {/* Highlight Badge */}
                {plan.badge && (
                  <div className={`absolute top-0 right-0 px-4 py-1 text-[11px] font-bold tracking-wider uppercase rounded-bl-xl ${
                    isTeam
                      ? 'bg-indigo-600 text-white'
                      : isEnterprise
                      ? 'bg-purple-600 text-white'
                      : isEducation
                      ? 'bg-amber-600 text-white'
                      : 'bg-slate-800 text-white'
                  }`}>
                    {plan.badge}
                  </div>
                )}

                <div className="p-6 sm:p-7 space-y-5">
                  {/* Plan Name & Icon */}
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      isEnterprise
                        ? 'bg-slate-800 border border-slate-700 text-purple-400'
                        : isTeam
                        ? 'bg-indigo-50 border border-indigo-100 text-indigo-600'
                        : isEducation
                        ? 'bg-amber-50 border border-amber-100 text-amber-600'
                        : 'bg-slate-100 border border-slate-200 text-slate-700'
                    }`}>
                      {getPlanIcon(plan.id)}
                    </div>
                    <div>
                      <h3 className={`text-xl font-extrabold tracking-tight ${isEnterprise ? 'text-white' : 'text-slate-900'}`}>{plan.name}</h3>
                      <p className={`text-xs font-medium ${isEnterprise ? 'text-slate-400' : 'text-slate-500'}`}>{plan.targetAudience}</p>
                    </div>
                  </div>

                  {/* Tagline */}
                  <p className={`text-xs min-h-[36px] leading-relaxed ${isEnterprise ? 'text-slate-300' : 'text-slate-600'}`}>
                    {plan.tagline}
                  </p>

                  {/* Pricing Display */}
                  <div className={`pt-2 border-t ${isEnterprise ? 'border-slate-800' : 'border-slate-100'}`}>
                    {isFree ? (
                      <div className="flex items-baseline gap-1">
                        <span className="text-3xl sm:text-4xl font-extrabold text-slate-900">$0</span>
                        <span className="text-xs text-slate-500">/ forever free</span>
                      </div>
                    ) : (
                      <div>
                        <div className="flex items-baseline gap-1">
                          <span className={`text-3xl sm:text-4xl font-extrabold ${isEnterprise ? 'text-white' : 'text-slate-900'}`}>
                            ${billingInterval === 'yearly' ? Math.round(price / 12) : price}
                          </span>
                          <span className={`text-xs ${isEnterprise ? 'text-slate-400' : 'text-slate-500'}`}>/ user / month</span>
                        </div>
                        <div className={`text-[11px] mt-0.5 ${isEnterprise ? 'text-slate-400' : 'text-slate-500'}`}>
                          {billingInterval === 'yearly' ? `Billed annually at $${price}/yr` : 'Billed monthly, cancel anytime'}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Core Capacity Limits */}
                  <div className={`p-3.5 rounded-xl space-y-2 ${isEnterprise ? 'bg-slate-950 border border-slate-800' : 'bg-slate-50 border border-slate-200'}`}>
                    <div className={`text-[11px] font-bold uppercase tracking-wider ${isEnterprise ? 'text-slate-400' : 'text-slate-500'}`}>Plan Limits</div>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-slate-400 block text-[10px]">Max Projects:</span>
                        <span className={`font-bold ${isEnterprise ? 'text-slate-200' : 'text-slate-800'}`}>
                          {plan.limits.maxProjects === 'Unlimited' ? 'Unlimited' : `${plan.limits.maxProjects} Projects`}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Analyses / Month:</span>
                        <span className="font-bold text-indigo-600">
                          {plan.limits.maxAnalysesPerMonth === 'Unlimited' ? 'Unlimited' : `${plan.limits.maxAnalysesPerMonth.toLocaleString()} / mo`}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Features List */}
                  <div className="space-y-2.5 pt-2">
                    <div className={`text-[11px] font-bold uppercase tracking-wider ${isEnterprise ? 'text-slate-400' : 'text-slate-500'}`}>Included Capabilities</div>
                    <ul className="space-y-2 text-xs">
                      {plan.features.map((feature, idx) => (
                        <li key={idx} className={`flex items-start gap-2.5 ${isEnterprise ? 'text-slate-300' : 'text-slate-600'}`}>
                          <div className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${
                            isEnterprise 
                              ? 'bg-purple-400' 
                              : isTeam 
                              ? 'bg-indigo-600' 
                              : isEducation 
                              ? 'bg-amber-600' 
                              : 'bg-slate-400'
                          }`} />
                          <span className="leading-snug">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Card Action Footer */}
                <div className="p-6 pt-0 mt-auto">
                  <button
                    id={`btn-select-plan-${plan.id}`}
                    onClick={() => onSelectPlan(plan, billingInterval)}
                    className={`w-full py-3.5 px-4 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 transition-all transform active:scale-95 cursor-pointer ${
                      isTeam
                        ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-500/20'
                        : isEnterprise
                        ? 'bg-white hover:bg-slate-100 text-slate-900 shadow-sm'
                        : isEducation
                        ? 'bg-amber-600 hover:bg-amber-700 text-white shadow-sm'
                        : isFree
                        ? 'bg-slate-900 hover:bg-slate-800 text-white shadow-sm'
                        : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm'
                    }`}
                  >
                    <span>{isFree ? 'Start Free (No Key Required)' : `Subscribe & Generate ${plan.name} Key`}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <p className={`text-[10px] text-center mt-2 ${isEnterprise ? 'text-slate-400' : 'text-slate-500'}`}>
                    {isFree 
                      ? '100% Keyless • No serial key or credit card needed' 
                      : 'Instant serial generation & automated email dispatch'}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Banner for Key Verification */}
        <div className="mt-12 p-6 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center shrink-0">
              <Shield className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">Already have a CodeSense Serial Key?</h4>
              <p className="text-xs text-slate-500">Validate digital signatures, check plan quotas, and manage bound workstation nodes.</p>
            </div>
          </div>
          <button
            id="pricing-btn-verify-existing"
            onClick={onOpenVerifier}
            className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-indigo-700 border border-slate-200 whitespace-nowrap transition-colors cursor-pointer"
          >
            Launch Key Verifier →
          </button>
        </div>
      </div>
    </section>
  );
};
