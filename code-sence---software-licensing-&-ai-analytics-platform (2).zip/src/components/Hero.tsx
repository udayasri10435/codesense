import React from 'react';
import { 
  ShieldCheck, Zap, KeyRound, CheckCircle2, ArrowRight, Terminal, 
  RefreshCw, Sparkles, MailCheck, Lock, Download, Laptop, Activity
} from 'lucide-react';
import { LiveDownloadCounter } from './LiveDownloadCounter';

interface HeroProps {
  onSelectPricing: () => void;
  onOpenSandbox: () => void;
  onOpenVerifier: () => void;
  onQuickCheckout: (planId: string) => void;
  onOpenDownloadModal?: () => void;
  downloadCount?: number;
}

export const Hero: React.FC<HeroProps> = ({ 
  onSelectPricing, 
  onOpenSandbox, 
  onOpenVerifier, 
  onQuickCheckout,
  onOpenDownloadModal,
  downloadCount = 0
}) => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-white to-slate-50 border-b border-slate-200 pt-10 pb-16 lg:pt-16 lg:pb-24">
      {/* Background Decorative Blur Elements */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-indigo-200/40 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-[400px] h-[300px] bg-sky-200/40 blur-[100px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Value Proposition & CTAs */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <div className="flex flex-wrap items-center gap-2">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-200/80 text-indigo-700 text-xs font-semibold shadow-xs">
                <span className="flex h-2 w-2 rounded-full bg-indigo-600 animate-pulse" />
                <span>Automated Billing & Instant Serial Key Dispatch Engine</span>
              </div>

              {/* Windows Tool Download Pill with Live Count */}
              <button
                onClick={onOpenDownloadModal}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-900 text-xs font-bold shadow-2xs transition-all cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                <span>Windows Tool (run.bat)</span>
                <span className="flex items-center gap-1 bg-emerald-200/80 text-emerald-950 px-2 py-0.5 rounded-full font-mono text-[11px]">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-ping" />
                  <span>{downloadCount.toLocaleString()} Live</span>
                </span>
              </button>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.12]">
              Master Code Quality with <span className="text-indigo-600">CodeSense™</span>
            </h1>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
              Next-generation software intelligence tool for automated technical debt calculation, refactoring simulation, and team code governance. Download the portable Windows engine (run <code className="bg-slate-100 text-indigo-700 px-1.5 py-0.5 rounded font-mono font-bold">run.bat</code> for instant Free Mode + 1,000 pts) or unlock full team features with cryptographic serial keys.
            </p>

            {/* Live Real-Time Downloads Telemetry Card in Hero */}
            <div className="max-w-md">
              <LiveDownloadCounter
                targetCount={downloadCount}
                label="Present Time Live Downloads"
                size="md"
              />
            </div>

            {/* Key Value Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
              <div className="flex items-center gap-2 text-xs font-medium text-slate-700 bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
                <Laptop className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>Windows Portable run.bat</span>
              </div>
              <div className="flex items-center gap-2 text-xs font-medium text-slate-700 bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
                <Zap className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>1,000 Free Starting Pts</span>
              </div>
              <div className="flex items-center gap-2 text-xs font-medium text-slate-700 bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
                <Lock className="w-4 h-4 text-purple-600 shrink-0" />
                <span>Tamper-Proof SHA-256 Keys</span>
              </div>
            </div>

            {/* Main CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-3">
              {/* Windows Download Tool CTA */}
              <button
                id="hero-cta-download-windows"
                onClick={onOpenDownloadModal}
                className="px-6 py-3.5 rounded-xl text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-600/20 flex items-center gap-2 transition-all transform active:scale-95 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Windows Tool (run.bat)</span>
              </button>

              <button
                id="hero-cta-pricing"
                onClick={onSelectPricing}
                className="px-6 py-3.5 rounded-xl text-sm font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-500/20 flex items-center gap-2 transition-all transform active:scale-95 cursor-pointer"
              >
                <span>Select Plan & Buy Key</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                id="hero-cta-sandbox"
                onClick={onOpenSandbox}
                className="px-5 py-3.5 rounded-xl text-sm font-semibold bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 shadow-xs flex items-center gap-2 transition-all cursor-pointer"
              >
                <Terminal className="w-4 h-4 text-indigo-600" />
                <span>Test Web Sandbox</span>
              </button>
            </div>

            {/* Trust Markers */}
            <div className="flex items-center gap-6 pt-3 text-xs text-slate-500">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Double-Click `run.bat` to Start</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>1,000 Points Free Mode</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Stripe & PayPal Verified</span>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Live Terminal & Activation Preview */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl bg-slate-900 border border-slate-800 shadow-xl overflow-hidden text-left">
              {/* Terminal Window Header */}
              <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500/80" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                  <div className="w-3 h-3 rounded-full bg-green-500/80" />
                  <span className="text-xs font-mono text-slate-400 ml-2">codesense-engine v2.4</span>
                </div>
                <div className="flex items-center gap-1.5 text-[11px] font-mono text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/40">
                  <KeyRound className="w-3 h-3" />
                  <span>CS-PRO-ACTIVE</span>
                </div>
              </div>

              {/* Terminal Content */}
              <div className="p-4 sm:p-5 font-mono text-xs text-slate-300 space-y-3 bg-slate-950/95">
                <div className="text-slate-400">
                  <span className="text-indigo-400 font-bold">$</span> codesense activate --key=&quot;CODESENSE-PRO-XXXXXXXX&quot;
                </div>
                <div className="p-2.5 rounded bg-slate-900 border border-emerald-500/30 text-emerald-300 space-y-1">
                  <div className="flex items-center gap-1.5 font-bold">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>CRYPTOGRAPHIC SIGNATURE VALIDATED</span>
                  </div>
                  <div className="text-[11px] text-slate-400 space-y-0.5">
                    <div>Plan: <strong className="text-white">Pro Developer Edition (Annual)</strong></div>
                    <div>Limits: <strong className="text-emerald-400">50,000 Points / Mo</strong> • 3 Workstations</div>
                    <div>Digital Signature: <strong className="text-indigo-300">ECDSA-P256-SHA256 (Valid)</strong></div>
                  </div>
                </div>

                <div className="text-slate-400 pt-1">
                  <span className="text-indigo-400 font-bold">$</span> codesense scan --path=&quot;./src&quot; --auto-refactor
                </div>
                <div className="text-slate-400 space-y-1 pl-2 border-l border-indigo-500/30">
                  <div>[1/4] Parsing AST AST Nodes (142 files)... <span className="text-emerald-400">Done (32ms)</span></div>
                  <div>[2/4] Computing Cyclomatic Complexity... <span className="text-emerald-400">Score 14.2 (Optimal)</span></div>
                  <div>[3/4] Estimating Refactoring Hours... <span className="text-amber-300">6.4 hrs</span></div>
                  <div>[4/4] Automated Code Fix Simulation... <span className="text-indigo-400">3 suggestions ready</span></div>
                </div>

                <div className="pt-2 text-center">
                  <button
                    onClick={onOpenSandbox}
                    className="w-full py-2.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-indigo-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <span>Launch Web Sandbox Simulator</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
