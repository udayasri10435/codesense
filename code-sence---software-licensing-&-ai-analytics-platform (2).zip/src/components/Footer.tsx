import React from 'react';
import { KeyRound, ShieldCheck, Lock, Terminal, CreditCard, Mail, CheckCircle2, Download, Laptop } from 'lucide-react';

interface FooterProps {
  onSelectTab: (tab: any) => void;
  onOpenCheckout: (planId?: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectTab, onOpenCheckout }) => {
  return (
    <footer className="bg-white border-t border-slate-200 text-slate-500 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 py-12 space-y-8">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1: Brand & Licensing */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg overflow-hidden bg-indigo-600 flex items-center justify-center">
                <img src="/favicon.svg" alt="Code Sence" className="w-full h-full object-cover" />
              </div>
              <span className="font-bold text-base text-slate-900">Code Sence™</span>
            </div>
            <p className="text-slate-500 text-xs leading-relaxed">
              Automated code intelligence and architectural debt management engine with instant cryptographic serial key distribution and portable Windows launcher (<code className="text-indigo-600 font-mono font-bold">run.bat</code>).
            </p>
            <div className="flex items-center gap-2 text-[11px] text-slate-500">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>SHA-256 HMAC Digital Signing</span>
            </div>
          </div>

          {/* Col 2: Subscription Plans */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Subscription Plans</h4>
            <ul className="space-y-1.5 text-xs">
              <li>
                <button onClick={() => onOpenCheckout('free')} className="hover:text-indigo-600 transition-colors cursor-pointer">
                  FREE Mode ($0) - No Serial Key Needed (1,000 Pts)
                </button>
              </li>
              <li>
                <button onClick={() => onOpenCheckout('pro')} className="hover:text-indigo-600 transition-colors cursor-pointer">
                  PRO Plan ($29/mo) - Refactoring Simulator
                </button>
              </li>
              <li>
                <button onClick={() => onOpenCheckout('team')} className="hover:text-indigo-600 transition-colors cursor-pointer">
                  TEAM Plan ($99/mo) - CI/CD & Org Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => onOpenCheckout('enterprise')} className="hover:text-indigo-600 transition-colors cursor-pointer">
                  ENTERPRISE ($299/mo) - RBAC & Audit Logs
                </button>
              </li>
              <li>
                <button onClick={() => onOpenCheckout('education')} className="hover:text-indigo-600 transition-colors cursor-pointer">
                  EDUCATION ($49/mo) - Lecturer Hub
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Tools & Verifiers */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Downloads & Tools</h4>
            <ul className="space-y-1.5 text-xs">
              <li>
                <button onClick={() => onSelectTab('download')} className="text-emerald-700 font-bold hover:text-emerald-800 flex items-center gap-1.5 transition-colors cursor-pointer">
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Windows Tool (run.bat)</span>
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('verifier')} className="hover:text-indigo-600 transition-colors cursor-pointer">
                  Serial Key Authenticity Verifier
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('sandbox')} className="hover:text-indigo-600 transition-colors cursor-pointer">
                  Live Software CLI Sandbox
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('portal')} className="hover:text-indigo-600 transition-colors cursor-pointer">
                  Retrieve Lost Serial Keys & Telemetry
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('features')} className="hover:text-indigo-600 transition-colors cursor-pointer">
                  Architecture & Specifications
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Automated Billing & Security */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Automated Billing & Gateways</h4>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              Payments are verified in milliseconds. Serial codes are generated instantly with automated email receipts dispatched to the buyer.
            </p>
            <div className="flex flex-wrap gap-2 pt-1">
              <span className="px-2 py-1 bg-slate-50 border border-slate-200 rounded text-[10px] text-slate-700 font-medium">
                Stripe Verified
              </span>
              <span className="px-2 py-1 bg-slate-50 border border-slate-200 rounded text-[10px] text-slate-700 font-medium">
                PayPal Express
              </span>
              <span className="px-2 py-1 bg-slate-50 border border-slate-200 rounded text-[10px] text-slate-700 font-medium">
                 Apple Pay
              </span>
              <span className="px-2 py-1 bg-slate-50 border border-slate-200 rounded text-[10px] text-slate-700 font-medium">
                256-Bit SSL
              </span>
            </div>
          </div>

        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-400">
          <div>
            © {new Date().getFullYear()} Code Sence Technologies Inc. All rights reserved. Automated Serial Key Issuance Platform.
          </div>
          <div className="flex items-center gap-4">
            <span className="hover:text-slate-600 cursor-pointer">Terms of Licensing</span>
            <span className="hover:text-slate-600 cursor-pointer">Privacy Policy</span>
            <span className="hover:text-slate-600 cursor-pointer">Security Whitepaper</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
