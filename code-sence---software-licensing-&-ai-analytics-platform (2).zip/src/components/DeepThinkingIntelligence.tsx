import React, { useState, useEffect } from 'react';
import { 
  BrainCircuit, Sparkles, ShieldAlert, CheckCircle2, Zap, ArrowRight, 
  Terminal, RefreshCw, Copy, Check, Lock, Cpu, Lightbulb, FileCode, Sliders
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { saveAuditToFirestore, fetchRecentAuditsFromFirestore, FirestoreAuditRecord } from '../lib/firestoreService';

const SAMPLE_SNIPPETS = {
  concurrency: `// High-frequency order book matching engine
class OrderBook {
  private std::mutex mtx_a;
  private std::mutex mtx_b;
  private std::vector<Order> bids;
  private std::vector<Order> asks;

public:
  void matchCrossMarket(OrderBook& targetMarket, Order incoming) {
    mtx_a.lock();
    // Simulate transaction across shards
    targetMarket.mtx_b.lock();
    
    for (auto& ask : asks) {
      if (incoming.price >= ask.price) {
        executeFill(incoming, ask);
      }
    }
    
    targetMarket.mtx_b.unlock();
    mtx_a.unlock();
  }
};`,
  auth: `// Distributed Token Verification & ACL Guard
export async function verifyAndAuthorize(req: Request, res: Response) {
  const token = req.headers['x-api-key'] as string;
  
  // Vulnerable timing attack string comparison
  if (token === process.env.MASTER_INTERNAL_KEY) {
    req.user = { role: 'superadmin', tier: 'enterprise' };
    return next();
  }

  const decoded = jwt.decode(token); // Unverified signature decode
  if (decoded && decoded.role === 'admin') {
    return next();
  }
  
  res.status(403).json({ error: 'Forbidden' });
}`,
  memory: `// Network Packet Framing & Buffer Slicer
void parse_raw_payload(uint8_t* raw_stream, size_t total_len) {
  uint16_t header_len = *(uint16_t*)raw_stream;
  uint8_t* payload_ptr = raw_stream + 2;
  
  char* buffer = (char*)malloc(header_len);
  // Missing buffer overflow guard: total_len < header_len
  memcpy(buffer, payload_ptr, header_len);
  
  process_packet(buffer);
  // Missing free(buffer) under certain early-return conditions
}`
};

export const DeepThinkingIntelligence: React.FC = () => {
  const { user } = useAuth();
  const [code, setCode] = useState<string>(SAMPLE_SNIPPETS.concurrency);
  const [language, setLanguage] = useState<'cpp' | 'typescript' | 'c' | 'rust'>('cpp');
  const [focusArea, setFocusArea] = useState<'security' | 'architecture' | 'performance' | 'high_thinking'>('high_thinking');
  const [enableThinking, setEnableThinking] = useState<boolean>(true);
  const [isAuditing, setIsAuditing] = useState<boolean>(false);
  const [auditResult, setAuditResult] = useState<any | null>(null);
  const [recentAudits, setRecentAudits] = useState<FirestoreAuditRecord[]>([]);
  const [copiedFixId, setCopiedFixId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'thinking' | 'findings' | 'actionPlan'>('overview');

  // Load past audits from Firestore on mount
  useEffect(() => {
    fetchRecentAuditsFromFirestore(user?.email).then((list) => {
      setRecentAudits(list);
    });
  }, [user]);

  const handleRunDeepAudit = async () => {
    if (!code.trim()) return;

    setIsAuditing(true);
    try {
      const response = await fetch('/api/gemini/audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code,
          language,
          focusArea,
          licenseTier: 'Enterprise AI Edition',
          enableThinking,
        }),
      });

      const data = await response.json();
      if (data.success && data.audit) {
        setAuditResult(data.audit);
        setActiveTab('findings');

        // Persist to Cloud Firestore
        const auditRecord: FirestoreAuditRecord = {
          id: 'audit_' + Date.now(),
          userId: user?.uid,
          userEmail: user?.email,
          codeSnippet: code.substring(0, 200) + '...',
          language,
          summary: data.audit.summary,
          thinkingProcess: data.audit.thinkingProcess,
          modelUsed: data.audit.modelUsed || (enableThinking ? 'gemini-3.1-pro-preview (ThinkingLevel.HIGH)' : 'gemini-3.5-flash'),
          securityScore: data.audit.metrics?.securityScore || 85,
          maintainabilityIndex: data.audit.metrics?.maintainabilityIndex || 80,
          findingsCount: data.audit.keyFindings?.length || 0,
          createdAt: new Date().toISOString(),
        };

        saveAuditToFirestore(auditRecord);
        setRecentAudits((prev) => [auditRecord, ...prev]);
      }
    } catch (err) {
      console.error('Deep thinking audit error:', err);
    } finally {
      setIsAuditing(false);
    }
  };

  const handleCopyCode = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedFixId(id);
    setTimeout(() => setCopiedFixId(null), 2000);
  };

  return (
    <div className="py-12 bg-slate-900 text-slate-100 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 space-y-8">
        
        {/* Header with High-Thinking Badge */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-800">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                <BrainCircuit className="w-3.5 h-3.5 text-indigo-400" />
                Gemini 3.1 Pro Preview &bull; High Thinking Engine
              </span>
              <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                Firestore Synchronized
              </span>
            </div>
            <h1 className="text-3xl font-extrabold text-white tracking-tight">
              Deep Thinking Code Architecture &amp; Vulnerability Audit
            </h1>
            <p className="text-slate-400 text-sm max-w-2xl">
              Leverage <span className="text-indigo-300 font-semibold">gemini-3.1-pro-preview</span> with multi-stage reasoning (<code className="text-xs bg-slate-800 px-1 py-0.5 rounded text-indigo-300">thinkingLevel: HIGH</code>) to perform AST data flow analysis, deadlock detection, and automated vulnerability remediation.
            </p>
          </div>

          {/* Quick sample loader */}
          <div className="flex items-center gap-2 bg-slate-800/80 p-2 rounded-xl border border-slate-700">
            <span className="text-xs text-slate-400 font-medium px-2">Sample Hazards:</span>
            <button
              onClick={() => {
                setCode(SAMPLE_SNIPPETS.concurrency);
                setLanguage('cpp');
              }}
              className="px-2.5 py-1 text-xs rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 transition-colors cursor-pointer"
            >
              Deadlock Lock Inversion
            </button>
            <button
              onClick={() => {
                setCode(SAMPLE_SNIPPETS.auth);
                setLanguage('typescript');
              }}
              className="px-2.5 py-1 text-xs rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 transition-colors cursor-pointer"
            >
              Timing Attack Auth
            </button>
            <button
              onClick={() => {
                setCode(SAMPLE_SNIPPETS.memory);
                setLanguage('c');
              }}
              className="px-2.5 py-1 text-xs rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 transition-colors cursor-pointer"
            >
              Buffer Slicer Overflow
            </button>
          </div>
        </div>

        {/* Main Grid: Code Input & Options on Left, Audit Results on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Code Editor & Controls */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-slate-800/90 rounded-2xl border border-slate-700 p-6 space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-indigo-400" />
                  Target Source Code
                </label>
                <div className="flex items-center gap-2">
                  <select
                    value={language}
                    onChange={(e: any) => setLanguage(e.target.value)}
                    className="bg-slate-900 border border-slate-700 text-xs rounded-lg px-2.5 py-1 text-slate-300 focus:outline-hidden focus:border-indigo-500"
                  >
                    <option value="cpp">C++ (ISO Standard)</option>
                    <option value="typescript">TypeScript / Node</option>
                    <option value="c">C99 / Systems</option>
                    <option value="rust">Rust (2021 Edition)</option>
                  </select>
                </div>
              </div>

              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                rows={14}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 font-mono text-xs text-slate-200 focus:outline-hidden focus:border-indigo-500 resize-none leading-relaxed"
                placeholder="Paste code or library functions to audit..."
              />

              {/* Controls */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/80 border border-slate-700/80">
                  <div className="flex items-center gap-2">
                    <BrainCircuit className="w-4 h-4 text-indigo-400" />
                    <div>
                      <span className="text-xs font-bold text-white block">High Thinking Mode</span>
                      <span className="text-[10px] text-slate-400 block">gemini-3.1-pro-preview with ThinkingLevel.HIGH</span>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={enableThinking}
                      onChange={(e) => setEnableThinking(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-slate-700 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setFocusArea('high_thinking')}
                    className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all text-left cursor-pointer ${
                      focusArea === 'high_thinking'
                        ? 'bg-indigo-600/30 border-indigo-500 text-white'
                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Cpu className="w-3.5 h-3.5 mb-1 text-indigo-400" />
                    Full Architecture Audit
                  </button>
                  <button
                    onClick={() => setFocusArea('security')}
                    className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all text-left cursor-pointer ${
                      focusArea === 'security'
                        ? 'bg-indigo-600/30 border-indigo-500 text-white'
                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <ShieldAlert className="w-3.5 h-3.5 mb-1 text-rose-400" />
                    Deep Vulnerability Taint
                  </button>
                </div>

                <button
                  id="btn-run-deep-audit"
                  onClick={handleRunDeepAudit}
                  disabled={isAuditing}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white font-bold text-sm shadow-lg shadow-indigo-600/25 flex items-center justify-center gap-2 cursor-pointer transition-all transform active:scale-98 disabled:opacity-50"
                >
                  {isAuditing ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin text-white" />
                      <span>Reasoning through AST &amp; Control Flows...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Execute Gemini High Thinking Audit</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Firestore Saved History */}
            {recentAudits.length > 0 && (
              <div className="bg-slate-800/70 rounded-2xl border border-slate-700/80 p-5 space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                  <span>Firestore Persistent Audit History</span>
                  <span className="text-[10px] text-indigo-400 font-mono">({recentAudits.length} Audits)</span>
                </h3>
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {recentAudits.slice(0, 5).map((aud, idx) => (
                    <div key={idx} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs flex items-center justify-between">
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-slate-200 truncate">{aud.summary}</p>
                        <p className="text-[10px] text-slate-500 font-mono mt-0.5">
                          Score: {aud.securityScore}/100 &bull; Model: {aud.modelUsed}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Deep Audit Report & Thinking Visualizer */}
          <div className="lg:col-span-7 space-y-6">
            {auditResult ? (
              <div className="bg-slate-800/90 rounded-2xl border border-slate-700 p-6 space-y-6 shadow-xl">
                
                {/* Metric Strip */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Security Score</span>
                    <span className={`text-2xl font-black ${
                      (auditResult.metrics?.securityScore || 0) >= 80 ? 'text-emerald-400' : 'text-amber-400'
                    }`}>
                      {auditResult.metrics?.securityScore ?? 88}<span className="text-xs font-normal text-slate-500">/100</span>
                    </span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Maintainability</span>
                    <span className="text-2xl font-black text-indigo-400">
                      {auditResult.metrics?.maintainabilityIndex ?? 82}<span className="text-xs font-normal text-slate-500">/100</span>
                    </span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Complexity</span>
                    <span className="text-2xl font-black text-slate-200">
                      {auditResult.metrics?.cyclomaticComplexity ?? 14}
                    </span>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-center">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Tech Debt Hours</span>
                    <span className="text-2xl font-black text-amber-400">
                      {auditResult.metrics?.estimatedTechnicalDebtHours ?? 8.5}h
                    </span>
                  </div>
                </div>

                {/* Tab Navigation */}
                <div className="flex items-center gap-2 border-b border-slate-700 pb-3">
                  <button
                    onClick={() => setActiveTab('findings')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                      activeTab === 'findings' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Vulnerabilities &amp; Fixes ({auditResult.keyFindings?.length || 0})
                  </button>
                  <button
                    onClick={() => setActiveTab('thinking')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${
                      activeTab === 'thinking' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <BrainCircuit className="w-3.5 h-3.5" />
                    High-Thinking Rationale
                  </button>
                  <button
                    onClick={() => setActiveTab('actionPlan')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                      activeTab === 'actionPlan' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Executive Action Plan
                  </button>
                </div>

                {/* Tab 1: Findings */}
                {activeTab === 'findings' && (
                  <div className="space-y-4">
                    <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Executive Summary</h4>
                      <p className="text-sm text-slate-300 leading-relaxed">{auditResult.summary}</p>
                    </div>

                    {auditResult.keyFindings?.map((item: any, idx: number) => (
                      <div key={idx} className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex items-center gap-2">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                              item.severity === 'critical' || item.severity === 'high'
                                ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                                : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            }`}>
                              {item.severity}
                            </span>
                            <span className="text-xs text-slate-400 font-mono">{item.category}</span>
                            {item.lineRange && (
                              <span className="text-[10px] text-indigo-400 bg-indigo-950/60 px-1.5 py-0.5 rounded">
                                {item.lineRange}
                              </span>
                            )}
                          </div>
                          <span className="text-xs font-mono text-slate-500">{item.id}</span>
                        </div>

                        <h4 className="text-sm font-bold text-white">{item.title}</h4>
                        <p className="text-xs text-slate-300 leading-relaxed">{item.description}</p>

                        {/* Suggested Code Replacement */}
                        {item.codeSnippetAfter && (
                          <div className="space-y-1.5 pt-2">
                            <div className="flex items-center justify-between text-[11px] font-semibold text-emerald-400">
                              <span className="flex items-center gap-1">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                Automated AST Transformation Fix
                              </span>
                              <button
                                onClick={() => handleCopyCode(item.id, item.codeSnippetAfter)}
                                className="flex items-center gap-1 text-[10px] text-slate-400 hover:text-slate-200 cursor-pointer"
                              >
                                {copiedFixId === item.id ? (
                                  <>
                                    <Check className="w-3 h-3 text-emerald-400" />
                                    <span>Copied</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="w-3 h-3" />
                                    <span>Copy Patch</span>
                                  </>
                                )}
                              </button>
                            </div>
                            <pre className="p-3 rounded-lg bg-slate-950 border border-emerald-900/50 text-[11px] font-mono text-emerald-300 overflow-x-auto">
                              {item.codeSnippetAfter}
                            </pre>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* Tab 2: High Thinking Process */}
                {activeTab === 'thinking' && (
                  <div className="space-y-4">
                    <div className="p-4 rounded-xl bg-indigo-950/30 border border-indigo-800/40 space-y-2">
                      <div className="flex items-center gap-2">
                        <BrainCircuit className="w-4 h-4 text-indigo-400" />
                        <span className="text-xs font-bold text-indigo-300">Gemini 3.1 Pro Preview Thinking Trace</span>
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line font-mono bg-slate-950 p-4 rounded-lg border border-slate-800">
                        {auditResult.thinkingProcess || 'Thinking process synthesized.'}
                      </p>
                    </div>
                  </div>
                )}

                {/* Tab 3: Action Plan */}
                {activeTab === 'actionPlan' && (
                  <div className="space-y-3">
                    {auditResult.executiveActionPlan?.map((plan: string, i: number) => (
                      <div key={i} className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-start gap-3">
                        <div className="w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                          {i + 1}
                        </div>
                        <p className="text-xs text-slate-200 leading-relaxed">{plan}</p>
                      </div>
                    ))}
                  </div>
                )}

              </div>
            ) : (
              /* Idle state placeholder */
              <div className="bg-slate-800/50 rounded-2xl border border-dashed border-slate-700 p-12 text-center space-y-4">
                <div className="w-16 h-16 rounded-2xl bg-indigo-950/80 border border-indigo-800/60 text-indigo-400 flex items-center justify-center mx-auto shadow-inner">
                  <BrainCircuit className="w-8 h-8" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-lg font-bold text-white">Ready for High-Thinking Deep Audit</h3>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    Select a sample hazard above or paste your own code, then click <strong className="text-indigo-300">Execute Gemini High Thinking Audit</strong> to generate complete vulnerability proofs and automated fixes.
                  </p>
                </div>
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
