import React, { useState } from 'react';
import { 
  X, CheckCircle2, ShieldCheck, Copy, Check, Download, 
  Terminal, Mail, Key, Laptop, ArrowRight, Sparkles, ExternalLink
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { SerialLicense } from '../types';

interface SerialCodeSuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  license: SerialLicense | null;
  onOpenSandboxWithKey: (key: string) => void;
  onViewEmailReceipt?: (emailData: any) => void;
  dispatchedEmail?: any;
}

export const SerialCodeSuccessModal: React.FC<SerialCodeSuccessModalProps> = ({
  isOpen,
  onClose,
  license,
  onOpenSandboxWithKey,
  onViewEmailReceipt,
  dispatchedEmail,
}) => {
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedEnv, setCopiedEnv] = useState(false);

  if (!isOpen || !license) return null;

  const copyToClipboard = (text: string, type: 'key' | 'env') => {
    navigator.clipboard.writeText(text);
    if (type === 'key') {
      setCopiedKey(true);
      setTimeout(() => setCopiedKey(false), 2000);
    } else {
      setCopiedEnv(true);
      setTimeout(() => setCopiedEnv(false), 2000);
    }
  };

  const downloadLicenseFile = () => {
    const licContent = JSON.stringify({
      product: 'Code Sence Software Intelligence',
      serialKey: license.licenseKey,
      plan: license.planName,
      customer: license.customerName,
      email: license.customerEmail,
      limits: license.limits,
      issuedAt: license.createdAt,
      expiresAt: license.expiresAt,
      signature: license.digitalSignature,
    }, null, 2);

    const blob = new Blob([licContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `codesence-${license.planId}-license.lic`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden text-slate-800">
        
        {/* Header Ribbon */}
        <div className="px-6 py-4 bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400 shadow-xs">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white tracking-tight">Payment Complete &amp; Verified</h3>
                <span className="text-[10px] uppercase font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                  Status: Active
                </span>
              </div>
              <p className="text-xs text-indigo-200">Your Official Cryptographic Serial License Code</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-300 hover:text-white p-2 rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6">
          
          {/* Main Success Announcement Card */}
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-start gap-3.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="text-xs text-emerald-900 space-y-0.5">
              <p className="font-bold text-sm text-emerald-950">
                Congratulations, {license.customerName}! Your Code Sence {license.planName} Plan is Live.
              </p>
              <p className="text-emerald-700">
                A digital certificate and invoice receipt have been sent to <strong>{license.customerEmail}</strong>.
              </p>
            </div>
          </div>

          {/* Primary High-Impact Serial Key Box */}
          <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900 to-indigo-950 text-white border-2 border-indigo-500/40 shadow-xl space-y-4 relative overflow-hidden">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 font-bold text-indigo-300 uppercase tracking-wider text-[11px]">
                <Key className="w-4 h-4 text-emerald-400" />
                <span>Your Official Serial Code:</span>
              </div>
              <span className="bg-indigo-500/30 text-indigo-200 px-2.5 py-0.5 rounded-full text-[10px] font-mono border border-indigo-400/30">
                256-BIT CRYPTO SIGNED
              </span>
            </div>

            {/* The Monospace Key */}
            <div className="p-4 rounded-xl bg-black/60 border border-indigo-500/50 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-inner">
              <span className="font-mono text-lg sm:text-2xl font-black text-emerald-400 tracking-wider select-all text-center sm:text-left break-all">
                {license.licenseKey}
              </span>

              <button
                onClick={() => copyToClipboard(license.licenseKey, 'key')}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-lg hover:shadow-emerald-500/30 cursor-pointer shrink-0"
              >
                {copiedKey ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
                <span>{copiedKey ? 'Serial Code Copied!' : 'Copy Serial Code'}</span>
              </button>
            </div>

            {/* License Metadata Matrix */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-[11px] font-mono">
              <div className="bg-white/5 border border-white/10 rounded-xl p-2.5">
                <span className="text-slate-400 block text-[10px] uppercase font-sans font-semibold">Tier</span>
                <span className="font-bold text-white mt-0.5 block">{license.planName}</span>
              </div>
              <div className="bg-white/5 border border-white/10 rounded-xl p-2.5">
                <span className="text-slate-400 block text-[10px] uppercase font-sans font-semibold">Projects Quota</span>
                <span className="font-bold text-indigo-300 mt-0.5 block">{license.limits.maxProjects}</span>
              </div>
              <div className="bg-white/5 border border-white/10 rounded-xl p-2.5">
                <span className="text-slate-400 block text-[10px] uppercase font-sans font-semibold">Analyses / Mo</span>
                <span className="font-bold text-indigo-300 mt-0.5 block">{license.limits.maxAnalysesPerMonth.toLocaleString()}</span>
              </div>
              <div className="bg-white/5 border border-white/10 rounded-xl p-2.5">
                <span className="text-slate-400 block text-[10px] uppercase font-sans font-semibold">Workstations</span>
                <span className="font-bold text-emerald-400 mt-0.5 block">{license.maxMachineActivations} slots</span>
              </div>
            </div>
          </div>

          {/* Quick Step Guide: Where to use this serial code */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              <span>How to Activate &amp; Use Your Serial Code</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Option 1: Windows App */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                  <Laptop className="w-4 h-4 text-indigo-600" />
                  <span>1. Windows run.bat</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Open downloaded <code className="text-indigo-600 font-mono font-semibold">run.bat</code> and paste your serial code when prompted.
                </p>
              </div>

              {/* Option 2: CLI / Env */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                  <Terminal className="w-4 h-4 text-indigo-600" />
                  <span>2. CLI Environment</span>
                </div>
                <button
                  onClick={() => copyToClipboard(`export CODESENSE_LICENSE_KEY="${license.licenseKey}"`, 'env')}
                  className="w-full text-left p-1.5 rounded-lg bg-white border border-slate-200 text-[10px] font-mono text-indigo-700 hover:bg-indigo-50 transition-colors flex items-center justify-between gap-1"
                >
                  <span className="truncate">export CODESENSE_KEY...</span>
                  {copiedEnv ? <Check className="w-3 h-3 text-emerald-600 shrink-0" /> : <Copy className="w-3 h-3 text-slate-400 shrink-0" />}
                </button>
              </div>

              {/* Option 3: License File */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                  <Download className="w-4 h-4 text-indigo-600" />
                  <span>3. Offline Certificate</span>
                </div>
                <button
                  onClick={downloadLicenseFile}
                  className="w-full py-1.5 px-2 rounded-lg bg-white border border-slate-200 text-[11px] font-semibold text-slate-700 hover:bg-slate-100 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3 h-3 text-indigo-600" />
                  <span>Download .lic</span>
                </button>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
            <button
              onClick={() => {
                onClose();
                onOpenSandboxWithKey(license.licenseKey);
              }}
              className="w-full sm:flex-1 py-3.5 px-4 rounded-xl text-sm font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Terminal className="w-4 h-4" />
              <span>Launch Live Software Sandbox with Key</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {dispatchedEmail && onViewEmailReceipt && (
              <button
                onClick={() => {
                  onClose();
                  onViewEmailReceipt(dispatchedEmail);
                }}
                className="w-full sm:w-auto py-3.5 px-5 rounded-xl text-sm font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Mail className="w-4 h-4 text-indigo-600" />
                <span>View Email Receipt</span>
              </button>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
