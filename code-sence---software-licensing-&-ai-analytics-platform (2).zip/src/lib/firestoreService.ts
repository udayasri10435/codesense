import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  serverTimestamp 
} from 'firebase/firestore';
import { db } from './firebase';
import { SerialLicense } from '../types';

export interface FirestoreAuditRecord {
  id: string;
  userId?: string;
  userEmail?: string;
  codeSnippet: string;
  language: string;
  summary: string;
  thinkingProcess?: string;
  modelUsed: string;
  securityScore: number;
  maintainabilityIndex: number;
  findingsCount: number;
  createdAt: any;
}

// Save issued license to Firestore
export async function saveLicenseToFirestore(license: SerialLicense): Promise<void> {
  try {
    const licenseRef = doc(db, 'licenses', license.licenseKey);
    await setDoc(licenseRef, {
      ...license,
      updatedAt: serverTimestamp(),
      persistedAt: new Date().toISOString(),
    }, { merge: true });
    console.log(`License ${license.licenseKey} persisted to Firestore.`);
  } catch (err) {
    console.warn('Firestore license persist notice:', err);
  }
}

// Fetch user licenses from Firestore
export async function fetchUserLicensesFromFirestore(email: string): Promise<SerialLicense[]> {
  try {
    const q = query(
      collection(db, 'licenses'),
      where('customerEmail', '==', email.toLowerCase().trim())
    );
    const snap = await getDocs(q);
    const results: SerialLicense[] = [];
    snap.forEach((docSnap) => {
      results.push(docSnap.data() as SerialLicense);
    });
    return results;
  } catch (err) {
    console.warn('Firestore fetch user licenses notice:', err);
    return [];
  }
}

// Save Gemini Deep Thinking AI Audit to Firestore
export async function saveAuditToFirestore(audit: FirestoreAuditRecord): Promise<void> {
  try {
    const auditRef = doc(db, 'ai_audits', audit.id);
    await setDoc(auditRef, {
      ...audit,
      createdAt: serverTimestamp(),
      savedAt: new Date().toISOString(),
    }, { merge: true });
  } catch (err) {
    console.warn('Firestore audit persist notice:', err);
  }
}

// Fetch recent AI Audits
export async function fetchRecentAuditsFromFirestore(userEmail?: string): Promise<FirestoreAuditRecord[]> {
  try {
    const auditsRef = collection(db, 'ai_audits');
    const snap = await getDocs(auditsRef);
    const list: FirestoreAuditRecord[] = [];
    snap.forEach((d) => {
      const data = d.data() as FirestoreAuditRecord;
      if (!userEmail || data.userEmail === userEmail) {
        list.push(data);
      }
    });
    return list;
  } catch (err) {
    console.warn('Firestore fetch audits notice:', err);
    return [];
  }
}
