export type PlanId = 'free' | 'pro' | 'team' | 'enterprise' | 'education';
export type BillingInterval = 'monthly' | 'yearly' | 'lifetime';

export interface PlanLimit {
  maxProjects: number | 'Unlimited';
  maxAnalysesPerMonth: number | 'Unlimited';
  seats: number | 'Unlimited';
  apiRateLimit: string;
}

export interface SubscriptionPlan {
  id: PlanId;
  name: string;
  badge?: string;
  tagline: string;
  monthlyPrice: number;
  yearlyPrice: number;
  limits: PlanLimit;
  features: string[];
  highlighted?: boolean;
  colorTheme: string;
  targetAudience: string;
}

export interface MachineActivation {
  machineId: string;
  hostname: string;
  os: string;
  activatedAt: string;
  lastPing: string;
}

export interface SerialLicense {
  licenseKey: string; // e.g. CS-PRO-8F2A-91K2-3341-9A0B
  planId: PlanId;
  planName: string;
  customerName: string;
  customerEmail: string;
  company?: string;
  createdAt: string;
  expiresAt: string;
  status: 'active' | 'expired' | 'revoked';
  billingInterval: BillingInterval;
  amountPaid: number;
  currency: string;
  transactionId: string;
  paymentMethod: string;
  invoiceNumber: string;
  limits: PlanLimit;
  features: string[];
  activeMachines: MachineActivation[];
  maxMachineActivations: number;
  digitalSignature: string;
}

export interface CheckoutRequest {
  planId: PlanId;
  billingInterval: BillingInterval;
  customerName: string;
  customerEmail: string;
  company?: string;
  country: string;
  paymentMethod: 'card' | 'paypal' | 'apple_pay' | 'crypto';
  cardDetails?: {
    cardNumber: string;
    expiry: string;
    cvc: string;
    cardHolder: string;
  };
}

export interface CheckoutResponse {
  success: boolean;
  message: string;
  license: SerialLicense;
  emailDispatched: {
    to: string;
    subject: string;
    sentAt: string;
    previewHtml: string;
  };
}

export interface VerifyLicenseResponse {
  valid: boolean;
  message: string;
  license?: SerialLicense;
  tamperProofValid?: boolean;
  remainingDays?: number;
}

export interface CodeAnalysisResult {
  projectName: string;
  language: string;
  filesScanned: number;
  linesOfCode: number;
  technicalDebtHours: number;
  qualityScore: number; // 0 - 100
  maintainabilityRating: 'A' | 'B' | 'C' | 'D' | 'F';
  duplicatedLinesPercent: number;
  securityVulnerabilities: {
    severity: 'critical' | 'high' | 'medium' | 'low';
    rule: string;
    file: string;
    line: number;
    suggestion: string;
  }[];
  refactoringOpportunities: {
    title: string;
    impact: 'High' | 'Medium' | 'Low';
    effort: string;
    description: string;
    codeSnippetBefore: string;
    codeSnippetAfter: string;
  }[];
}

export interface AuthUser {
  id: string;
  uid?: string;
  email: string;
  name: string;
  picture?: string;
  givenName?: string;
  familyName?: string;
  provider: 'google';
  verifiedEmail?: boolean;
  verified_email?: boolean;
  signedInAt: string;
}

export interface AuthState {
  user: AuthUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface ApiEndpointUsage {
  endpoint: string;
  name: string;
  count: number;
  avgLatencyMs: number;
  successRate: number;
}

export interface UsageTimelinePoint {
  time: string;
  calls: number;
  p95LatencyMs: number;
  errors: number;
}

export interface LicenseUsageStats {
  licenseKey: string;
  planId: PlanId;
  planName: string;
  totalCallsCurrentMonth: number;
  monthlyQuota: number | 'Unlimited';
  percentageUsed: number;
  rateLimitPerMinute: number;
  currentQps: number;
  peakThroughputRpm: number;
  uptimePercentage: number;
  cacheHitRatio: number;
  avgLatencyMs: number;
  p95LatencyMs: number;
  p99LatencyMs: number;
  errorRatePercentage: number;
  cycleResetDate: string;
  endpoints: ApiEndpointUsage[];
  timeline: UsageTimelinePoint[];
  machineAttribution: {
    machineId: string;
    hostname: string;
    callsCount: number;
    lastActive: string;
  }[];
  recentActivityLogs: {
    id: string;
    timestamp: string;
    endpoint: string;
    method: 'GET' | 'POST';
    statusCode: number;
    latencyMs: number;
    ipOrHost: string;
    status: 'success' | 'rate_limited' | 'error';
  }[];
}

export interface WindowsDownloadStats {
  totalDownloads: number;
  todayDownloads: number;
  version: string;
  releaseName: string;
  fileSize: string;
  freeStartingPoints: number;
  downloadUrl: string;
  executionFile: string;
  sha256Checksum: string;
  compatibility: string[];
  lastUpdated: string;
  recentDownloads?: {
    id: string;
    timestamp: string;
    os: string;
    country: string;
    pointsGranted: number;
  }[];
}

