import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { PricingSection } from './components/PricingSection';
import { SoftwareSandbox } from './components/SoftwareSandbox';
import { LicenseVerifier } from './components/LicenseVerifier';
import { LicenseManager } from './components/LicenseManager';
import { FeatureDeepDive } from './components/FeatureDeepDive';
import { DeepThinkingIntelligence } from './components/DeepThinkingIntelligence';
import { WindowsDownloadSection } from './components/WindowsDownloadSection';
import { WindowsDownloadModal } from './components/WindowsDownloadModal';
import { CheckoutModal } from './components/CheckoutModal';
import { EmailReceiptModal } from './components/EmailReceiptModal';
import { SerialCodeSuccessModal } from './components/SerialCodeSuccessModal';
import { GoogleLoginModal } from './components/GoogleLoginModal';
import { Footer } from './components/Footer';
import { SUBSCRIPTION_PLANS } from './data/plans';
import { SubscriptionPlan, BillingInterval, SerialLicense, WindowsDownloadStats } from './types';
import { AuthProvider, useAuth } from './context/AuthContext';
import { KeyRound, Sparkles, Terminal, Mail, CheckCircle2, ArrowRight, Download, Laptop, Key, Copy, Check } from 'lucide-react';

function MainApp() {
  const { isLoginModalOpen, closeLoginModal } = useAuth();
  const [activeTab, setActiveTab] = useState<'home' | 'pricing' | 'download' | 'sandbox' | 'verifier' | 'portal' | 'features' | 'ai-audit'>('home');
  
  // Checkout modal state
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan>(SUBSCRIPTION_PLANS[1]); // Default PRO
  const [checkoutInterval, setCheckoutInterval] = useState<BillingInterval>('yearly');
  
  // Email receipt modal state
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [activeDispatchedEmail, setActiveDispatchedEmail] = useState<any>(null);

  // Serial code success modal state
  const [isSerialModalOpen, setIsSerialModalOpen] = useState(false);
  const [copiedKeyToast, setCopiedKeyToast] = useState(false);

  // Windows download modal state & stats
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [downloadStats, setDownloadStats] = useState<WindowsDownloadStats | null>(() => {
    try {
      const saved = localStorage.getItem('codesense_custom_downloads');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed.totalDownloads === 'number') {
          return {
            totalDownloads: parsed.totalDownloads,
            todayDownloads: parsed.todayDownloads || 148,
            version: '2.4.0-Release (Build #4892)',
            releaseName: 'Code Sence Windows Desktop & Local Engine',
            fileSize: '48.2 MB',
            freeStartingPoints: 1000,
            downloadUrl: 'https://drive.google.com/file/d/10C5aBQRInoeCRzAMedUm9mBjhwBQiQ03/view?usp=sharing',
            executionFile: 'run.bat',
            sha256Checksum: 'd8f2a4198ec0028a49c951fa69e0018f29402ab8419ef2018a1a9e87189fa91b',
            compatibility: ['Windows 11', 'Windows 10', 'Windows Server'],
            lastUpdated: parsed.lastUpdated || new Date().toISOString(),
          };
        }
      }
    } catch (e) {
      // fallback
    }
    return {
      totalDownloads: 0,
      todayDownloads: 0,
      version: '2.4.0-Release (Build #4892)',
      releaseName: 'Code Sence Windows Desktop & Local Engine',
      fileSize: '48.2 MB',
      freeStartingPoints: 1000,
      downloadUrl: 'https://drive.google.com/file/d/10C5aBQRInoeCRzAMedUm9mBjhwBQiQ03/view?usp=sharing',
      executionFile: 'run.bat',
      sha256Checksum: 'd8f2a4198ec0028a49c951fa69e0018f29402ab8419ef2018a1a9e87189fa91b',
      compatibility: ['Windows 11', 'Windows 10', 'Windows Server'],
      lastUpdated: new Date().toISOString(),
    };
  });

  // Active key in sandbox
  const [sandboxKey, setSandboxKey] = useState<string>('');
  
  // Active recent license banner loaded from storage if available
  const [lastIssuedLicense, setLastIssuedLicense] = useState<SerialLicense | null>(() => {
    try {
      const savedLic = localStorage.getItem('codesense_last_license');
      if (savedLic) return JSON.parse(savedLic);
    } catch (e) {}
    return null;
  });

  // Fetch download stats on mount & poll every 4s for present-time live calculate
  useEffect(() => {
    const fetchLatestDownloads = () => {
      fetch('/api/downloads/stats')
        .then(res => res.json())
        .then(data => {
          if (data.success && data.stats) {
            setDownloadStats(data.stats);
          }
        })
        .catch(err => console.warn('Could not sync download stats:', err));
    };

    fetchLatestDownloads();
    const interval = setInterval(fetchLatestDownloads, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleDownloadIncrement = (updatedStats?: WindowsDownloadStats) => {
    if (updatedStats) {
      setDownloadStats(updatedStats);
      try {
        localStorage.setItem('codesense_custom_downloads', JSON.stringify({
          totalDownloads: updatedStats.totalDownloads,
          todayDownloads: updatedStats.todayDownloads,
          lastUpdated: updatedStats.lastUpdated,
        }));
      } catch (e) {}
    } else {
      // Optimistic +1 increment immediately
      setDownloadStats(prev => {
        if (!prev) return null;
        const next = {
          ...prev,
          totalDownloads: prev.totalDownloads + 1,
          todayDownloads: prev.todayDownloads + 1,
          lastUpdated: new Date().toISOString(),
        };
        try {
          localStorage.setItem('codesense_custom_downloads', JSON.stringify({
            totalDownloads: next.totalDownloads,
            todayDownloads: next.todayDownloads,
            lastUpdated: next.lastUpdated,
          }));
        } catch (e) {}
        return next;
      });
    }
  };

  const handleOpenCheckout = (planId?: string) => {
    if (planId === 'free') {
      setSandboxKey('');
      setActiveTab('sandbox');
      return;
    }
    if (planId) {
      const found = SUBSCRIPTION_PLANS.find(p => p.id === planId);
      if (found) setSelectedPlan(found);
    }
    setIsCheckoutOpen(true);
  };

  const handleSelectPlan = (plan: SubscriptionPlan, interval: BillingInterval) => {
    if (plan.id === 'free') {
      // Free mode requires no serial key or checkout: launch sandbox directly!
      setSandboxKey('');
      setActiveTab('sandbox');
      return;
    }
    setSelectedPlan(plan);
    setCheckoutInterval(interval);
    setIsCheckoutOpen(true);
  };

  const handleCheckoutSuccess = (license: SerialLicense, emailData: any) => {
    setLastIssuedLicense(license);
    setActiveDispatchedEmail(emailData);
    setSandboxKey(license.licenseKey);
    try {
      localStorage.setItem('codesense_last_license', JSON.stringify(license));
      const existing = localStorage.getItem('codesense_my_licenses');
      const list = existing ? JSON.parse(existing) : [];
      const updated = [license, ...list.filter((l: any) => l.licenseKey !== license.licenseKey)];
      localStorage.setItem('codesense_my_licenses', JSON.stringify(updated));
    } catch (e) {}
    setIsSerialModalOpen(true);
  };

  const handleCopyKeyFromBanner = (key: string) => {
    navigator.clipboard.writeText(key);
    setCopiedKeyToast(true);
    setTimeout(() => setCopiedKeyToast(false), 2200);
  };

  const handleOpenSandboxWithKey = (key: string) => {
    setSandboxKey(key);
    setActiveTab('sandbox');
  };

  const handleVerifySpecificKey = (key: string) => {
    setSandboxKey(key);
    setActiveTab('verifier');
  };

  const handleViewEmail = (emailData: any) => {
    setActiveDispatchedEmail(emailData);
    setIsEmailModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-indigo-600 selection:text-white">
      {/* Top Automated Dispatch Status Notification if a key was just generated */}
      {lastIssuedLicense && (
        <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-900 border-b border-indigo-500/40 px-4 py-2.5 text-xs text-slate-100 shadow-md">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
              <span className="font-bold text-white text-[12px] whitespace-nowrap">
                Active Serial Code:
              </span>
              <code className="font-mono bg-black/80 px-2.5 py-1 rounded-lg text-emerald-400 border border-emerald-500/40 font-black tracking-wider text-[12px] select-all">
                {lastIssuedLicense.licenseKey}
              </code>
              <button
                onClick={() => handleCopyKeyFromBanner(lastIssuedLicense.licenseKey)}
                className="px-2.5 py-1 rounded-md bg-white/10 hover:bg-white/20 text-white font-semibold text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
                title="Copy serial code"
              >
                {copiedKeyToast ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKeyToast ? 'Copied!' : 'Copy'}</span>
              </button>
              <span className="text-indigo-200 hidden md:inline text-[11px]">
                ({lastIssuedLicense.planName} Tier • {lastIssuedLicense.customerEmail})
              </span>
            </div>

            <div className="flex items-center gap-2 sm:gap-3">
              <button
                onClick={() => setIsSerialModalOpen(true)}
                className="px-3 py-1 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-200 hover:text-white font-semibold text-[11px] border border-indigo-400/30 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Key className="w-3.5 h-3.5 text-emerald-400" />
                <span>Show Code Details</span>
              </button>

              {activeDispatchedEmail && (
                <button
                  onClick={() => setIsEmailModalOpen(true)}
                  className="text-indigo-300 hover:text-white font-medium text-[11px] flex items-center gap-1 transition-colors cursor-pointer hidden sm:flex"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Email Receipt</span>
                </button>
              )}

              <button
                onClick={() => handleOpenSandboxWithKey(lastIssuedLicense.licenseKey)}
                className="px-3 py-1 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center gap-1 shadow-sm transition-colors cursor-pointer"
              >
                <Terminal className="w-3 h-3" />
                <span>Test in CLI →</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenCheckout={handleOpenCheckout}
        onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
        downloadCount={downloadStats?.totalDownloads}
        activeLicense={lastIssuedLicense}
        onOpenSerialModal={() => setIsSerialModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <div>
            <Hero
              onSelectPricing={() => {
                setActiveTab('pricing');
                const el = document.getElementById('pricing-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              onOpenSandbox={() => setActiveTab('sandbox')}
              onOpenVerifier={() => setActiveTab('verifier')}
              onQuickCheckout={handleOpenCheckout}
              onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
              downloadCount={downloadStats?.totalDownloads}
            />

            {/* Dedicated Windows Download Highlight Section on Home */}
            <WindowsDownloadSection
              onOpenSandbox={() => setActiveTab('sandbox')}
              onOpenPricing={() => setActiveTab('pricing')}
              onDownloadIncrement={handleDownloadIncrement}
            />

            {/* Embedded Pricing Section */}
            <PricingSection
              onSelectPlan={handleSelectPlan}
              onOpenVerifier={() => setActiveTab('verifier')}
            />

            {/* Deep Dive Features Section */}
            <FeatureDeepDive onOpenCheckout={handleOpenCheckout} />
          </div>
        )}

        {activeTab === 'download' && (
          <WindowsDownloadSection
            onOpenSandbox={() => setActiveTab('sandbox')}
            onOpenPricing={() => setActiveTab('pricing')}
            onDownloadIncrement={handleDownloadIncrement}
          />
        )}

        {activeTab === 'pricing' && (
          <PricingSection
            onSelectPlan={handleSelectPlan}
            onOpenVerifier={() => setActiveTab('verifier')}
          />
        )}

        {activeTab === 'sandbox' && (
          <SoftwareSandbox
            initialKey={sandboxKey}
            onOpenPricing={() => setActiveTab('pricing')}
            onOpenCheckout={handleOpenCheckout}
          />
        )}

        {activeTab === 'verifier' && (
          <LicenseVerifier
            onOpenCheckout={handleOpenCheckout}
            onOpenSandboxWithKey={handleOpenSandboxWithKey}
          />
        )}

        {activeTab === 'features' && (
          <FeatureDeepDive onOpenCheckout={handleOpenCheckout} />
        )}

        {activeTab === 'portal' && (
          <LicenseManager
            onOpenSandboxWithKey={handleOpenSandboxWithKey}
            onOpenCheckout={handleOpenCheckout}
            onViewEmailReceipt={handleViewEmail}
          />
        )}

        {activeTab === 'ai-audit' && (
          <DeepThinkingIntelligence />
        )}
      </main>

      {/* Windows Download Modal */}
      <WindowsDownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
        onDownloadIncrement={handleDownloadIncrement}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        plan={selectedPlan}
        initialInterval={checkoutInterval}
        onSuccess={handleCheckoutSuccess}
        onOpenSandboxWithKey={handleOpenSandboxWithKey}
        onViewEmail={handleViewEmail}
      />

      {/* Serial Code Display Modal */}
      <SerialCodeSuccessModal
        isOpen={isSerialModalOpen}
        onClose={() => setIsSerialModalOpen(false)}
        license={lastIssuedLicense}
        onOpenSandboxWithKey={handleOpenSandboxWithKey}
        onViewEmailReceipt={handleViewEmail}
        dispatchedEmail={activeDispatchedEmail}
      />

      {/* Email Receipt Modal */}
      <EmailReceiptModal
        isOpen={isEmailModalOpen}
        onClose={() => setIsEmailModalOpen(false)}
        emailData={activeDispatchedEmail}
      />

      {/* Google Login Modal */}
      <GoogleLoginModal
        isOpen={isLoginModalOpen}
        onClose={closeLoginModal}
      />

      {/* Footer */}
      <Footer
        onSelectTab={setActiveTab}
        onOpenCheckout={handleOpenCheckout}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}

