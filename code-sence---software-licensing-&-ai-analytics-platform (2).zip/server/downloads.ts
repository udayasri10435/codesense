import { WindowsDownloadStats } from '../src/types';

export const WINDOWS_DOWNLOAD_URL = 'https://drive.google.com/file/d/10C5aBQRInoeCRzAMedUm9mBjhwBQiQ03/view?usp=sharing';

const COUNTRIES = [
  'United States', 'Germany', 'United Kingdom', 'Japan', 'Canada', 
  'France', 'Australia', 'Netherlands', 'India', 'Singapore', 'Sweden', 'Switzerland'
];

const OS_LIST = [
  'Windows 11 Pro x64', 'Windows 11 Enterprise', 'Windows 10 Pro 64-bit',
  'Windows Server 2022', 'Windows 11 ARM64', 'Windows 10 Enterprise'
];

// Persistent state initialized to 0 downloads
let baseDownloads = 0;
let todayDownloads = 0;
let lastCalculatedTime = Date.now();

let recentDownloads: {
  id: string;
  timestamp: string;
  os: string;
  country: string;
  pointsGranted: number;
}[] = [];

export function getDownloadStats(): WindowsDownloadStats {
  return {
    totalDownloads: baseDownloads,
    todayDownloads,
    version: '2.4.0-Release (Build #4892)',
    releaseName: 'CodeSense Windows Desktop & Local Engine',
    fileSize: '48.2 MB',
    freeStartingPoints: 1000,
    downloadUrl: WINDOWS_DOWNLOAD_URL,
    executionFile: 'run.bat',
    sha256Checksum: 'd8f2a4198ec0028a49c951fa69e0018f29402ab8419ef2018a1a9e87189fa91b',
    compatibility: [
      'Windows 11 (64-bit / ARM64)',
      'Windows 10 (Version 1909+)',
      'Windows Server 2019 / 2022',
      'PowerShell 5.1+ & Command Prompt (CMD)'
    ],
    lastUpdated: new Date().toISOString(),
    recentDownloads,
  };
}

export function setCustomDownloadCount(total: number, today?: number): WindowsDownloadStats {
  if (typeof total === 'number' && !isNaN(total) && total >= 0) {
    baseDownloads = Math.floor(total);
  }
  if (typeof today === 'number' && !isNaN(today) && today >= 0) {
    todayDownloads = Math.floor(today);
  }
  lastCalculatedTime = Date.now();
  return getDownloadStats();
}

export function recordDownload(clientInfo?: { os?: string; country?: string; userAgent?: string }): WindowsDownloadStats {
  baseDownloads += 1;
  todayDownloads += 1;
  lastCalculatedTime = Date.now();

  const newRecord = {
    id: `DL-${baseDownloads}`,
    timestamp: new Date().toISOString(),
    os: clientInfo?.os || 'Windows 11 x64',
    country: clientInfo?.country || 'Verified Developer',
    pointsGranted: 1000,
  };

  recentDownloads = [newRecord, ...recentDownloads.slice(0, 9)];
  return getDownloadStats();
}
