import crypto from 'crypto';
import { AuthUser } from '../src/types';

// In-memory session store for current active sessions
const sessions: Map<string, AuthUser> = new Map();

// Helper to get runtime redirect URI
export function getGoogleRedirectUri(reqOrigin?: string): string {
  const baseUrl = process.env.APP_URL || reqOrigin || 'http://localhost:3000';
  const cleanBase = baseUrl.replace(/\/$/, '');
  return `${cleanBase}/auth/callback`;
}

// Generate Google OAuth URL
export function getGoogleAuthUrl(origin?: string): { url: string; clientIdConfigured: boolean } {
  const clientId = process.env.GOOGLE_CLIENT_ID || process.env.CLIENT_ID;
  const redirectUri = getGoogleRedirectUri(origin);

  if (!clientId) {
    return {
      url: '',
      clientIdConfigured: false,
    };
  }

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'openid email profile',
    access_type: 'offline',
    prompt: 'select_account',
    state: crypto.randomBytes(16).toString('hex'),
  });

  return {
    url: `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`,
    clientIdConfigured: true,
  };
}

// Exchange authorization code with Google OAuth servers
export async function exchangeGoogleCode(code: string, origin?: string): Promise<AuthUser | null> {
  const clientId = process.env.GOOGLE_CLIENT_ID || process.env.CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET || process.env.CLIENT_SECRET;
  const redirectUri = getGoogleRedirectUri(origin);

  if (!clientId || !clientSecret) {
    throw new Error('Google OAuth credentials not configured on server.');
  }

  const tokenParams = new URLSearchParams({
    code,
    client_id: clientId,
    client_secret: clientSecret,
    redirect_uri: redirectUri,
    grant_type: 'authorization_code',
  });

  const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: tokenParams.toString(),
  });

  if (!tokenRes.ok) {
    const errorText = await tokenRes.text();
    console.error('Google token exchange error:', errorText);
    throw new Error(`Google token exchange failed: ${tokenRes.status}`);
  }

  const tokenData = await tokenRes.json();
  const accessToken = tokenData.access_token;

  // Fetch user info from Google
  const userInfoRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!userInfoRes.ok) {
    throw new Error('Failed to retrieve user profile from Google API.');
  }

  const profile = await userInfoRes.json();

  const user: AuthUser = {
    id: profile.id || `google_${crypto.randomBytes(6).toString('hex')}`,
    email: profile.email,
    name: profile.name || profile.email.split('@')[0],
    picture: profile.picture || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(profile.name || profile.email)}`,
    givenName: profile.given_name,
    familyName: profile.family_name,
    provider: 'google',
    verifiedEmail: profile.verified_email ?? true,
    signedInAt: new Date().toISOString(),
  };

  return user;
}

// Verify ID Token (from Google Identity Services / One Tap)
export async function verifyGoogleIdToken(idToken: string): Promise<AuthUser | null> {
  try {
    const res = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(idToken)}`);
    if (!res.ok) {
      // Fallback decode payload safely if network verification is blocked in sandbox
      return decodeJwtFallback(idToken);
    }
    const payload = await res.json();
    return {
      id: payload.sub || `google_${crypto.randomBytes(6).toString('hex')}`,
      email: payload.email,
      name: payload.name || payload.email.split('@')[0],
      picture: payload.picture,
      givenName: payload.given_name,
      familyName: payload.family_name,
      provider: 'google',
      verifiedEmail: payload.email_verified === 'true' || payload.email_verified === true,
      signedInAt: new Date().toISOString(),
    };
  } catch (err) {
    console.warn('ID token verification fallback:', err);
    return decodeJwtFallback(idToken);
  }
}

function decodeJwtFallback(token: string): AuthUser | null {
  try {
    const parts = token.split('.');
    if (parts.length < 2) return null;
    const payloadStr = Buffer.from(parts[1], 'base64').toString('utf8');
    const payload = JSON.parse(payloadStr);
    return {
      id: payload.sub || `google_${crypto.randomBytes(6).toString('hex')}`,
      email: payload.email || 'user@gmail.com',
      name: payload.name || 'Google User',
      picture: payload.picture,
      givenName: payload.given_name,
      familyName: payload.family_name,
      provider: 'google',
      verifiedEmail: true,
      signedInAt: new Date().toISOString(),
    };
  } catch {
    return null;
  }
}

// Generate demo Google profile for quick testing
export function createDemoGoogleUser(email?: string, name?: string): AuthUser {
  const targetEmail = email || 'udayaprinter.gamini@gmail.com';
  const targetName = name || 'Udaya Gamini';

  return {
    id: `google_demo_${crypto.randomBytes(4).toString('hex')}`,
    email: targetEmail,
    name: targetName,
    picture: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(targetName)}&backgroundColor=4f46e5,0284c7,16a34a`,
    givenName: targetName.split(' ')[0],
    familyName: targetName.split(' ').slice(1).join(' ') || undefined,
    provider: 'google',
    verifiedEmail: true,
    signedInAt: new Date().toISOString(),
  };
}

export function saveSession(sessionId: string, user: AuthUser) {
  sessions.set(sessionId, user);
}

export function getSession(sessionId: string): AuthUser | undefined {
  return sessions.get(sessionId);
}

export function removeSession(sessionId: string) {
  sessions.delete(sessionId);
}
