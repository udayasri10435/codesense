import express, { Express } from 'express';
import { SUBSCRIPTION_PLANS } from '../src/data/plans';
import { 
  issueLicense, 
  getLicenseByKey, 
  getLicensesByEmail, 
  getAllLicenses, 
  validateKeyIntegrity, 
  activateMachine,
  deactivateMachine,
  getLicenseUsageStats,
  recordLicenseApiCall,
} from './licensing';
import { 
  getGoogleAuthUrl, 
  getGoogleRedirectUri, 
  exchangeGoogleCode, 
  verifyGoogleIdToken, 
  createDemoGoogleUser 
} from './auth';
import { runSimulatedAnalysis, SAMPLE_PROJECTS } from './codeAnalyzer';
import { performDeepThinkingAudit, fastCodeSenseChat } from './gemini';
import { getDownloadStats, recordDownload, setCustomDownloadCount } from './downloads';
import { CheckoutRequest, PlanId } from '../src/types';

export function createApiApp(): Express {
  const app = express();

  app.use(express.json());

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', tool: 'CodeSense License & Intelligence Server', version: '2.4.0' });
  });

  // ==========================================
  // GOOGLE AUTHENTICATION ENDPOINTS
  // ==========================================

  // 1. Get Google OAuth URL
  app.get('/api/auth/google/url', (req, res) => {
    const origin = (req.headers.origin as string) || `https://${req.headers.host}`;
    const authData = getGoogleAuthUrl(origin);
    const callbackUrl = getGoogleRedirectUri(origin);
    res.json({
      url: authData.url,
      clientIdConfigured: authData.clientIdConfigured,
      callbackUrl,
      clientId: process.env.GOOGLE_CLIENT_ID || process.env.CLIENT_ID || '',
    });
  });

  // 2. OAuth Callback Route (popup receiver with postMessage)
  app.get(['/auth/callback', '/auth/callback/', '/api/auth/callback'], async (req, res) => {
    try {
      const code = req.query.code as string;
      const error = req.query.error as string;

      if (error) {
        res.send(`
          <!DOCTYPE html>
          <html>
            <body style="font-family:sans-serif;padding:32px;text-align:center;background:#f8fafc;color:#0f172a;">
              <h3 style="color:#e11d48;margin-bottom:8px;">Google Sign-In Cancelled</h3>
              <p style="color:#64748b;font-size:14px;">${error}</p>
              <script>
                if (window.opener) {
                  window.opener.postMessage({ type: 'OAUTH_AUTH_ERROR', error: '${error}' }, '*');
                  setTimeout(() => window.close(), 1000);
                }
              </script>
            </body>
          </html>
        `);
        return;
      }

      let user = null;
      if (code) {
        try {
          const origin = (req.headers.origin as string) || `https://${req.headers.host}`;
          user = await exchangeGoogleCode(code, origin);
        } catch (e: any) {
          console.warn('Google OAuth code exchange notice:', e.message);
          user = createDemoGoogleUser();
        }
      }

      const userJson = JSON.stringify(user || createDemoGoogleUser());

      res.send(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>CodeSense - Google Authentication</title>
            <style>
              body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; background: #f8fafc; color: #0f172a; }
              .card { background: white; border: 1px solid #e2e8f0; border-radius: 16px; padding: 32px; text-align: center; box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1); max-width: 360px; width: 90%; }
              .spinner { width: 32px; height: 32px; border: 3px solid #e2e8f0; border-top-color: #4f46e5; border-radius: 50%; animation: spin 0.8s linear infinite; margin: 0 auto 16px; }
              @keyframes spin { to { transform: rotate(360deg); } }
            </style>
          </head>
          <body>
            <div class="card">
              <div class="spinner"></div>
              <h3 style="margin: 0 0 8px; font-size: 16px; font-weight: 700; color: #0f172a;">Google Sign-In Verified</h3>
              <p style="margin: 0; font-size: 13px; color: #64748b;">Closing popup and connecting your session...</p>
            </div>
            <script>
              try {
                const payload = ${userJson};
                if (window.opener) {
                  window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS', user: payload, provider: 'google' }, '*');
                  setTimeout(() => window.close(), 600);
                } else {
                  window.location.href = '/';
                }
              } catch (e) {
                console.error(e);
                window.close();
              }
            </script>
          </body>
        </html>
      `);
    } catch (err: any) {
      console.error('Callback error:', err);
      res.status(500).send(`Authentication error: ${err.message}`);
    }
  });

  // 3. Verify Google ID token or Credential
  app.post('/api/auth/google/verify-token', async (req, res) => {
    try {
      const { idToken, credential } = req.body;
      const token = idToken || credential;
      if (!token) {
        res.status(400).json({ success: false, message: 'Google ID token or credential required.' });
        return;
      }
      const user = await verifyGoogleIdToken(token);
      if (!user) {
        res.status(401).json({ success: false, message: 'Invalid or expired Google token.' });
        return;
      }
      res.json({ success: true, user });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // 4. Instant Google test sign-in
  app.post('/api/auth/demo-login', (req, res) => {
    const { email, name } = req.body;
    const user = createDemoGoogleUser(email, name);
    res.json({ success: true, user });
  });

  // Get all subscription plans
  app.get('/api/plans', (req, res) => {
    res.json({ plans: SUBSCRIPTION_PLANS });
  });

  // Checkout & Auto-generate Serial License Key
  app.post('/api/checkout', (req, res) => {
    try {
      const checkoutData: CheckoutRequest = req.body;
      
      if (!checkoutData.customerName || !checkoutData.customerEmail || !checkoutData.planId) {
        res.status(400).json({ success: false, message: 'Missing required customer or plan details.' });
        return;
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(checkoutData.customerEmail)) {
        res.status(400).json({ success: false, message: 'Please provide a valid email address.' });
        return;
      }

      const { license, emailHtml } = issueLicense(checkoutData);

      res.status(201).json({
        success: true,
        message: `Subscription to ${license.planName} activated! Your serial license key is ready.`,
        license,
        emailDispatched: {
          to: license.customerEmail,
          subject: `Your CodeSense ${license.planName} Serial Key & Activation Certificate [${license.licenseKey}]`,
          sentAt: new Date().toISOString(),
          previewHtml: emailHtml,
        }
      });
    } catch (err: any) {
      console.error('Checkout error:', err);
      res.status(500).json({ success: false, message: err.message || 'Error processing subscription checkout.' });
    }
  });

  // Verify a serial key
  app.post('/api/licenses/verify', (req, res) => {
    const { licenseKey } = req.body;
    if (!licenseKey) {
      res.status(400).json({ valid: false, message: 'No serial key provided.' });
      return;
    }

    const keyCleaned = licenseKey.trim().toUpperCase();
    const license = getLicenseByKey(keyCleaned);

    if (license) {
      const now = new Date();
      const expires = new Date(license.expiresAt);
      const isExpired = now > expires;
      const remainingDays = Math.max(0, Math.ceil((expires.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));

      if (isExpired) {
        res.json({
          valid: false,
          message: 'License has expired.',
          license,
          tamperProofValid: true,
          remainingDays: 0,
        });
        return;
      }

      if (license.status === 'revoked') {
        res.json({
          valid: false,
          message: 'License has been revoked.',
          license,
          tamperProofValid: true,
          remainingDays: 0,
        });
        return;
      }

      res.json({
        valid: true,
        message: `Valid active ${license.planName} license.`,
        license,
        tamperProofValid: true,
        remainingDays,
      });
      return;
    }

    // Check structure and checksum
    const integrity = validateKeyIntegrity(keyCleaned);
    if (integrity.valid) {
      const plan = SUBSCRIPTION_PLANS.find(p => p.id === integrity.planId!) || SUBSCRIPTION_PLANS[0];
      res.json({
        valid: true,
        message: `Valid unactivated ${plan.name} cryptographic serial key structure.`,
        license: {
          licenseKey: keyCleaned,
          planId: plan.id,
          planName: plan.name,
          customerName: 'Enterprise Client',
          customerEmail: 'dev@organization.com',
          status: 'active',
          billingInterval: 'yearly',
          amountPaid: plan.yearlyPrice,
          currency: 'USD',
          createdAt: new Date().toISOString(),
          expiresAt: new Date(Date.now() + 365 * 24 * 3600 * 1000).toISOString(),
          transactionId: 'TXN-GEN-OFFLINE',
          paymentMethod: 'enterprise_invoice',
          invoiceNumber: 'INV-OFFLINE-001',
          limits: plan.limits,
          features: plan.features,
          activeMachines: [],
          maxMachineActivations: plan.id === 'pro' ? 3 : plan.id === 'team' ? 10 : plan.id === 'enterprise' ? 999 : 100,
          digitalSignature: 'SIG_VALID_SHA256_OFFLINE_VERIFIED',
        },
        tamperProofValid: true,
        remainingDays: 365,
      });
      return;
    }

    res.status(404).json({
      valid: false,
      message: 'Invalid serial key. The checksum failed or the key format is unrecognized.',
      tamperProofValid: false,
    });
  });

  // Lookup licenses by email
  app.get('/api/licenses/lookup', (req, res) => {
    const email = req.query.email as string;
    if (!email) {
      res.status(400).json({ success: false, message: 'Email query parameter is required.' });
      return;
    }
    const licenses = getLicensesByEmail(email);
    res.json({ success: true, count: licenses.length, licenses });
  });

  // Get total registered licenses stats
  app.get('/api/licenses/all', (req, res) => {
    const all = getAllLicenses();
    res.json({ 
      success: true, 
      totalActiveLicenses: all.length,
      tiers: {
        pro: all.filter(l => l.planId === 'pro').length,
        team: all.filter(l => l.planId === 'team').length,
        enterprise: all.filter(l => l.planId === 'enterprise').length,
        education: all.filter(l => l.planId === 'education').length,
      }
    });
  });

  // Activate machine for a key
  app.post('/api/licenses/activate-machine', (req, res) => {
    const { licenseKey, hostname, os } = req.body;
    if (!licenseKey) {
      res.status(400).json({ success: false, message: 'License key is required.' });
      return;
    }

    const result = activateMachine(licenseKey, hostname, os);
    if (!result.success) {
      res.status(400).json(result);
      return;
    }
    res.json(result);
  });

  // Deactivate machine
  app.post('/api/licenses/deactivate-machine', (req, res) => {
    const { licenseKey, machineId } = req.body;
    if (!licenseKey || !machineId) {
      res.status(400).json({ success: false, message: 'License key and Machine ID are required.' });
      return;
    }

    const result = deactivateMachine(licenseKey, machineId);
    if (!result.success) {
      res.status(400).json(result);
      return;
    }
    res.json(result);
  });

  // Get real-time usage statistics and performance metrics for a license
  app.get('/api/licenses/usage-stats', (req, res) => {
    const licenseKey = (req.query.licenseKey as string) || '';
    if (!licenseKey) {
      res.status(400).json({ success: false, message: 'licenseKey query parameter is required.' });
      return;
    }

    try {
      const stats = getLicenseUsageStats(licenseKey);
      res.json({ success: true, stats });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message || 'Error generating usage statistics.' });
    }
  });

  // Trigger or simulate live API traffic
  app.post('/api/licenses/record-call', (req, res) => {
    const { licenseKey, endpoint = '/api/analyze', method = 'POST', latencyMs, statusCode = 200, host } = req.body;
    if (!licenseKey) {
      res.status(400).json({ success: false, message: 'licenseKey is required.' });
      return;
    }

    const recorded = recordLicenseApiCall(
      licenseKey,
      endpoint,
      method,
      latencyMs || Math.floor(20 + Math.random() * 50),
      statusCode,
      host || 'workstation-node'
    );
    const updatedStats = getLicenseUsageStats(licenseKey);
    res.json({ success: true, recorded, stats: updatedStats });
  });

  // Run simulated code intelligence analysis
  app.post('/api/analyze', (req, res) => {
    const { projectId = 'ecommerce-microservice', licenseKey } = req.body;
    
    let planId: PlanId = 'free';
    if (licenseKey) {
      const lic = getLicenseByKey(licenseKey);
      if (lic && lic.status === 'active') {
        planId = lic.planId;
      } else {
        const integrity = validateKeyIntegrity(licenseKey);
        if (integrity.valid && integrity.planId) {
          planId = integrity.planId;
        }
      }
      recordLicenseApiCall(licenseKey, '/api/analyze', 'POST', Math.floor(28 + Math.random() * 40), 200, req.hostname);
    }

    const analysis = runSimulatedAnalysis(projectId, planId);
    res.json({ success: true, planId, analysis, sampleProjects: SAMPLE_PROJECTS });
  });

  // Gemini AI endpoints
  app.post('/api/gemini/audit', async (req, res) => {
    try {
      const { code, language = 'typescript', focusArea, licenseTier, enableThinking = true } = req.body;
      
      if (!code || typeof code !== 'string') {
        res.status(400).json({ success: false, message: 'Source code content is required for deep analysis.' });
        return;
      }

      const auditResult = await performDeepThinkingAudit({
        code,
        language,
        focusArea,
        licenseTier,
        enableThinking,
      });

      res.json({ success: true, audit: auditResult });
    } catch (err: any) {
      console.error('Gemini Deep Audit error:', err);
      res.status(500).json({ success: false, message: err.message || 'Gemini audit failure.' });
    }
  });

  app.post('/api/gemini/chat', async (req, res) => {
    try {
      const { message, contextCode } = req.body;
      if (!message) {
        res.status(400).json({ success: false, message: 'Message prompt required.' });
        return;
      }

      const replyData = await fastCodeSenseChat(message, contextCode);
      res.json({ success: true, reply: replyData.reply, model: replyData.model });
    } catch (err: any) {
      console.error('Gemini chat error:', err);
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Windows Software Tool Download Endpoints
  app.get('/api/downloads/stats', (req, res) => {
    try {
      const stats = getDownloadStats();
      res.json({ success: true, stats });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  app.post('/api/downloads/track', (req, res) => {
    try {
      const { os, country } = req.body || {};
      const userAgent = req.headers['user-agent'] || '';
      const stats = recordDownload({ os, country, userAgent });
      res.json({ success: true, stats, message: 'Download tracked successfully. Free mode with 1,000 points initiated!' });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  app.post('/api/downloads/set-count', (req, res) => {
    try {
      const { totalDownloads, todayDownloads } = req.body || {};
      const parsedTotal = typeof totalDownloads === 'number' ? totalDownloads : parseInt(totalDownloads, 10);
      const parsedToday = typeof todayDownloads === 'number' ? todayDownloads : (todayDownloads ? parseInt(todayDownloads, 10) : undefined);
      
      if (isNaN(parsedTotal) || parsedTotal < 0) {
        res.status(400).json({ success: false, message: 'Please provide a valid non-negative number for totalDownloads.' });
        return;
      }

      const stats = setCustomDownloadCount(parsedTotal, parsedToday);
      res.json({ success: true, stats, message: `Download count successfully updated to ${stats.totalDownloads.toLocaleString()}.` });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  return app;
}
