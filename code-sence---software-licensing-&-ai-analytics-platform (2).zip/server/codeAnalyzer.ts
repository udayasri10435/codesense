import { CodeAnalysisResult, PlanId } from '../src/types';

export const SAMPLE_PROJECTS: Record<string, { name: string; language: string; loc: number; files: number }> = {
  'ecommerce-microservice': {
    name: 'ecommerce-cart-service',
    language: 'TypeScript / Node.js',
    loc: 14820,
    files: 84,
  },
  'payment-gateway-sdk': {
    name: 'pay-core-engine',
    language: 'Go / gRPC',
    loc: 28400,
    files: 132,
  },
  'ml-pipeline-orchestrator': {
    name: 'data-flow-agent',
    language: 'Python 3.12',
    loc: 9650,
    files: 46,
  },
  'academic-cs101-assignments': {
    name: 'cs204-data-structures-lab',
    language: 'Java 21',
    loc: 4200,
    files: 28,
  }
};

export function runSimulatedAnalysis(projectId: string, planId: PlanId): CodeAnalysisResult {
  const project = SAMPLE_PROJECTS[projectId] || SAMPLE_PROJECTS['ecommerce-microservice'];
  
  // Base analysis
  const baseResult: CodeAnalysisResult = {
    projectName: project.name,
    language: project.language,
    filesScanned: project.files,
    linesOfCode: project.loc,
    technicalDebtHours: 36.5,
    qualityScore: 84,
    maintainabilityRating: 'B',
    duplicatedLinesPercent: 4.2,
    securityVulnerabilities: [
      {
        severity: 'high',
        rule: 'SECURITY-CWE-89: Potential SQL/NoSQL Injection in raw filter builder',
        file: 'src/services/cartQueryBuilder.ts',
        line: 142,
        suggestion: 'Use parameterized query builder or typed Prisma/Drizzle inputs instead of string concatenation.',
      },
      {
        severity: 'medium',
        rule: 'ARCH-LEAK: Unbounded connection pool timeout in Redis cache layer',
        file: 'src/config/redisCluster.ts',
        line: 29,
        suggestion: 'Set connectionTimeout: 5000 and maxRetriesPerRequest: 3 to avoid memory leak under heavy traffic spike.',
      }
    ],
    refactoringOpportunities: [
      {
        title: 'Extract Monolithic calculateCartTotals into Strategy Pattern',
        impact: 'High',
        effort: '2.5 hrs',
        description: 'The function calculateCartTotals spans 240 lines with a cyclomatic complexity of 19. Refactor into discount strategies.',
        codeSnippetBefore: `// Complex nested conditionals in cart checkout
function calculateCartTotals(cart: Cart, user: User, coupon?: Coupon) {
  let subtotal = 0;
  for (let i = 0; i < cart.items.length; i++) {
    subtotal += cart.items[i].price * cart.items[i].quantity;
    if (cart.items[i].isTaxExempt) { /* ... */ }
    if (user.isVip && cart.items[i].category === 'ELECTRONICS') {
      subtotal -= cart.items[i].price * 0.15;
    }
  }
  // 150 more lines of tax, currency & VAT nested logic...
}`,
        codeSnippetAfter: `// Clean decomposed Strategy pattern
export class CartTotalCalculator {
  constructor(private strategies: PricingStrategy[]) {}
  
  public calculate(cart: Cart, context: PricingContext): CartSummary {
    const base = cart.calculateSubtotal();
    return this.strategies.reduce(
      (acc, strategy) => strategy.apply(acc, context),
      base
    );
  }
}`,
      },
      {
        title: 'Eliminate N+1 Query in Customer Order Items Hydration',
        impact: 'High',
        effort: '1.0 hr',
        description: 'Iterating over fetched orders and awaiting database query per line item degrades database latency from 15ms to 420ms.',
        codeSnippetBefore: `for (const order of orders) {
  order.items = await db.orderItems.findMany({ where: { orderId: order.id } });
}`,
        codeSnippetAfter: `// Batch load with single indexed IN query
const orderIds = orders.map(o => o.id);
const allItems = await db.orderItems.findMany({ where: { orderId: { in: orderIds } } });
const itemsByOrder = groupBy(allItems, 'orderId');
orders.forEach(o => o.items = itemsByOrder[o.id] || []);`,
      }
    ]
  };

  // If FREE tier, strip advanced refactoring and enterprise metrics
  if (planId === 'free') {
    return {
      ...baseResult,
      technicalDebtHours: 0, // Not available in free
      refactoringOpportunities: [], // Pro feature only
    };
  }

  // If Enterprise or Team, add CI/CD policy gates and compliance rules
  if (planId === 'enterprise' || planId === 'team') {
    baseResult.securityVulnerabilities.push({
      severity: 'low',
      rule: 'COMPLIANCE-RBAC: Missing role validation annotation on internal export route',
      file: 'src/controllers/adminExportController.ts',
      line: 88,
      suggestion: 'Add @RequiresPermission(Permission.AUDIT_LOG_EXPORT) guard to prevent privilege escalation.',
    });
  }

  return baseResult;
}
